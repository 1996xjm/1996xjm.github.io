import os

merge_annotation_output = "merge_annotation"

pgap_output = config["pgap"]
bakta_proteins_output = config["bakta"]
rast_output = config["rast"]
SAMPLES = os.listdir(pgap_output)
rule all:
    input:
        expand(merge_annotation_output + "/{sample}_annotation.tsv", sample=SAMPLES)

rule merge_annotation_result:
    input:
        pgap_gff = pgap_output + "/{sample}/result/annot.gff",
        bakta_tsv = bakta_proteins_output + "/{sample}/{sample}.tsv",
        rast_tsv = rast_output + "/{sample}/{sample}_subsystem.tsv",
    output:
        merge_annotation_output + "/{sample}_annotation.tsv"
    script:
        "scripts/python/merge_annotation_result.py"