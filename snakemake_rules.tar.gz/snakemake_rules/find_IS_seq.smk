"""
name: find insertion sequence
date: 20234-03-22
description: Snakemake pipeline to find insertion sequences (multiple copy) by blasting the transposase gene together with 200-500 bp of flanking sequence across the entire genome.
author: Jianmin Xie
dependencies:
    - blastn,
    - seqkit,
rules:
    -
"""
import os
from os import path
import pandas as pd
shell.executable('/bin/zsh') # set a shell to run commands


env_name = config["env_name"]
ref_genome = config["genome"]

combined_genomes = "/Users/xjm/Documents/sampling/final_representative_strain/Phaeobacter_gallaeciensis/TG_genome/genome/combined_genomes.fasta"
combined_ISs = "/Users/xjm/Documents/sampling/final_representative_strain/Phaeobacter_gallaeciensis/TG_genome/mobile_element/IS/All/All_IS.fasta"

annotation_file = '/Users/xjm/Documents/sampling/final_representative_strain/Phaeobacter_gallaeciensis/TG_genome/mobile_element/transposase/annotation/PT47_15_transposase_gene_info.tsv'

annotation_file_df = pd.read_table(annotation_file, index_col=0)

transposase_gene_id = "PT47_15_004293"
transposase_family = "IS5"
print(annotation_file_df.loc[transposase_gene_id, "cluster_id"])


left_flanking_length = 200
right_flanking_length = 200
strand = annotation_file_df.loc[transposase_gene_id, 'Strand']
cluster = annotation_file_df.loc[transposase_gene_id, 'cluster_id'].replace('_','')

IS_L = 331
IS_R = 3988


rule all:
    input:
        "blast.out",
        # f"{transposase_family}_{cluster}.fasta",




rule extract_expanding_IS:
    params:
        start = annotation_file_df.loc[transposase_gene_id, 'Start']-(left_flanking_length if strand == "+" else right_flanking_length),
        end = annotation_file_df.loc[transposase_gene_id, 'End']+ (right_flanking_length if strand == "+" else left_flanking_length),
        chr = annotation_file_df.loc[transposase_gene_id, 'Seqname'],
        strand =strand,
    output:
        f"tmp/{transposase_family}_{cluster}_{transposase_gene_id}.fasta",
    conda:
        env_name
    shell:
        """if [[ {params.strand} == "-" ]] {{
    seqkit subseq -r {params.start}:{params.end} --chr {params.chr} {ref_genome} | seqkit seq -r -p -w 0 > {output}
}} else {{
    seqkit subseq -r {params.start}:{params.end} --chr {params.chr} -w 0 {ref_genome} > {output}
}}"""

rule blastn:
    input:
        rules.extract_expanding_IS.output
    output:
        "blast.out",
    conda:
        env_name
    shell:
        "blastn -query {input} -subject {combined_genomes} -evalue 1e-5 -outfmt '6 sacc pident qcovhsp qlen slen length mismatch gapopen evalue bitscore qstart qend sstart send' "
        "|sort -nr -k10,10;echo \"\n\n\";" # 对第10列进行降序排序
        "blastn -query {input} -subject {combined_ISs} -evalue 1e-5 -outfmt '6 sacc pident qcovhsp qlen slen length mismatch gapopen evalue bitscore qstart qend sstart send' "
        "|sort -nr -k10,10" # 对第10列进行降序排序



rule extract_IS:
    input:
        rules.extract_expanding_IS.output
    output:
        f"{transposase_family}_{cluster}.fasta"
    params:
        l=IS_L,
        r=IS_R,
    conda:
        "blast"
    shell:
        "[[ ! -e {output} ]] && seqkit subseq -w 0 -r {params.l}:{params.r} {input} | seqkit replace -p '(.*)' -r '{transposase_family}_{cluster}_{transposase_gene_id}' -w 0 > {output}"
