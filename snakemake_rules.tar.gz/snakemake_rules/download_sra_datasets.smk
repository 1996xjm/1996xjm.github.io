"""
name: download SRA datasets
date: 2023-01-14
description: Snakemake pipeline to download SRA datasets
author: Jianmin Xie
dependencies:
    - ascp = 4.4.2.550,
rules:
    - download
"""

import pandas as pd
from os import path
shell.executable('/bin/zsh') # set a shell to run commands


# 从ENA导出来的表格：例如 https://www.ebi.ac.uk/ena/browser/view/PRJEB1787
metadata_file = config["metadata"]
output_path = "reads"
openssh = config["openssh"]

env_name = "aspera-v4"

check_md5_output = "check_md5_output"

logs_dir = f"logs"
benchmarks = "benchmarks"


def get_sample_df(metadata_file):
    meteData = pd.read_table(metadata_file)

    # print(meteData)

    run_accession_list = []
    fastq_md5_list = []
    fastq_aspera_list = []
    filename_list = []
    for i, row in meteData.iterrows():
        run_accession = row["run_accession"].strip()
        fastq_md5_split = row["fastq_md5"].strip().split(";")
        fastq_aspera_split = row["fastq_aspera"].strip().split(";")
        for i, md5 in enumerate(fastq_md5_split):
            run_accession_list.append(run_accession)
            fastq_md5_list.append(md5)
            # 参考sra explorer网站上面的没有根符号
            fastq_aspera_list.append("era-fasp@" + fastq_aspera_split[i].replace(":/",":"))
            filename_list.append(path.basename(fastq_aspera_split[i]))

    return (pd.DataFrame({
        "run_accession": run_accession_list,
        "fastq_md5": fastq_md5_list,
        "fastq_aspera": fastq_aspera_list,
    },index=filename_list).to_dict(orient='index'),filename_list,run_accession_list)

metadata_dict, SAMPLE, Accession = get_sample_df(metadata_file)



def get_Aspera_URL(wildcards):
    return metadata_dict[wildcards.sample]["fastq_aspera"]

rule all:
    input:
        expand([output_path + "/{accession}/{sample}", check_md5_output + "/{accession}/{sample}.md5"], zip, accession=Accession[:48], sample=SAMPLE[:48]),


rule download:
    params:
        url=get_Aspera_URL,
        openssh=openssh
    output:
        protected(output_path + "/{accession}/{sample}")
    benchmark:
        benchmarks + "/{accession}/{sample}_benchmark.tsv"
    conda:
        env_name
    retries: 10
    shell:
        "ascp -k 1 -QT -l 300m -P33001 -i {params.openssh} {params.url} {output}"


rule check_md5:
    input:
        rules.download.output
    output:
        check_md5_output + "/{accession}/{sample}.md5"
    run:
        for line in shell("md5sum {input}", iterable=True):
            print(">>>>>>>:")
            md5_res, filename = line.strip().split("  ")
            fastq_md5 = metadata_dict[wildcards.sample]['fastq_md5']
            echo_str = f"{filename}\t{md5_res}\t{md5_res}\t{md5_res == fastq_md5}\n"
        shell(f"echo '{echo_str}' > {{output}}")


