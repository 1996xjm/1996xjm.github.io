"""
name: quality control
date: 2022-11-27
description: Snakemake pipeline to do gene prediction, annotation
author: Jianmin Xie
dependencies:
    - prokka = 1.14.6
rules:
    - prokka

"""

import os
from os import path
genome_dir = config["fasta"]
genome_suffix = config.get("genome_suffix","fasta")
env_name = config["env"]
SAMPLES = [".".join(i.split(".")[:-1]) for i in os.listdir(genome_dir)]
bakta_output = "bakta_output"
bakta_db = config["bakta_db"]



shell.executable('/bin/zsh') # set a shell to run commands




# onsuccess:
#     #  merge prokka results of all samples
#     shell(f"python  ~/Documents/BioInformatic/genome_assembly/mergeProkkaSummary.py -f {PROKKA_OUT_PATH} -o ./summary_table")

rule all:
    input:
        expand(bakta_output + "/{sample}/{sample}.tsv", sample=SAMPLES),


# rule prokka:
#     input:
#         genomes_dir + "/{sample}.fasta"
#     output:
#         directory(PROKKA_OUT_PATH + "/{sample}")
#     threads: 16
#     params:
#         sampleName = "{sample}"
#     log:
#         "logs/flash/{sample}_flash.log"
#     conda:
#         env_name
#     shell:
#         "prokka --quiet --cpus {threads} --locustag {params.sampleName} --force --outdir {output} --prefix {params.sampleName} {input}"



rule bakta:
    input:
        genome=genome_dir + "/{sample}." + genome_suffix,
    output:
        bakta_output + "/{sample}/{sample}.tsv"
    params:
        out_dir=bakta_output + "/{sample}",
        db=bakta_db,
    log:
        "logs/bakta/{sample}_bakta.log"
    threads: workflow.cores / 4
    conda:
        env_name
    shell:
        "bakta -f "
        "--db {params.db} "
        "--verbose "
        "--output {params.out_dir} "
        "--prefix {wildcards.sample} "
        "--locus-tag {wildcards.sample} "
        "--threads {threads} {input.genome} "
        "&> {log}"





