"""
name: run anvi pangenomics
date: 20234-03-22
description: Snakemake pipeline to run anvi pangenomics https://merenlab.org/2016/11/08/pangenomics-v2/
author: Jianmin Xie
dependencies:
    - anvio,
rules:
    -
"""
import os
from os import path
import pandas as pd
import numpy as np
from itertools import combinations

shell.executable('/bin/zsh') # set a shell to run commands

# configfile: "configs/anvio_pangenome_config.yaml"

env_name = config["env_name"]
pgap_output = config["pgap_output"]



blast_db_output = "blast_db"
diamond_db_output = "diamond_db"
external_gene_calls_output = "external_gene_calls"
contigs_db_output = "contigs_db"
pan_genome_output = "pan_genome_output"
core_genome_proportion = "core_genome_proportion"



SAMPLES =  os.listdir(pgap_output)




# 方法一：f-string（元素会自动 str()）
pairs_dict = {
    f"{a}_vs_{b}": (a, b)
    for a, b in combinations(SAMPLES, 2)
}

SAMPLES = pairs_dict.keys()


rule all:
    input:
        # expand(pan_genome_output + "/{sample}/table/gene_cluster_count.tsv", sample=SAMPLES)
        core_genome_proportion + "/core_genome_proportion_matrix.tsv"



rule rename_and_merge_pgap_faa:
    input:
        faa=lambda w:[pgap_output + f"/{i}/result/annot_translated_cds.faa" for i in pairs_dict.get(w.sample) ],
    output:
        faa=pan_genome_output + "/{sample}/seq/combined-aas.faa",
    log:
        "logs/rename_and_merge_pgap_faa/{sample}.log"
    script:
        "scripts/python/rename_and_merge_pgap_faa.py"


rule make_blast_db:
    input:
        rules.rename_and_merge_pgap_faa.output.faa
    output:
        blast_db_output + "/{sample}/combined-aas.phr"
    params:
        db_prifix = blast_db_output + "/{sample}/combined-aas"
    conda:
        env_name
    log:
        "logs/make_blast_db/{sample}.log"
    shell:
        "makeblastdb -in {input} -dbtype prot -out {params.db_prifix} &> {log}"

rule run_blastp:
    input:
        phr = rules.make_blast_db.output,
        faa = rules.rename_and_merge_pgap_faa.output.faa
    output:
        pan_genome_output + "/{sample}/table/blast-search-results.tsv"
    params:
        db_prifix = blast_db_output + "/{sample}/combined-aas",
        max_target_seqs = 10000, # 如果你的基因组个数大于这个数，你要提高这个数值
    conda:
        env_name
    threads: workflow.cores
    log:
        "logs/blastp/{sample}.log"
    shell:
        "blastp -query {input.faa} -db {params.db_prifix} -evalue 1e-05 -outfmt '6 qseqid sseqid pident qcovhsp qlen slen length mismatch gapopen evalue bitscore' -max_target_seqs {params.max_target_seqs} -out {output} -num_threads {threads} &> {log}"


rule generate_mcl_input:
    input:
        rules.run_blastp.output
    output:
        pan_genome_output + "/{sample}/table/mcl-input.tsv"
    params:
        minbit = 0.5 # minbit = BITSCORE(A, B) / MIN(BITSCORE(A, A), BITSCORE(B, B)), 过滤掉不相似的边的阈值
    log:
        "logs/generate_mcl_input/{sample}.log"
    script:
        "scripts/python/pangenome/generate_mcl_input.py"



rule run_mcl:
    input:
        rules.generate_mcl_input.output
    output:
        pan_genome_output + "/{sample}/table/mcl-clusters.tsv"
    params:
        inflation = 10 # MCL - a cluster algorithm for graphs， 膨胀系数 非常相近的基因组建议用10
    conda:
        env_name
    threads: 64
    log:
        "logs/run_mcl/{sample}.log"
    shell:
        "mcl {input} --abc -I {params.inflation} -o {output} -te {threads} &> {log}"



rule generate_gene_cluster_output:
    input:
        mcl = rules.run_mcl.output[0],
        faa = rules.rename_and_merge_pgap_faa.output.faa,
        blastp_res = rules.run_blastp.output[0],
    output:
        gene_cluster_count = pan_genome_output + "/{sample}/table/gene_cluster_count.tsv",
        core_genome_proportion = pan_genome_output + "/{sample}/table/core_genome_proportion.tsv",
        # gene_type_table = pan_genome_output + "/{sample}/table/gene_type_table.tsv",
        # single_copy_aas_dir = directory(pan_genome_output + "/{sample}/seq/single_copy_aas"),
        # single_copy_sample_aas_dir = directory(pan_genome_output + "/{sample}/seq/single_copy_sample_aas"),
        # all_cluster_aas_dir = directory(pan_genome_output + "/{sample}/seq/all_cluster_aas"),
        # single_copy_fnas_dir = directory(pan_genome_output + "/{sample}/seq/single_copy_fnas"),
        # single_copy_genes_annotation_dir = directory(pan_genome_output + "/{sample}/table/single_copy_genes_annotation"),
        # genome_specific_aas_dir = directory(pan_genome_output + "/{sample}/seq/genome_specific_aas"),
        # genome_specific_genes_annotation_dir = directory(pan_genome_output + "/{sample}/table/genome_specific_genes_annotation"),
        # genome_specific_genes_blastp_info_dir = directory(pan_genome_output + "/{sample}/table/genome_specific_genes_blastp_info"),
    log:
        "logs/generate_gene_cluster_output/{sample}.log"
    script:
        "scripts/python/pangenome/generate_gene_cluster_table_paired.py"



rule merge_core_genome_proportion:
    input:
        expand(pan_genome_output + "/{sample}/table/core_genome_proportion.tsv",sample=SAMPLES)
    output:
        table = core_genome_proportion + "/core_genome_proportion.tsv",
        matrix = core_genome_proportion + "/core_genome_proportion_matrix.tsv",
        genus_value = core_genome_proportion + "/genus_value.tsv",
    run:
        p_list = [pd.read_table(i) for i in input]
        df = pd.concat(p_list,axis=0)

        df.to_csv(output.table,sep="\t",index=None)
        # 获取所有唯一的菌株 ID
        ids = pd.Index(df['pair1'].tolist() + df['pair2'].tolist()).unique()

        # 构造一个空的 DataFrame，行列均为所有 ID
        mat = pd.DataFrame(np.nan,index=ids,columns=ids,dtype=float)

        genus_value_dict = {
            "Leisingera": [],
            "Phaeobacter":[],
            "Pseudophaeobacter": [],
            "study":[]
        }

        new_id = {"SY47_7": "AcS47_7", "GCF_021228235.1": "Pseudophaeobacter flagellatus", "PT47_15": "LaS47_15", "PT42_8": "ChS42_8", "GCF_025857195.1": "Leisingera thetidis", "GCF_000473165.1": "Leisingera aquimarina", "GCF_000826835.2": "Phaeobacter piscinae", "PT24_64": "DiB24_64", "GCF_029697505.1": "Pseudophaeobacter profundi", "GCF_002087335.1": "Pseudophaeobacter leonis", "PT34_48": "ThF34_48", "GCF_000511385.1": "Phaeobacter gallaeciensis", "GCF_000473205.1": "Pseudophaeobacter arcticus", "GCF_000473145.1": "Leisingera daeponensis", "GCF_000473325.1": "Leisingera caerulea", "GCF_001458395.1": "Leisingera aquaemixtae", "GCF_025139345.1": "Leisingera aquaemixtae", "SY12_1": "BaP12_1", "PT41_83": "NeS41_83", "GCF_000473105.1": "Phaeobacter inhibens", "GCF_000511355.1": "Leisingera methylohalidivorans", "GCF_001888185.1": "Phaeobacter porticola"}
        # 将已知的 ANI 值填入矩阵（上三角或下三角）
        for row in df.itertuples(index=False):
            i, j, ani = row.pair1, row.pair2, row.value
            mat.at[i, j] = ani
            mat.at[j, i] = ani  # 对称填充

            i_genus = new_id[i].split(" ")[0]
            j_genus = new_id[j].split(" ")[0]
            if i_genus == j_genus:
                genus_value_dict[i_genus].append(ani)
            elif i_genus not in genus_value_dict.keys() and j_genus not in genus_value_dict.keys():
                genus_value_dict["study"].append(ani)

        # 把每个 list 转成 Series，Series 长度不一时会自动填 NaN
        series_dict = {k: pd.Series(v) for k, v in genus_value_dict.items()}

        pd.DataFrame(series_dict).to_csv(output.genus_value,sep="\t")


        mat.fillna(100).to_csv(output.matrix,sep="\t")
        # mat.fillna(100).rename(columns=new_id,index=new_id).to_csv(output.matrix,sep="\t")

