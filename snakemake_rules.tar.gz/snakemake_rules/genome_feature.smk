"""
name: quality control
date: 2022-11-27
description: Snakemake pipeline to do quality control, assembly, summary assembly quality
author: Jianmin Xie
dependencies:
    - fastp = 0.23.2
    - spades = 3.15.3
    - quast = 5.2.0
    - checkm = 1.2.0
rules:
    - fastp
    - spades
    - filterLengthAndCoverage
    - quast

"""

import os
from os import path
genomes_dir = "/home/xjm/Sulfitobacter/ncbi_dataset/dereplicate_output_fastANI/dereplicated_genomes"
SAMPLES = [".".join(i.split(".")[:-1]) for i in os.listdir(genomes_dir)]

QUAST_OUT_PATH = "quast_output"
PROKKA_OUT_PATH = "prokka_output"


shell.executable('/bin/zsh') # set a shell to run commands




onsuccess:
    #  merge quast results of all samples
    shell(f"python  ~/BioInformatic/genome_assembly/mergeQuastSummary.py -f {QUAST_OUT_PATH} -o ./summary_table")
    shell(f"python  ~/BioInformatic/genome_assembly/mergeProkkaSummary.py -f {PROKKA_OUT_PATH} -o ./summary_table")

rule all:
    input:
        expand(PROKKA_OUT_PATH + "/{sample}", sample=SAMPLES),
        expand(QUAST_OUT_PATH + "/{sample}", sample=SAMPLES),

rule prokka:
    input:
        genomes_dir + "/{sample}.fna"
    output:
        directory(PROKKA_OUT_PATH + "/{sample}")
    threads: 16
    params:
        sampleName = "{sample}"
    log:
        "logs/flash/{sample}_flash.log"
    conda:
        "SG_assembly"
    shell:
        "prokka --quiet --cpus {threads} --locustag {params.sampleName} --force --outdir {output} --prefix {params.sampleName} {input}"


rule quast:
    input:
        genomes_dir + "/{sample}.fna"
    output:
        directory(QUAST_OUT_PATH + "/{sample}")
    conda:
        "quality_assessment"
    shell:
        "quast.py {input} -o {output} &> /dev/null"







