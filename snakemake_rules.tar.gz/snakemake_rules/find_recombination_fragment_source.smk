"""
name: find source of recombination fragments from reference genome database
date: 2023-01-06
description: Snakemake pipeline to find source of recombination fragments from reference genome database
author: Jianmin Xie
dependencies:
    - blast = 2.12.0,
rules:
    - move_genome
    - make_blast_db
    - blast
    - statistics


"""

import os
from os import path
import json
import pandas as pd

WORK_PATH = "/home/cyr/Documents/xjm/finall_strain/Pha/population_structure/recombination_fragment_source"
reference_genome_PATH = "/home/cyr/Documents/xjm/finall_strain/genome_db/recombination_fragment_source_db"
SAMPLE = [i for i in os.listdir(WORK_PATH)  if not i.startswith(".")]
onsuccess:
    res_arr = []
    for i in SAMPLE:
        with open(path.join(WORK_PATH,i,"summary.json"), "r") as f:
            res = json.load(f)
            res["node"] = i
            res_arr.append(res)
    print(res_arr)
    print(pd.DataFrame(res_arr).set_index("node", drop=True).to_csv(sep="\t"))

shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand(WORK_PATH + "/{sample}/genome", sample=SAMPLE),
        expand(WORK_PATH + "/{sample}/blast_db", sample=SAMPLE),
        expand(WORK_PATH + "/{sample}/blast.out", sample=SAMPLE),
        expand(WORK_PATH + "/{sample}/summary.json", sample=SAMPLE),


rule move_genome:
    input:
        rgp=reference_genome_PATH,
        et=WORK_PATH + "/{sample}/exclude_taxa.txt" #把属于本clade的基因组排除
    output:
        directory(WORK_PATH + "/{sample}/genome")
    shell:
        "mkdir {output};"
        "ln -fs {input.rgp}/**/*.(fasta|fna) {output};"
        "while {{read i}} {{ unlink {output}/${{i}}.fasta }} < {input.et}"

rule make_blast_db:
    input:
        rules.move_genome.output
    output:
        directory(WORK_PATH + "/{sample}/blast_db")
    shell:
        "mkdir {output};"
        "cat {input}/* | sed 's/\(.\)>/\\1\\n>/g' > {output}/ref.fasta;" # use sed to deal with error of missing '\n' before '>'
        "makeblastdb -in {output}/ref.fasta  -dbtype nucl -out {output}/recREF;"
        "rm {output}/ref.fasta"

rule blast:
    input:
        db=rules.make_blast_db.output,
        query=WORK_PATH + "/{sample}/recombination_fragment.fasta"
    output:
        WORK_PATH + "/{sample}/blast.out"
    shell:
        "blastn -db {input.db}/recREF -query {input.query} "
        "-outfmt '6 qacc sacc pident qcovhsp qlen slen length mismatch gapopen evalue bitscore' "
        "-out {output} -evalue 1e-5 -max_target_seqs 10"

rule stat:
    input:
        blastOut=rules.blast.output,
        query=WORK_PATH + "/{sample}/recombination_fragment.fasta"
    output:
        WORK_PATH + "/{sample}/summary.json"
    shell:
        "python  ~/Documents/BioInformatic/Gubbins/recombination_fragment_source_blast_result.py -b {input.blastOut} -f {input.query} -o {output}"
