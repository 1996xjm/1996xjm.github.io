"""
name: run McScanX
date: 2023-03-02
description: Snakemake pipeline to run McScanX
author: Jianmin Xie
dependencies:
    - prokka =
    - McScanX = 1.2.2,
    - blast = 2.12.0
rules:
    - make_db
"""
import os
from os import path
import pandas as pd
shell.executable('/bin/zsh') # set a shell to run commands

base_dir = "/home/xjm/Sulfitobacter/ncbi_dataset"
genome_dir = path.join(base_dir, "dereplicate_output_fastANI/dereplicated_genomes")
prokka_output_dir = path.join(base_dir, "prokka_output")
gff_output_dir = path.join(base_dir, "gff_output")
faa_output_dir = path.join(base_dir, "faa_output")
blast_db_dir = path.join(base_dir, "blast_db")
suffix = "fna"
threads = 32



SAMPLE = [".".join(i.split(".")[0:-1]) for i in os.listdir(genome_dir)]

print(SAMPLE)

# onsuccess:
#     shell(f"cat {gff_output_dir}/* > {path.join(base_dir, 'combined.gff')}")
#     shell(f"cat {faa_output_dir}/* > {path.join(base_dir, 'combined.faa')}")
#     shell(f"mkdir -p {blast_db_dir}")
#     shell(f"makeblastdb -in {path.join(base_dir, 'combined.faa')} -dbtype prot -parse_seqids -out {path.join(blast_db_dir,'combined')}")
#     shell(f"blastp -query {path.join(base_dir, 'combined.faa')} -out {path.join(base_dir, 'combined.blast')} -db {path.join(blast_db_dir,'combined')} -outfmt 6 -evalue 1e-5 -num_threads {threads}")
#     shell("MCScanX combined")
rule all:
    input:
        expand(prokka_output_dir + "/{sample}/{sample}.gff", sample=SAMPLE),
        expand(prokka_output_dir + "/{sample}/{sample}.faa", sample=SAMPLE),
        expand(gff_output_dir + "/{sample}.gff", sample=SAMPLE),
        expand(faa_output_dir + "/{sample}.faa", sample=SAMPLE),
        # expand("mcScanX_out" + "/{sample}/combined.faa", sample=SAMPLE),
        # expand("mcScanX_out" + "/{sample}/combined.gff", sample=SAMPLE),
        expand("mcScanX_out" + "/{sample}/blast_db/combined.pdb", sample=SAMPLE),


rule prokka:
    input:
        genome_dir + "/{sample}." + suffix
    output:
        gff=prokka_output_dir + "/{sample}/{sample}.gff",
        faa=prokka_output_dir + "/{sample}/{sample}.faa",
    threads: 16
    conda:
        "SG_assembly"
    params:
        dir = directory(prokka_output_dir + "/{sample}"),
        sampleName = "{sample}"
    shell:
        "prokka --quiet --cpus {threads} --locustag {params.sampleName} --force --outdir {params.dir} --prefix {params.sampleName} {input}"


rule pre_gff:
    input:
        rules.prokka.output.gff
    output:
        gff_output_dir + "/{sample}.gff"
    shell:
        "grep '\CDS\s'  {input} | awk -F '[\t;=]' 'BEGIN{{OFS=\"\t\"}} {{print $1,$10,$4,$5}}' > {output}"

rule cp_faa:
    input:
        rules.prokka.output.faa
    output:
        faa_output_dir + "/{sample}.faa"
    shell:
        "cp {input} {output}"

# 甘老师
c_11_faa = "mcScanX/faa/1-11.faa"
c_11_gff = "mcScanX/gff/1-11.gff"
# rule cat_faa:
#     input:
#         rules.cp_faa.output,
#         c_11_faa
#     output:
#         "mcScanX_out" + "/{sample}/combined.faa"
#     shell:
#         "cat {input} > {output}"
#
#
# rule cat_gff:
#     input:
#         rules.pre_gff.output,
#         c_11_gff
#     output:
#         "mcScanX_out" + "/{sample}/combined.gff"
#     shell:
#         "cat {input} > {output}"



rule blast:
    input:
        rules.cp_faa.output
    output:
        "mcScanX_out" + "/{sample}/blast_db/combined.pdb",
        "mcScanX_out" + "/{sample}/{sample}.blast",
    params:
        prefix = "mcScanX_out" + "/{sample}/blast_db/combined",
        dir = "mcScanX_out" + "/{sample}"
    threads: 8
    conda:
        "SG_assembly"
    shell:
        "makeblastdb -in {input} -dbtype prot -parse_seqids -out {params.prefix};"
        "blastp -query mcScanX/faa/1-11.faa -out {output[1]} -db {params.prefix} -outfmt 6 -evalue 1e-5 -num_threads {threads} -max_target_seqs 1;"
