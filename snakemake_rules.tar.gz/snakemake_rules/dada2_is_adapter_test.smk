"""
name: dada2 qiime2 test
date: 2023-12-27
description: Snakemake pipeline to test params of dada2 and qiime2
author: Jianmin Xie
dependencies:
    - bioconductor-shortread = 1.60.0 # r-base is in this package
    - cutadapt = 4.6
    - flash = 1.2.11
    - qiime2 = 2023.9.0
    - biopython
    - pandas

rules:
    - fastp
    - flye
    - minimap2
    - pilon


"""

import os
from os import path
configfile: "configs/dada2_qiime2_test_config.yaml"

samples_dir = config["samples_dir"]
env_name = config["env_name"]
SAMPLES = os.listdir(samples_dir)

f_primer = config["f_primer"]
r_primer = config["r_primer"]
truncLen = config["truncLen"]
phred_offset = config["phred_offset"]

minFoldParentOverAbundance = config["minFoldParentOverAbundance"]

max_error_num = config["max_error_num"]



custom_pipeline_output = f"custom_pipeline_output_mfp{minFoldParentOverAbundance}"
renamed_reads = "renamed_reads"
cutadapt_output = "cutadapt_output"

logs_dir = f"logs_mfp{minFoldParentOverAbundance}"



flash_output = path.join(custom_pipeline_output, "flash_output")

dada2_paired_no_adapter_truncLen220_output = path.join(custom_pipeline_output, "dada2_paired_no_adapter_truncLen220_output")
dada2_paired_with_adapter_truncLen220_output = path.join(custom_pipeline_output, "dada2_paired_with_adapter_truncLen220_output")


dada2_single_filter_output = path.join(custom_pipeline_output, "dada2_single_filter_output")
summary_output = path.join(custom_pipeline_output, "summary_output")


shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand(custom_pipeline_output + "/dada2_paired_no_adapter_truncLen{len}_output/{sample}/{sample}_rep_seqs_nochim.fasta", len=[220], sample=SAMPLES),
        expand(dada2_single_filter_output + "/{sample}/{sample}_rep_seqs_nochim.fasta", sample=SAMPLES),
        expand(summary_output + "/{type}_length_frequency_distribution_{order}_cutting.tsv", type=["R1", "R2"], order=["before", "after"]),
        expand(summary_output + "/{type}.tsv", type=["single_filter_reads"]),
        expand(summary_output + "/paired_reads_no_adapter_truncLen{len}.tsv", len=[220]),
    default_target: True

# cutadapt read id 不一致会报错，去掉注释部分
rule rename_reads_id:
    input:
        r1 = samples_dir + "/{sample}/{sample}_1.fq.gz",
        r2 = samples_dir + "/{sample}/{sample}_2.fq.gz"
    output:
        r1=temp(renamed_reads + "/{sample}/{sample}_1.fq"),
        r2=temp(renamed_reads + "/{sample}/{sample}_2.fq")
    shell:
        "zcat {input.r1}|sed 's/#.*\/1$/\/1/g' > {output.r1};"
        "zcat {input.r2}|sed 's/#.*\/2$/\/2/g' > {output.r2}"

rule cutadapt:
    input:
        r1 = rules.rename_reads_id.output.r1,
        r2 = rules.rename_reads_id.output.r2
    output:
        r1 = cutadapt_output + "/{sample}/{sample}_1.fq.gz",
        r2 = cutadapt_output + "/{sample}/{sample}_2.fq.gz"
    log:
        logs_dir + "/cutadapt/{sample}_cutadapt.log"
    threads: 16
    params:
        f_adapter = f_primer,
        r_adapter = r_primer,
        max_error_num = max_error_num
    conda:
        env_name
    shell:
        "cutadapt --discard-untrimmed -g {params.f_adapter} -G {params.r_adapter} -e {params.max_error_num} -o {output.r1} -p {output.r2} {input.r1} {input.r2} &> {log}"


rule reads_length_frequency_distribution_before_cutting:
    input:
        r1 = expand(renamed_reads + "/{sample}/{sample}_1.fq", sample=SAMPLES),
        r2 = expand(renamed_reads + "/{sample}/{sample}_2.fq", sample=SAMPLES)
    output:
        r1 = summary_output + "/R1_length_frequency_distribution_before_cutting.tsv",
        r2 = summary_output + "/R2_length_frequency_distribution_before_cutting.tsv",
    log:
        logs_dir + "/reads_len_freq_dist_before_cutting.log"
    conda:
        env_name
    script:
        "scripts/R/reads_length_frequency_distribution.R"


rule reads_length_frequency_distribution_after_cutting:
    input:
        r1 = expand(cutadapt_output + "/{sample}/{sample}_1.fq.gz", sample=SAMPLES),
        r2 = expand(cutadapt_output + "/{sample}/{sample}_2.fq.gz", sample=SAMPLES)
    output:
        r1 = summary_output + "/R1_length_frequency_distribution_after_cutting.tsv",
        r2 = summary_output + "/R2_length_frequency_distribution_after_cutting.tsv",
    log:
        logs_dir + "/reads_len_freq_dist_after_cutting.log"
    conda:
        env_name
    script:
        "scripts/R/reads_length_frequency_distribution.R"

rule flash:
    input:
        r1 = rules.cutadapt.output.r1,
        r2 = rules.cutadapt.output.r2,
    output:
        flash_output + "/{sample}/{sample}.extendedFrags.fastq"
    log:
        logs_dir + "/flash/{sample}_flash.log"
    threads: 16
    params:
        prefix = "{sample}",
        out_dir = flash_output + "/{sample}",
        phred_offset = phred_offset,
        max_overlap = 250 # 最大重叠长度，如果重叠区大于这个长度也会正常拼接，但是下面的错配比率的分母还是按照这个值去算而不是整个重叠区长度，会导致拼接失败的比例升高 [default: 65]
    conda:
        env_name
    shell:
        "flash -m 15 -M {params.max_overlap} -x 0.1 -o {params.prefix} -d {params.out_dir} -p {params.phred_offset} -t {threads} {input.r1} {input.r2} &> {log}"





rule dada2_paired_reads_no_adapter_truncLen220:
    input:
        r1 = rules.cutadapt.output.r1,
        r2 = rules.cutadapt.output.r2,
    output:
        r1 = dada2_paired_no_adapter_truncLen220_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2 = dada2_paired_no_adapter_truncLen220_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs = dada2_paired_no_adapter_truncLen220_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv = dada2_paired_no_adapter_truncLen220_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name = "{sample}",
        minFoldParentOverAbundance = minFoldParentOverAbundance,
        truncLen = truncLen
    log:
        logs_dir + "/dada2_paired_reads_no_adapter_truncLen220/{sample}_dada2_paired_reads.log"
    conda:
        env_name
    script:
        "scripts/R/dada2_from_paired_reads.R"

rule dada2_paired_reads_with_adapter_truncLen220:
    input:
        r1=rules.rename_reads_id.output.r1,
        r2=rules.rename_reads_id.output.r2
    output:
        r1 = dada2_paired_with_adapter_truncLen220_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2 = dada2_paired_with_adapter_truncLen220_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs = dada2_paired_with_adapter_truncLen220_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv = dada2_paired_with_adapter_truncLen220_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name = "{sample}",
        minFoldParentOverAbundance = minFoldParentOverAbundance,
        truncLen = truncLen
    log:
        logs_dir + "/dada2_paired_reads_with_adapter_truncLen220/{sample}_dada2_paired_reads.log"
    conda:
        env_name
    script:
        "scripts/R/dada2_from_paired_reads.R"




rule dada2_single_filter_reads:
    input:
        cr1 = rules.cutadapt.output.r1,
        merged_seq = rules.flash.output
    output:
        rep_seqs = dada2_single_filter_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv= dada2_single_filter_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name = "{sample}",
        minFoldParentOverAbundance = minFoldParentOverAbundance,
        is_filter = 1
    log:
        logs_dir + "/dada2_single_filter_reads/{sample}_dada2_single_filter_reads.log"
    conda:
        env_name
    script:
        "scripts/R/dada2_from_single_reads.R"






rule summary:
    input:
        paired_reads_no_adapter_truncLen220_tsv = expand(dada2_paired_no_adapter_truncLen220_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        paired_reads_with_adapter_truncLen220_tsv = expand(dada2_paired_with_adapter_truncLen220_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        single_filter_reads_tsv = expand(dada2_single_filter_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),

    output:
        paired_reads_no_adapter_truncLen220_tsv = summary_output + "/paired_reads_no_adapter_truncLen220.tsv",
        paired_reads_with_adapter_truncLen220_tsv = summary_output + "/paired_reads_with_adapter_truncLen220.tsv",
        single_filter_reads_tsv = summary_output + "/single_filter_reads.tsv",
    script:
        "scripts/python/dada2_summary.py"





