"""
name: quality control
date: 2022-11-27
description: Snakemake pipeline to do quality control, assembly, summary assembly quality
author: Jianmin Xie
dependencies:
    - parsnp = 1.7.4,
    - harvesttools = ?
rules:
    - parsnp


"""

SAMPLE = ["Pha"]
PARSNP_OUT_PATH = "population_structure/parsnp_output"
ClonalFrameML_OUT_PATH = "population_structure/ClonalFrameML_output/mafft"

shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand("{sample}/" + PARSNP_OUT_PATH, sample=SAMPLE),
        # expand("{sample}/" + ClonalFrameML_OUT_PATH, sample=SAMPLE),

rule parsnp:
    input:
        "{sample}/genome/genome_upper_L1000C10"
    output:
        directory("{sample}/" + PARSNP_OUT_PATH)
    threads: 32
    shell:
        "parsnp -r ! -d {input} -c -o {output} -p {threads} -n mafft --vcf --skip-phylogeny;"
        "harvesttools -x {output}/parsnp.xmfa -M {output}/parsnp.fasta;" #convert xmfa to fasta alignment
        "sed -i 's/.fasta//' {output}/parsnp.fasta" #Each title of seq must be identical to leaf name in tree file



rule clonalframeml:
    input:
        xmfa = "{sample}/" + PARSNP_OUT_PATH + "/parsnp.fasta",
        tree = "{sample}/tree/Pha_rerooted_newick.txt"
    output:
        directory("{sample}/" + ClonalFrameML_OUT_PATH)

    shell:
        #SequenceHeader: make sure that the name of header lines in XMFA file is the same as tree file
        "ClonalFrameML {input.tree} {input.xmfa} {output}"






