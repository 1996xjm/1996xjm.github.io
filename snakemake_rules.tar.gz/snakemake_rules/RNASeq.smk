"""
name: RNASeq
date: 2023-04-20
description: Snakemake pipeline to do RNASeq
author: Jianmin Xie
dependencies:
    - fastp = 0.23.2
    - samtools = 1.17
    - hisat2 = 2.2.1
    - htseq = 2.0.2 # 速度慢 不支持多线程
    - subread # featureCounts is in this package 速度快 支持多线程
    - r-base = 4.3.1
    - bioconductor-deseq2 = 1.40.2

rules:
    - fastp
    - hisat2
    - htseq
    - featureCounts


"""

import os
from os import path
import pandas as pd

configfile: "configs/RNASeq_config.yaml"

reads_dir = config["reads_dir"]
ref_genome = config["ref_genome"]
gff = config["gff"]
env_name = config["env_name"]

SAMPLE = os.listdir(reads_dir)
SAMPLE.sort()
hisat2_OUT_PATH = "hisat2_output"
htseq_table = "htseq_table"
featureCounts_table = "featureCounts_table"
hisat2_prefix = ".".join(path.basename(ref_genome).split(".")[:-1])
mergeOutputList = ["all_condition", "all_condition_R", "RPKM_table"]

shell.executable('/bin/zsh') # set a shell to run commands

module fastp_module:
    snakefile: "modules/fastp_module.smk"
    config: config["fastp_config"]

# 使用fastp模块
use rule fastp from fastp_module as my_fastp


rule all:
    input:
        "summary/hisat2_alignment_rate.txt",
        "summary/featureCounts_summary.tsv",
        "summary/featureCounts_summary_R.png",
        "summary/all_condition_R.png",
        # expand(featureCounts_table + "/{sample}/{sample}_count.tsv", sample=SAMPLE),
        expand("express_table/{item}.tsv", item=config["condition_list"]+mergeOutputList),
        expand("different_express_gene_table/{condition}/{condition}_{file}.tsv", condition=config["condition_list"], file=['dif', 'significant_dif', 'rlog', 'chiplot_dif', 'significant_gff'])
    default_target: True


rule build_index:
    input:
        ref_genome
    output:
        ensure(f'hisat2_index/{hisat2_prefix}.1.ht2', non_empty=True)
    params:
        out = f'hisat2_index/{hisat2_prefix}'
    log:
        "logs/build_index/build_index.log"
    conda:
        env_name
    shell:
        "hisat2-build {input} {params.out} &> {log}"

# mapping
rule hisat2:
    params:
        index = rules.build_index.params.out
    input:
        r1 = rules.my_fastp.output.r1,
        r2 = rules.my_fastp.output.r2,
        hisat2_index = rules.build_index.output
    output:
        sam = temp(hisat2_OUT_PATH + "/{sample}/{sample}.sam"),
        summary = hisat2_OUT_PATH + "/{sample}/{sample}.summary"
    log:
        "logs/hisat2/{sample}_hisat2.log"
    benchmark:
        "benchmarks/hisat2/{sample}_benchmark.txt"
    threads: 36
    conda:
        env_name
    shell:
        "hisat2 -p {threads} "
        "-x {params.index} "
        "-1 {input.r1} "
        "-2 {input.r2} "
        "-S {output.sam} "
        "--summary-file {output.summary} "
        "&> {log}"

# 统计mapping比例
rule alignment_rate:
    input:
        expand(hisat2_OUT_PATH + "/{sample}/{sample}.summary",sample=SAMPLE)
    output:
        "summary/hisat2_alignment_rate.txt"
    shell:
        "grep 'overall alignment rate' {input} | sed 's#hisat2_output/.*/##' | sed 's/:/:    /' &> {output}"

# 排序与压缩
rule samtools:
    input:
        rules.hisat2.output.sam
    output:
        hisat2_OUT_PATH + "/{sample}/{sample}.sort.bam"
    params:
        prefix="{sample}.sort.bam.temp"
    log:
        "logs/samtools/{sample}_samtools.log"
    threads: 24
    conda:
        env_name
    shell:
        "samtools sort -O BAM -o {output} -@ {threads} -m 2G -T {params.prefix} {input} &> {log}"

# 定量 1
# rule htseq:
#     input:
#         rules.samtools.output
#     output:
#         htseq_table + "/{sample}/{sample}_count.tsv"
#     params:
#         gff = gff
#     log:
#         htseq_table + "/{sample}/{sample}_htseq.log"
#     shell:
#         "htseq-count -f bam -r pos "
#         "--max-reads-in-buffer 5000000 " # 不够会报错
#         "--stranded no "
#         "--minaqual 10 " # 错误率为1%
#         "--type CDS " # 指定GTF/GFF注释中的要素类型
#         "--idattr ID --mode union " # 数count的模式
#         "--nonunique none " # 对未唯一对齐或分配不明确的reads的计数，全部不要
#         "--secondary-alignments ignore " # 对第二优的对齐的计数忽略
#         "--supplementary-alignments ignore " # 是否进行补充比对
#         "--counts_output {output} "
#         "{input} "
#         "{params.gff} &> {log}"

# 定量 2 速度快
rule featureCounts:
    input:
        rules.samtools.output
    output:
        tsv = featureCounts_table + "/{sample}/{sample}_count.tsv",
        summary = featureCounts_table + "/{sample}/{sample}_count.tsv.summary"
    params:
        gff = gff
    log:
        "logs/featureCounts/{sample}_featureCounts.log"
    threads: 24
    conda:
        env_name
    shell:
        "featureCounts -t CDS -g ID -Q 10 --primary "
        "-R BAM "
        "-s 0 -p -T {threads} "
        "-a {params.gff} "
        "-o {output.tsv} "
        "{input} &> {log}"

# -t CDS 指定GTF注释中的要素类型，这里指定的是CDS
# -g gene_id 输出文件的行名
# -Q 10 错误率10%
# --primary   只数最优的
# -R BAM Output detailed assignment results for each read or read-pair, 会在BAM文件里标明这条reads的匹配类型
# -s 0 链特异性
# -p 双端
# -T 1 CPU
# -a gtf文件
# -o 输出文件
# 可以输入多个bam文件，会直接整合到一个表达矩阵


rule featureCounts_summary:
    input:
        expand(featureCounts_table + "/{sample}/{sample}_count.tsv.summary", sample=SAMPLE)
    output:
        "summary/featureCounts_summary.tsv",
        "summary/featureCounts_summary_R.tsv",
    script:
        "scripts/python/featureCounts_summary.py"


rule plot_featureCounts_summary:
    input:
        rules.featureCounts_summary.output[1]
    output:
        "summary/featureCounts_summary_R.png"
    conda:
        env_name
    script:
        "scripts/R/plot_featureCounts_summary.R"

# 统计表达矩阵
rule mergeExpressCount:
    input:
        expand(featureCounts_table + "/{sample}/{sample}_count.tsv", sample=SAMPLE)
    output:
        expand("express_table/{condition}.tsv", condition=config["condition_list"] + mergeOutputList)
    params:
        dir = "express_table",
        sample_list = SAMPLE,
        condition_list = config["condition_list"]
    script:
        "scripts/python/mergeExpressCount.py"



rule plot_all_condition_featureCounts:
    input:
        "express_table/all_condition_R.tsv"
    output:
        "summary/all_condition_R.png"
    conda:
        env_name
    script:
        "scripts/R/plot_all_condition.R"

rule DESeq2:
    input:
        "express_table/{condition}.tsv"
    output:
        "different_express_gene_table/{condition}/{condition}_dif.tsv",
        "different_express_gene_table/{condition}/{condition}_significant_dif.tsv",
        "different_express_gene_table/{condition}/{condition}_rlog.tsv",
        "different_express_gene_table/{condition}/{condition}_chiplot_dif.tsv",
        "different_express_gene_table/{condition}/{condition}_significant_gff.tsv",
    params:
        gff = gff
    conda:
        env_name
    script:
        "scripts/R/DESeq2.R"
