import http.cookiejar, urllib.request, urllib.parse
import json
import math
import sys
from urllib.error import HTTPError
import time
from Bio import SeqIO
import os
from os import path
import re
from multiprocessing import Pool # 真正并行的多进程
import getpass
from lxml import etree
import datetime
from subprocess import *


class EZ:
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    login_page_url = "https://www.ezbiocloud.net/login"
    login_url = "https://www.ezbiocloud.net/user/login"
    submit_data_url = "https://www.ezbiocloud.net/cl16s/submit_identify_data"
    get_jobs_url = "https://www.ezbiocloud.net/cl16s/get_user_jobs"
    delete_jobs_url = "https://www.ezbiocloud.net/cl16s/delete_jobs"

    def __init__(self, baseDir, puppeteer_js, username, password):
        self.baseDir = baseDir
        self.puppeteer_js = puppeteer_js
        self.username = username
        self.password = password
        self.c_step = 10
        self.ez_temp = path.join(self.baseDir,"ez_temp")
        self.seq_spec_temp_dir = path.join(self.baseDir, "seq_spec_temp")
        self.seq_taxon_temp_dir = path.join(self.baseDir, "seq_taxon_temp")
        self.seq_taxon_updated_temp_dir = path.join(self.baseDir, "seq_taxon_updated_temp")

        for temp_dir in [self.ez_temp, self.seq_spec_temp_dir, self.seq_taxon_temp_dir, self.seq_taxon_updated_temp_dir]:
            if not path.exists(temp_dir):
                os.makedirs(temp_dir)






    def login(self):

        cmd_parms = [
            "node",
            self.puppeteer_js,
            self.username,
            self.password
        ]
        print(" ".join(cmd_parms))
        res = run(cmd_parms, stdout=PIPE, stderr=PIPE)
        print(res.stderr.decode())
        if res.returncode !=0:
            sys.exit()
        else:
            self.Cookie = res.stdout.decode().strip()






    def check_status(self, fastaFile):
        records = SeqIO.parse(fastaFile, "fasta")
        records = list(records)
        count = 0
        flag = 0

        print("## seq length: ", len(records))

        if path.exists(path.join(self.ez_temp,"ez_status.json")):
            with open(path.join(self.ez_temp,"ez_status.json"), "r") as f:
                statusDict = json.load(f)
                count = statusDict.get("count",0)
                flag = statusDict.get("flag",0)

        if count < len(records):
            self.login()
            self.deleteAllJobs()
            return (records,count,flag)
        else:
            self.mergeSeq()
            sys.exit()


    def submitData(self, fastaFile, uploadCount):


        records,count,flag = self.check_status(fastaFile)
        print("## uploading....")
        count_per_upload = uploadCount
        while count < len(records):
            formData = {
                "jsonStr": []
            }
            for i in range(flag*count_per_upload, (flag+1)*count_per_upload):


                rec = records[i]
                seq_obj = {
                    "strain_name":rec.id,
                    "ssurrn_seq":str(rec.seq)
                }
                formData["jsonStr"].append(seq_obj)
                count += 1
                print(rec.id)
                if count == len(records):
                    break
            formDataBytes = urllib.parse.urlencode(formData).encode("utf-8")
            req = urllib.request.Request(self.submit_data_url, formDataBytes)
            req.add_header('User-Agent',
                           'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36')
            req.add_header('Content-Type', 'application/x-www-form-urlencoded')
            req.add_header('Cookie', self.Cookie)


            res = self.opener.open(req)
            print(datetime.datetime.now(), res.status)
            if res.status == 202:
                print("Cookie error!")
                sys.exit()
                return
            json_data = json.loads(res.read().decode())
            print(datetime.datetime.now(), json_data)
            flag += 1
            if count%self.c_step == 0 or count == len(records):
                idList, getSeqIdList = self.getJobs(count)

                with Pool(self.c_step) as p:
                    # 第二个参数的列表的元素会传给第一个参数的函数
                    p.map(self.getTopHitSeq, getSeqIdList)
                print(">>>>>>>>>>>>> getTopHitSeq successfully")
                with open(path.join(self.ez_temp, "ez_status.json"), "w") as f:
                    json.dump({"count":count,"flag":flag}, f)
                if count != len(records):
                    self.deleteJobs(idList)

    def getTopHitSeq(self, job_id):
        req = urllib.request.Request(f"https://www.ezbiocloud.net/identify/result?id={job_id}")
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        req.add_header('Cookie', self.Cookie)

        response = urllib.request.urlopen(req)
        print(">>>>>>>getTopHitSeq status:", response.status)
        if response.status == 202:
            print("Cookie error!")
            raise ValueError("Invalid status code")
            return
        findall_res = re.findall(r'idResult.init\((.*)\);', response.read().decode())
        if len(findall_res) > 0:
            json_data = json.loads(findall_res[0])
            query_name = json_data["query_name"]
            taxon_status = json_data["hits"][0]["taxon_status"]

            top_hit_taxon_name = json_data["hits"][0]["taxon_name"]

            split_res = json_data["hits"][0]["taxonomy"].split(";")

            split_res = [i for i in split_res if i != ""]
            split_res = [i for i in split_res[:6] if not bool(re.search(r"_.$", i))]

            top_hit_accession = json_data["hits"][0]["accession"]
            top_hit_seq = json_data["hits"][0]["aligned_hseq"].replace("-", "")

            if taxon_status != "PHYLOTYPE":
                # 有种名
                with open(path.join(self.seq_spec_temp_dir, f"{query_name}.fasta"), "w") as f:
                    f.write(f">{top_hit_accession} {top_hit_taxon_name}\n{top_hit_seq}\n")

            with open(path.join(self.seq_taxon_temp_dir, f"{query_name}.fasta"),"w") as f:
                f.write(f">{';'.join(split_res)};\n{top_hit_seq}\n")

        else:
            print(f">>>>>>>>>>>job id: {job_id} no res!")

    def getJobs(self, count):
        req = urllib.request.Request(self.get_jobs_url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        req.add_header('Cookie', self.Cookie)

        res = self.opener.open(req)
        json_data = json.loads(res.read().decode())["data"]
        with open(path.join(self.ez_temp, f"{(math.ceil(count/self.c_step)-1)*self.c_step + 1}-{count}.ez.json"), "w") as f:
            json.dump(json_data, f, indent=4)
        return ([i["sge_job_id"] for i in json_data ], [i["sge_job_id"] for i in json_data if i["result_taxon"] != "No hits found" ])


    def deleteJobs(self, idList):
        formData = {
            "jobs": idList

        }
        formDataBytes = urllib.parse.urlencode(formData).encode("utf-8")
        req = urllib.request.Request(self.delete_jobs_url, formDataBytes)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        req.add_header('Cookie', self.Cookie)
        while True:
            try:
                res = self.opener.open(req)
                json_data = json.loads(res.read().decode())
                print(json_data)
                break
            except HTTPError as e:
                print(e)
                print(e.fp.read().decode())
                time.sleep(1)


    def deleteAllJobs(self):
        req = urllib.request.Request(self.get_jobs_url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        req.add_header('Cookie', self.Cookie)
        try:
            res = self.opener.open(req)
            print(">>>>>>>>>> deleteAllJobs:", res.status)
            if res.status == 202:
                print("Cookie error!")

                sys.exit()
                return
        except HTTPError as e:
            print(e.fp.read().decode())
        json_data = json.loads(res.read().decode())["data"]

        idList =  [i["sge_job_id"] for i in json_data]
        self.deleteJobs(idList)

    def updateTax(self, name, genus):
        query = urllib.parse.urlencode({"name": genus})

        url = f"https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?mode=Undef&{query}&lvl=3&lin=f&keep=1&srchmode=1&unlock"
        req = urllib.request.Request(url)
        res = self.opener.open(req)
        html = etree.HTML(res.read().decode())
        # item_value = html.xpath("//a[contains(@href,'Undef')]/text()")
        item_value = html.xpath(
    "//a[@title='family'"
    " or @title='order'"
    " or @title='class'"
    " or @title='phylum'"
    " or @title='domain']/text()"
)
        if len(item_value) == 0:
            return None
        item_value.append(genus)

        tax_str = (";".join(item_value)+";").replace("Candidatus ","")
        print(name,genus,": ",tax_str)
        return tax_str


    def mergeSeq(self):
        for seq in sorted(os.listdir(self.seq_taxon_temp_dir), key=lambda x: int(x.split('_')[1].split('.')[0])):
            out_file = path.join(self.seq_taxon_updated_temp_dir, seq)
            if not path.exists(out_file):
                record = SeqIO.read(path.join(self.seq_taxon_temp_dir,seq),"fasta")
                genus = record.id.split(";")[-2].split("_")[0]
                new_tax = self.updateTax(seq, genus)
                if new_tax != None:
                    record.id = new_tax
                record.description = ""
                with open(out_file, "w") as f:
                    SeqIO.write([record],f,"fasta")

        # 不直接用cat 文件太多会报错 Argument list too long
        os.system(f"""find {self.seq_taxon_updated_temp_dir} -name "*.fasta" -exec cat {{}} + > {self.baseDir}/ez_top_hit_taxon.fasta""")
        os.system(f"""find {self.seq_spec_temp_dir} -name "*.fasta" -exec cat {{}} + > {self.baseDir}/ez_top_hit_spec.fasta""")



if __name__ == '__main__':
    with open(snakemake.log[0], 'w') as f:
        # sys.stdout = f
        # sys.stderr = f
        ez = EZ(snakemake.params.out_dir, snakemake.params.puppeteer_js, snakemake.params.username, snakemake.params.password)
        ez.submitData(snakemake.input[0], snakemake.params.step_count)
        ez.mergeSeq()




