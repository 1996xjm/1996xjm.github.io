import pandas as pd
from os import path

def summary(in_tsv_dict, out_tsv_dict):
    """计算每个基因组不同化合物合成的基因数量"""

    df_dict = {}

    df_list = []


    type_list = [i for i in dir(in_tsv_dict) if i.endswith("tsv")]

    feature_list = ["merged", "merged_P", "non_chimeric", "non_chimeric_P", "merged_ASV", "non_chimeric_ASV"]
    for T in type_list:

        merged_data = pd.concat([pd.read_table(file, index_col=0) for file in in_tsv_dict[T]])

        merged_data.to_csv(out_tsv_dict[T], sep="\t")
        df_dict[T] = merged_data
        df_list.append(merged_data)
        dir_name = path.dirname(out_tsv_dict[T])


    # for f in feature_list:
    #     f_se_list = []
    #     for T in type_list:
    #         se = df_dict[T][f]
    #         se.name = T
    #         f_se_list.append(se)
    #     df = pd.concat(f_se_list, axis=1).T
    #     df.index.name = f
    #
    #     df.to_csv(path.join(dir_name, f"{f}.tsv"), sep="\t")


    



if __name__ == '__main__':
    summary(snakemake.input, snakemake.output)