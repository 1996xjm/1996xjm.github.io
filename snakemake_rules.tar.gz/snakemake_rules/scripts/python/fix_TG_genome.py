from Bio import SeqIO
import pandas as pd
from log import Log
import os



def fix(input, output, logPath):
    log_f = open(logPath, "w")
    df_gff = pd.read_table(input[1], header=None)
    df_gff[3] = df_gff[3].astype(int)
    df_gff[4] = df_gff[4].astype(int)
    df_gff = df_gff.groupby(by=0)

    records = SeqIO.parse(input[0], "fasta")
    records_list = []
    for rec in records:



        topology_description = rec.description.split(" ")[-1]

        if "topology" not in topology_description:
            raise ValueError("Can not find topology description!")


        if "circular" in topology_description:

            Log.info(f"fix {rec.id}.", log_f)
            contig_id = rec.id
            group = df_gff.get_group(contig_id)
            row_index = 0
            # 寻找第一个间隔区
            while row_index < group.shape[0]-1:
                if group.iloc[row_index, :][4] < group.iloc[row_index + 1, :][3]:
                    end_gene_info = group.iloc[row_index].to_csv(sep='\t')#间隔区前面的基因
                    Log.info(f"found end gene:\n######\n{end_gene_info}######", log_f)
                    end = group.iloc[row_index, :][4]
                    rec.seq = rec.seq[end:] + rec.seq[0:end]
                    break
                row_index += 1

            if row_index == group.shape[0]-1:
                Log.warning("There is no end gene!", log_f)
        else:
            Log.warning(f"{rec.id}: This seq is not circular!", log_f)

        records_list.append(rec)
    with open(output, "w") as f:
        SeqIO.write(records_list, f, "fasta")
    log_f.close()


if __name__ == '__main__':
    # input 不支持字典 还是列表
    fix(snakemake.input, snakemake.output[0], snakemake.log[0])