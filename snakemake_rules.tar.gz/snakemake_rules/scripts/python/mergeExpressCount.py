import pandas as pd
import os
from os import path
def mergeExpressCount(countTSVList, condition_name_list, sample_list, output_dir):
    count_list = []

    condition_list = []
    for condition in condition_name_list:
        [left_sample, right_sample] = condition.split("_vs_")
        cols = [i for i in sample_list if i.startswith(left_sample)] + [i for i in sample_list if i.startswith(right_sample)]
        condition_list.append({
            "name": condition,
            "cols": cols
        })

    # print(condition_list)

    os.makedirs(output_dir,exist_ok=True)
    for i,sample in enumerate(sample_list):
        df = pd.read_table(countTSVList[i],skiprows=1,index_col=0)
        col_count = df.iloc[:, -1]
        col_count.name = sample
        count_list.append(col_count)
        gene_length = df.iloc[:, -2]
    final_df = pd.concat(count_list,axis=1)

    final_df.to_csv(path.join(output_dir,"all_condition.tsv"),sep="\t")

    # R 绘图数据
    final_df_R = pd.melt(final_df, var_name='Samples', value_name='Value')
    final_df_R.to_csv(path.join(output_dir,"all_condition_R.tsv"), sep="\t", index=False)

    # 计算RPKM
    RPKM_table = final_df.divide(gene_length,axis=0).divide(final_df.sum(),axis=1) * 10 ** 9
    RPKM_table.to_csv(path.join(output_dir,"RPKM_table.tsv"),sep="\t")
    # print(RPKM_table)



    for cond in condition_list:
        new_df = final_df[cond["cols"]]
        new_df = new_df[~(new_df == 0).all(axis=1)]
        # print(new_df)
        new_df.to_csv(path.join(output_dir,f"{cond['name']}.tsv"),sep="\t")



if __name__ == '__main__':
    mergeExpressCount(snakemake.input, snakemake.params.condition_list, snakemake.params.sample_list, snakemake.params.dir)