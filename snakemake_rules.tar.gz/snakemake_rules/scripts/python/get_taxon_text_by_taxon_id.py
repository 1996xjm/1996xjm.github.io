import urllib
from os import path
from lxml import etree
from log import Log
def get(url_txt, output_txt, logPath, sample):
    log_f = open(logPath, "w")


    with open(url_txt, "r") as f:
        taxId, url = f.read().strip().split("\t")
    Log.info(f"###### {url} ######", log_f)
    response = urllib.request.urlopen(url)


    if response.status == 200:
        html = etree.HTML(response.read())
        item_value = html.xpath("//a[contains(@href,'Undef')]/text()")
        if len(item_value) > 0:
            item_value = [sample, taxId] + item_value
            with open(output_txt, "w") as f:
                f.write("\t".join(item_value) + "\n")
            Log.info(f"status: {response.status} success", log_f)
        else:
            Log.warning(f"status: {response.status} No such taxonomy link!", log_f)
    else:
        Log.warning(f"status: {response.status} Network error!", log_f)

    log_f.close()





if __name__ == '__main__':
    get(snakemake.input[0], snakemake.output[0], snakemake.log[0], snakemake.wildcards.sample)