from os import path
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

from log import Log
import pandas as pd
def extract(gff, genome, output_fasta):
    copy_number = 3
    df = pd.read_table(gff,header=None)
    record_dict = SeqIO.index(genome, "fasta")
    seq_name = df.iloc[copy_number, 0]
    start_p = df.iloc[copy_number, 3]
    end_p = df.iloc[copy_number, 4]
    seq_16S = record_dict.get(seq_name).seq[start_p:end_p + 1]
    strand = df.iloc[copy_number, 6]
    if strand == "-":
        seq_16S = seq_16S.reverse_complement()
    record = SeqRecord(
        seq_16S,
        id=f"{seq_name}:{start_p}-{end_p}({strand})",
        description=""
    )
    with open(output_fasta,"w") as f:
        SeqIO.write([record],f,"fasta")





if __name__ == '__main__':
    extract(snakemake.input.gff[0], snakemake.input.genome, snakemake.output[0])