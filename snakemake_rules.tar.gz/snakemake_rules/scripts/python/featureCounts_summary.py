import pandas as pd

def filterLength(summaryList, outputPath, outputPath_R):
    df_list = [pd.read_table(i, index_col=0) for i in summaryList]
    df = pd.concat(df_list, axis=1)
    new_columns = df.columns.to_series().str.split("/", expand=True)[1].to_list()
    df.columns = new_columns
    # 滤掉全为0的行，转成R绘图的长格式
    df_R = pd.melt(df[df.any(axis=1)], var_name='Samples', value_name='Value', ignore_index=False)
    df_R.to_csv(outputPath_R, sep="\t")

    df.loc["Assigned rate(%)"] = df.loc["Assigned",:] / df.sum() * 100
    df.to_csv(outputPath, sep="\t")



if __name__ == '__main__':
    filterLength(snakemake.input, snakemake.output[0], snakemake.output[1])