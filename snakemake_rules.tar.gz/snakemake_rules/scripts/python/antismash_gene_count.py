import pandas as pd
import js2py
def geneCount(antismash_regionsJS_list, output, logFile):
    """计算每个基因组不同化合物合成的基因数量"""
    log_f = open(logFile, "w")
    orfs_count_list = []
    products_count_list = []

    for regions_js_path in antismash_regionsJS_list:
        eval_result, js_object = js2py.run_file(regions_js_path)  # 转换js文件
        regions = js_object.all_regions
        regions_name_list = regions.order

        orfs_count_dict = {}
        products_count_dict = {}

        total_orfs_count = 0
        total_products_count = 0

        for reg in regions_name_list:
            total_orfs_count += len(regions[reg].orfs)
            if regions[reg].type in orfs_count_dict:
                orfs_count_dict[regions[reg].type] += len(regions[reg].orfs)
            else:
                orfs_count_dict[regions[reg].type] = len(regions[reg].orfs)

            for pro in regions[reg].products:
                total_products_count += 1
                if pro in products_count_dict:
                    products_count_dict[pro] += 1
                else:
                    products_count_dict[pro] = 1
        # 截取样本名称
        sample_name = regions_js_path.split("/")[-2]
        orfs_count_list.append(pd.DataFrame.from_dict(orfs_count_dict, orient='index', columns=[sample_name]))
        products_count_list.append(pd.DataFrame.from_dict(products_count_dict, orient='index', columns=[sample_name]))
        print(">>>>>>>finished: ", sample_name, file=log_f)
        print("total orfs: ", total_orfs_count, file=log_f)
        print("total products: ", total_products_count, file=log_f)
        print(file=log_f)

    orfs_count_df = pd.concat(orfs_count_list, axis=1).fillna(0).T
    products_count_df = pd.concat(products_count_list, axis=1).fillna(0).T

    orfs_count_df.index.name = "sample"
    products_count_df.index.name = "sample"

    orfs_count_df.to_csv(output.orfs_count, sep="\t")
    products_count_df.to_csv(output.products_count, sep="\t")
    log_f.close()



if __name__ == '__main__':
    geneCount(snakemake.input, snakemake.output, snakemake.log[0])