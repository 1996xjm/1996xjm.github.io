import csv
import os
import re
import sys
from os import path
from bs4 import BeautifulSoup

def contains_any_item(string, items_list):
    for item in items_list:
        if item in string:
            return True
    return False
def get_index_page_table(index_html, output_dir):

    os.makedirs(output_dir, exist_ok=True)

    with open(index_html, "r") as f:
        html_content = f.read()

    # Parse HTML content with BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')

    # Find the table in the HTML
    find_res = soup.find(id="single-record-tables")
    if not find_res:
        return
    contig_name_list = [cell.get_text(strip=True) for cell in find_res.find_all("div", "record-overview-header")]
    table_list = find_res.find_all("table")
    target_type = ["NRPS", "NRPS-like"]

    for t_index, contig_name in enumerate(contig_name_list):
        contig_name = re.sub(r"\\\\.*", "", contig_name)
        table = table_list[t_index]
        # Create a CSV writer for TSV format

        tsv_row_list = []

        # Iterate through rows and columns of the table
        for row in table.find_all('tr'):
            # Extract data from each cell in the row
            row_data = [cell.get_text(strip=True).replace("&nbsp", " ") for cell in row.find_all(['th', 'td'])]
            if row_data[0] != "Region" and not contains_any_item(row_data[1], target_type):
                continue

            tsv_row_list.append(row_data)
        if len(tsv_row_list)>1:
            with open(path.join(output_dir, f'{contig_name}.tsv'), 'w', newline='', encoding='utf-8') as tsv_file:
                tsv_writer = csv.writer(tsv_file, delimiter='\t')
                tsv_writer.writerows(tsv_row_list)

            print(f'Table successfully parsed and saved as {contig_name}.tsv')


def get_index_page_table1(index_html, output_dir, sample):
    """不区分contig"""

    os.makedirs(output_dir, exist_ok=True)

    with open(index_html, "r") as f:
        html_content = f.read()

    # Parse HTML content with BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')

    # Find the table in the HTML
    find_res = soup.find(id="single-record-tables")
    if not find_res:
        return
    table_list = find_res.find_all("tbody")
    target_type = ["NRPS", "NRPS-like"]

    tsv_row_list = [["Region", "Type", "From", "To", "Most similar known cluster", "Description", "Similarity"]]

    for table in table_list:
        # Iterate through rows and columns of the table
        for row in table.find_all('tr'):
            # Extract data from each cell in the row
            row_data = [cell.get_text(strip=True).replace("&nbsp", " ") for cell in row.find_all('td')]

            if contains_any_item(row_data[1], target_type):
                tsv_row_list.append(row_data)
    if len(tsv_row_list)>1:
        with open(path.join(output_dir, f"{sample}.tsv"), 'w', newline='', encoding='utf-8') as tsv_file:
            tsv_writer = csv.writer(tsv_file, delimiter='\t')
            tsv_writer.writerows(tsv_row_list)

        print(f'Table successfully parsed and saved as {output_dir}')



if __name__ == '__main__':
    with open(snakemake.log[0], 'w') as f:
        sys.stdout = f
        sys.stderr = f
        get_index_page_table1(snakemake.input[0], snakemake.output[0], snakemake.wildcards.sample)