from Bio.Phylo.PAML import yn00
import pandas as pd
import os

# === Step 1. 读取 yn00 输出文件 ===
results = yn00.read(snakemake.input[0])

# === Step 2. 为每个基因生成 pairwise NG86 表格 ===
# results 是一个 dict，形如 results[gene_id][seq1][seq2]["NG86"] = {...}

# output_dir = "pairwise_results"
# os.makedirs(output_dir, exist_ok=True)
rows = []
for seq1, gene_data in results.items():
    for seq2, methods in gene_data.items():
        if "NG86" in methods:
            ng86 = methods["NG86"]
            dN = ng86.get("dN", None)
            dS = ng86.get("dS", None)
            omega = ng86.get("omega", None)
            rows.append({
                "Seq1": seq1,
                "Seq2": seq2,
                "dN": dN,
                "dS": dS,
                "omega": omega
            })
    # === Step 3. 输出成 tsv 文件 ===
if rows:
    df = pd.DataFrame(rows)
    # out_path = os.path.join(output_dir, f"{gene_id}_pairwise.tsv")
    df.to_csv(snakemake.output[0], sep="\t", index=False)

    df_filtered = df[df['omega'] != -1]
    result = df_filtered.groupby('Seq1', as_index=False)['omega'].mean()
    result['sample'] = result['Seq1'].apply(lambda x: '_'.join(x.split('_')[:2]))
    result.set_index('sample', inplace=True)
    result.to_csv(snakemake.output[1], sep="\t")
