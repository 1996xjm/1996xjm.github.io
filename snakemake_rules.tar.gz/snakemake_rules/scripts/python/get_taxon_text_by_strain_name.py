import urllib
from os import path
from lxml import etree
from log import Log
def get(strain_name, output_txt, sample):

    from lxml import etree
    name = urllib.parse.urlencode({"name": strain_name})
    url = f"https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?mode=Undef&{name}&lvl=3&lin=f&keep=1&srchmode=1&unlock"
    res = urllib.request.urlopen(url)

    try:
        decode = res.read().decode()
    except Exception as e:
        print(e)
        decode = e.partial.decode()

    html = etree.HTML(decode)
    item_value = html.xpath("//a[contains(@href,'Undef')]/text()")
    item_value = [sample] + item_value
    with open(output_txt, "w") as f:
        f.write("\t".join(item_value) + "\n")






if __name__ == '__main__':
    get(snakemake.params.name, snakemake.output[0], snakemake.wildcards.sample)