import pandas as pd
import os
from os import path
def mergeExpressCount(flagstat_list, coverage_list, out_file):
    data_dict = {
        "Sample":[],
        "Genome_length":[],
        "Total_reads":[],
        "Mapped_reads":[],
        "Covbases":[],
    }
    for file in flagstat_list:
        with open(file,"r") as f:
            total_reads = int(f.readline().strip().split(" ")[0])
            data_dict["Sample"].append(file.split("/")[1])
            data_dict["Total_reads"].append(total_reads)
    for file in coverage_list:
        df = pd.read_table(file, index_col=0)
        df_sum = df.sum()
        data_dict["Genome_length"].append(df_sum["endpos"])
        data_dict["Mapped_reads"].append(df_sum["numreads"])
        data_dict["Covbases"].append(df_sum["covbases"])

    f_df = pd.DataFrame(data_dict)

    f_df["RPKM"] = f_df["Mapped_reads"]/f_df["Genome_length"]/f_df["Total_reads"] * 1e9
    f_df.to_csv(out_file,sep="\t",index=None)





if __name__ == '__main__':
    mergeExpressCount(snakemake.input["flagstat_list"],snakemake.input["coverage_list"], snakemake.output[0])