import sys
import pandas as pd
import gzip

vcf_file = snakemake.input.vcf
cov_file = snakemake.input.cov
out_file = snakemake.output[0]

# 读取 coverage.tsv
cov = pd.read_csv(cov_file, sep="\t")
cov = cov.rename(columns={cov.columns[0]: "contig"})  # 第一列是contig ID
cov["Type"] = cov["contig"].apply(lambda x: "chromosome" if "chromosome" in x.lower() else "plasmid")

# 统计突变数
mut_counts = {}
open_func = gzip.open if vcf_file.endswith(".gz") else open
with open_func(vcf_file, "rt") as f:
    for line in f:
        if line.startswith("#"):
            continue
        parts = line.strip().split("\t")
        contig = parts[0]
        mut_counts[contig] = mut_counts.get(contig, 0) + 1

# 合并
cov["Mutations"] = cov["contig"].map(mut_counts).fillna(0).astype(int)
cov["Density"] = cov["Mutations"] / cov["endpos"]  # 假设 coverage.tsv 有 length 列

# 保存
cov.to_csv(out_file, sep="\t", index=False)
