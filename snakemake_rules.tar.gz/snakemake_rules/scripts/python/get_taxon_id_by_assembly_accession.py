import urllib
# from os import path
# from lxml import etree
import re
from log import Log



# 新网站方法
def get_new_version(accession, output_txt, logPath):
    assembly_url = f"https://www.ncbi.nlm.nih.gov/datasets/genome/{accession}"
    log_f = open(logPath, "w")
    Log.info(f"###### {assembly_url} ######", log_f)
    response = urllib.request.urlopen(assembly_url)

    if response.status == 200:
        html = response.read().decode()
        pattern = r'pageData\.taxId = "(\d+)"'
        match = re.search(pattern, html)
        if match:
            taxId = match.group(1)
            with open(output_txt, "w") as f:
                f.write(f"{taxId}\thttps://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id={taxId}&mode=info")
            Log.info(f"status: {response.status} success", log_f)
        else:
            Log.warning(f"status: {response.status} No such taxonomy link!", log_f)

    else:
        Log.warning(f"status: {response.status} Network error!", log_f)

    log_f.close()





if __name__ == '__main__':
    get_new_version(snakemake.params.accession, snakemake.output[0], snakemake.log[0])