library(DESeq2)
library("rtracklayer") # 读取gff
library(data.table)
#说明文档 http://bioconductor.org/packages/devel/bioc/vignettes/DESeq2/inst/doc/DESeq2.html
do_diff <- function(count_table_path, dif_out_path, significant_dif_out_path, rlog_out_path, chiplot_dif_out_path) {

count_df <- read.table(count_table_path, fill = T, check.names = F, row.names = 1, header=T, sep="\t")
# 过滤每一行总和>20 且都大于0
  count_df.filter <- count_df[rowSums(count_df) > 20 & apply(count_df,1, function (x){ all(x>0) }),]

  sample_df <- data.frame(
  condition = c(rep("A", 3), rep("B", 3)),
  kkk = "kkk"
)# 是按照字母顺序来算foldChange的 这样就是B/A
rownames(sample_df) <- colnames(count_df.filter)

deseq2.obj <- DESeqDataSetFromMatrix(countData = count_df.filter, colData = sample_df, design = ~condition)

dif_res <- results(DESeq(deseq2.obj))
dif_res.df <- as.data.frame(dif_res)

  dif_res.chiplot_df = dif_res.df[, c("log2FoldChange", "padj")]
  # 过滤NA 一般都是因为平行出现异常值
  dif_res.chiplot_df = dif_res.chiplot_df[!is.na(dif_res.chiplot_df$padj),]


write.table(cbind(gene_id=rownames(dif_res.df),dif_res.df), file = dif_out_path, sep = "\t", quote = F, row.names = F)
write.table(cbind(gene_id=rownames(dif_res.chiplot_df),dif_res.chiplot_df), file = chiplot_dif_out_path, sep = "\t", quote = F, row.names = F)

rld <- rlog(deseq2.obj)
ll = assay(rld)
# p = plotPCA(rld, returnData = F)
# write.table(p[["data"]], file = "/Users/xjm/Desktop/CYR/PT1_trn/express_table/PCA_rlog.tsv", sep = "\t", quote = F, col.names = NA)
# write.table(t(ll), file = rlog_out_path, sep = "\t", quote = F, col.names = NA) #转置
write.table(cbind(gene_id=rownames(ll),ll), file = rlog_out_path, sep = "\t", quote = F, row.names = F)

  # 筛选差异表达基因 log2FoldChange >= 1, padj <= 0.05且padj不为空
  dif_res.signif_df = dif_res.df[(abs(dif_res.df$log2FoldChange) >= 1) & (!is.na(dif_res.df$padj)) & (dif_res.df$padj <= 0.05),]

  write.table(cbind(gene_id=rownames(dif_res.signif_df),dif_res.signif_df), file = significant_dif_out_path, sep = "\t", quote = F, row.names = F)
  return(rownames(dif_res.signif_df))
}

grep_gff = function (gff_path, gene_ids, significant_gff_out_path){
  # 读取 GFF 文件
  gff = import(gff_path)
  gff = as.data.frame(gff)

  result_df <- gff[gff$ID %in% gene_ids,]

  # 输出查找到的结果
  fwrite(result_df, file = significant_gff_out_path, sep = "\t", quote = F, col.names = TRUE, row.names = FALSE)

}

gene_ids = do_diff(snakemake@input[[1]], snakemake@output[[1]], snakemake@output[[2]], snakemake@output[[3]], snakemake@output[[4]])
grep_gff(snakemake@params[["gff"]], gene_ids, snakemake@output[[5]])
