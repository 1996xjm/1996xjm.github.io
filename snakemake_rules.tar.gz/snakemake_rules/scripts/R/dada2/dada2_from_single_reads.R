## capture all the output to a file.
log <- file(snakemake@log[[1]], open="wt")
sink(log) #redirect stdout
sink(log, type = "message") #redirect stderr
library(dada2)
library(ShortRead) # 读写序列



do_dada2 = function (cr1_file_path, fq_file_path, rep_seqs_nochim_file, tsv_path, sample_name, is_filter = 0, minFoldParentOverAbundance = 1.5){

  # Get the count of reads from a FASTQ file
  reads_count <- countFastq(cr1_file_path)
  reads_count <- reads_count$records



  fnFs <- c(fq_file_path)
  if (is_filter == 1) {
    out_dir = dirname(rep_seqs_nochim_file)

    filtFs = c(file.path(out_dir, paste(sample_name, "_filt.fq.gz")))

    print(filtFs)

    out_2 <- filterAndTrim(fnFs, filtFs, truncLen=0,
                               maxN=0, maxEE=2, truncQ=2, rm.phix=TRUE,
                               compress=TRUE, multithread=TRUE, verbose=TRUE)
    print(out_2)
    fnFs = filtFs
  }




  errF <- learnErrors(fnFs, multithread=TRUE)


  dadaFs <- dada(fnFs, err=errF, multithread=TRUE)



  seqtab <- makeSequenceTable(dadaFs)


  print(minFoldParentOverAbundance)


  seqtab.nochim <- removeBimeraDenovo(seqtab, method="consensus", multithread=TRUE, verbose=TRUE, minFoldParentOverAbundance=minFoldParentOverAbundance)


  df <- data.frame(Sample = sample_name,
                   input = reads_count,
                   merged = sum(seqtab),
                   merged_P = sum(seqtab)/reads_count*100,
                   non_chimeric = sum(seqtab.nochim),
                   non_chimeric_P = sum(seqtab.nochim)/reads_count*100,
                   merged_ASV = dim(seqtab)[2],
                   chimeric_ASV = dim(seqtab)[2] - dim(seqtab.nochim)[2],
                   non_chimeric_ASV = dim(seqtab.nochim)[2]

  )

  print(df)
  write.table(df, file = tsv_path, sep = "\t", quote = F, row.names = FALSE)

  # 导出序列
  seq_nochim = getSequences(seqtab.nochim)
  names(seq_nochim) <- paste0(sample_name, "_ASV_", seq_along(seq_nochim))

  writeFasta(seq_nochim, rep_seqs_nochim_file)



}

do_dada2(snakemake@input[["cr1"]], snakemake@input[["merged_seq"]], snakemake@output[["rep_seqs"]], snakemake@output[["tsv"]], snakemake@params[["sample_name"]], snakemake@params[["is_filter"]], snakemake@params[["minFoldParentOverAbundance"]])



