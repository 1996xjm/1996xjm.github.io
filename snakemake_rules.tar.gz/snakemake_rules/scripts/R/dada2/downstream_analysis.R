## capture all the output to a file.
log <- file(snakemake@log[[1]], open="wt")
sink(log) #redirect stdout
sink(log, type = "message") #redirect stderr

library(ggplot2)
library(phyloseq) #下游分析
library(dplyr) # 数据框分组聚合
library(phangorn) # 进化树

do_dada2 = function (
  phyloseq_object_file,
  tree_file,
  seq_table_prop_no_chloro_mito_file,
  prevalence_totalAbundance_table,
  alpha_diversity_tsv,
  alpha_diversity_fig_dir,
  stacked_bar_plot_table_dir,
  prevalence_fig_dir,
  beta_diversity_table_dir
){

  load(phyloseq_object_file)
  print(ps)

  # 下游分析

  tree <- read_tree(tree_file)

  # The FastTree program creates an unrooted tree, so in the final step in this section midpoint rooting is applied to place the root of the tree at the midpoint of the longest tip-to-tip distance in the unrooted tree.

  midpoint_tree = midpoint(tree)

  ps <- merge_phyloseq(ps, midpoint_tree)


  print(ps)





  # Alpha diversity
  # 辛普森多样性指数是基于在一个无限大的群落中，随机抽取两个个体，它们属于同一物种的概率
  # Simpson's Index: D
  # 这里的Simpson 算的应该是Simpson's Index of Diversity: 1-D
  # InvSimpson是Simpson's Reciprocal Index: 1/D
  # 加了 Fisher 这种算法会报错，原因不明, 应该是某些数值不符合计算要求

  # 可能还是要统一采样，算出来才准
  richness_measures = c("Observed", "Chao1", "ACE", "Shannon", "Simpson","InvSimpson")
  richness = estimate_richness(ps, measures=richness_measures)
  print(richness)

  write.table(cbind(sample=rownames(richness), richness), file = alpha_diversity_tsv, sep = "\t", quote = F, row.names = F)
  dir.create(alpha_diversity_fig_dir)
  for (measures in richness_measures){
    r_p = plot_richness(ps, measures=measures)
    ggsave(file.path(alpha_diversity_fig_dir, paste0(measures,".png")), plot = r_p, width = nrow(richness)*5, height = 200, units = "mm", dpi = 300, limitsize = FALSE)

  }

  # Transform data to proportions as appropriate for Bray-Curtis distances
  ps.prop <- transform_sample_counts(ps, function(otu) otu/sum(otu))
  write.table(cbind(sample=rownames(ps.prop@otu_table),ps.prop@otu_table), file = seq_table_prop_no_chloro_mito_file, sep = "\t", quote = F, row.names = F)
if(nrow(richness)>2){
  # 超过两个样本才计算beta diversity
  dir.create(beta_diversity_table_dir)
  ord_pcoa_dict <- list(
    ord_pcoa_wunifrac = ordinate(ps.prop, method = "PCoA", distance ="wunifrac"),
    ord_pcoa_unifrac = ordinate(ps.prop, method = "PCoA", distance ="unifrac"),
    ord_pcoa_bray = ordinate(ps.prop, method = "PCoA", distance ="bray")
)
  for (key in names(ord_pcoa_dict)){
    ord_table = ord_pcoa_dict[[key]]$vectors[, c("Axis.1", "Axis.2")]
  write.table(cbind(sample=rownames(ord_table),ord_table), file = file.path(beta_diversity_table_dir, paste0(key, ".tsv")), sep = "\t", quote = F, row.names = F)
  Relative_eig = ord_pcoa_dict[[key]]$values$Relative_eig
  Relative_eig_table = data.frame(type=c("explained variance ratio (%)"), Axis.1=Relative_eig[1]*100, Axis.2=Relative_eig[2]*100)
  write.table(Relative_eig_table, file = file.path(beta_diversity_table_dir, paste0(key, "_explained_variance_ratio.tsv")), sep = "\t", quote = F, row.names = F)

  }

  ord_nmds_dict <- list(
    ord_nmds_bray = ordinate(ps.prop, method="NMDS", distance="bray"),
    ord_nmds_wunifrac = ordinate(ps.prop, method="NMDS", distance="wunifrac"),
    ord_nmds_unifrac = ordinate(ps.prop, method="NMDS", distance="unifrac")
)

  for (key in names(ord_nmds_dict)){

    ord_table = ord_nmds_dict[[key]]$points
  write.table(cbind(sample=rownames(ord_table),ord_table), file = file.path(beta_diversity_table_dir, paste0(key, ".tsv")), sep = "\t", quote = F, row.names = F)
  write.table(data.frame(stress=ord_nmds_dict[[key]]$stress), file = file.path(beta_diversity_table_dir, paste0(key, "_stress.tsv")), sep = "\t", quote = F, row.names = F)


  }

}







  # 堆叠柱状图表格
  ps.prop_100 <- transform_sample_counts(ps, function(otu) otu/sum(otu)*100)
  seqtab.prop_100_no_chim_chloro_mito_T <- as.data.frame(t(ps.prop_100@otu_table))
  taxonomy_levels <- c("Kingdom","Phylum","Class","Order","Family","Genus","Species")

  # 去NA
  taxonomy_table <- as.data.frame(tax_table(ps)) %>% mutate_all(~ifelse(is.na(.), "Unknown", .))
  dir.create(stacked_bar_plot_table_dir)
  for (taxonomy_level in taxonomy_levels) {
    seqtab_taxa = cbind(seqtab.prop_100_no_chim_chloro_mito_T, taxonomy_table[,taxonomy_level])
    colnames(seqtab_taxa)[ncol(seqtab_taxa)] <- taxonomy_level
    bar_plot_table <- seqtab_taxa |>
      group_by(!!sym(taxonomy_level)) |>
      summarise_all(sum) |>
      as.data.frame()
    # Set the taxonomy level as the row names
    rownames(bar_plot_table) <- bar_plot_table[[taxonomy_level]]
    # Remove the taxonomy level column
    bar_plot_table <- bar_plot_table[, -1] |>
      t() |>
      as.data.frame()

    write.table(cbind(sample=rownames(bar_plot_table), bar_plot_table), file = file.path(stacked_bar_plot_table_dir, paste0(taxonomy_level,".tsv")), sep = "\t", quote = F, row.names = F)




}


  # 计算流行度prevalence和总丰度TotalAbundance

## 每个AVS出现在多少个样品中
prevdf = apply(X = otu_table(ps),
               MARGIN = ifelse(taxa_are_rows(ps), yes = 1, no = 2),
               FUN = function(x){sum(x > 0)})

## Add taxonomy and total read counts to this data.frame
prevdf = data.frame(Prevalence = prevdf,
                    TotalAbundance = taxa_sums(ps),
                    taxonomy_table)

write.table(cbind(ASV_id=rownames(prevdf), prevdf), file = prevalence_totalAbundance_table, sep = "\t", quote = F, row.names = F)

  dir.create(prevalence_fig_dir)
  for (taxonomy_level in taxonomy_levels[-7]) {
    sqrt_res = ceiling(sqrt(length(get_taxa_unique(ps,taxonomy_level))))
prev_plot = ggplot(prevdf, aes(TotalAbundance, Prevalence / nsamples(ps),color=!!sym(taxonomy_level))) +
  # Include a guess for parameter
  geom_hline(yintercept = 0.05, alpha = 0.5, linetype = 2) + geom_point(size = 2, alpha = 0.7) +
  scale_x_log10() +  xlab("Total Abundance of each ASV") + ylab("Prevalence [Frac. Samples]") +
  facet_wrap(c(taxonomy_level), ncol=sqrt_res) + theme(legend.position="none") +
  ggtitle(paste0("Taxonomy level: ", taxonomy_level))


    fig_height = sqrt_res * 80
    fig_width = sqrt_res * 80
    if(fig_height<300){
      fig_height = 300
    }
    if(fig_width<300){
      fig_width = 300
    }
    print(paste0(">>>>>>>>>fig_height: ", taxonomy_level, " # ", fig_height))

ggsave(file.path(prevalence_fig_dir, paste0(taxonomy_level, ".png")), plot = prev_plot, width = fig_width, height = fig_height, units = "mm", dpi = 300, limitsize = FALSE)

  }




}

do_dada2(
  snakemake@input[["phyloseq_object_file"]],
  snakemake@input[["tree_file"]],
  snakemake@output[["seq_table_prop_no_chloro_mito"]],
  snakemake@output[["prevalence_totalAbundance_table"]],
  snakemake@output[["alpha_diversity_tsv"]],
  snakemake@params[["alpha_diversity_fig_dir"]],
  snakemake@params[["stacked_bar_plot_table_dir"]],
  snakemake@params[["prevalence_fig_dir"]],
  snakemake@params[["beta_diversity_table_dir"]]
)




