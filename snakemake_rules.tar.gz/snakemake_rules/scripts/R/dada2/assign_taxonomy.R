## capture all the output to a file.
log <- file(snakemake@log[[1]], open="wt")
sink(log) #redirect stdout
sink(log, type = "message") #redirect stderr
library(dada2)
library(ggplot2)
library(ShortRead) # 读写序列
library(phyloseq) #下游分析
library(dplyr) # 数据框分组聚合
library(biomformat) #导出biom格式


do_dada2 = function (
  seq_table_file_path,
  db_taxon_file_path,
  db_spec_file_path,
  rep_seqs_no_chloro_mito_file,
  rep_seqs_with_chloro_mito_file,
  seq_table_no_chloro_mito_file,
  seq_table_no_chloro_mito_biom,
  seq_table_with_chloro_mito_file,
  taxon_no_chloro_mito_tsv,
  taxon_with_chloro_mito_tsv,
  assign_taxonomy_stats_tsv,
  phyloseq_object_file

){

  load(seq_table_file_path)

  print(dim(seqtab.nochim))

  seq_nochim = getSequences(seqtab.nochim)
  paste0Result <- paste0("ASV_", seq_along(seq_nochim))
  names(seq_nochim) <- paste0Result

  taxa_L6 <- assignTaxonomy(seqtab.nochim, db_taxon_file_path, multithread=TRUE)

  taxa_add_L7 <- addSpecies(taxa_L6, db_spec_file_path)

  # 在上面还没算好前不能提前改名字，因为他是靠这个名字的序列去比对的
  rownames(taxa_add_L7) = paste0Result
  colnames(seqtab.nochim) = paste0Result

  # 去除叶绿体和线粒体
  is.chloro <- taxa_add_L7[,"Order"] %in% "Chloroplast"
  is.mito <- taxa_add_L7[,"Family"] %in% "Mitochondria"

  taxa_table_L7_no_chloro_mito = taxa_add_L7[!is.chloro & !is.mito,]

  taxa_table_L7_with_chloro_mito = taxa_add_L7[is.chloro | is.mito,]

  seqtab.no_chim_chloro_mito = seqtab.nochim[,!is.chloro & !is.mito]
  seqtab.with_chim_chloro_mito = seqtab.nochim[,is.chloro | is.mito]

  print(dim(seqtab.no_chim_chloro_mito))
  print(">>>>>>>is.chloro:")
  print(rowSums(seqtab.nochim[,is.chloro]))
  print(">>>>>>is.mito:")
  print(rowSums(seqtab.nochim[,is.mito]))


  # 导出序列
  seq_no_chim_chloro_mito = seq_nochim[!is.chloro & !is.mito]
  seq_with_chloro_mito = seq_nochim[is.chloro | is.mito]


  writeFasta(seq_no_chim_chloro_mito, rep_seqs_no_chloro_mito_file)
  writeFasta(seq_with_chloro_mito, rep_seqs_with_chloro_mito_file)





  # print(taxa_add_L7)
  write.table(cbind(sample=rownames(seqtab.no_chim_chloro_mito),seqtab.no_chim_chloro_mito), file = seq_table_no_chloro_mito_file, sep = "\t", quote = F, row.names = F)
  # biom的格式需要行为ASV, 列为样本
  write_biom(make_biom(as.data.frame(t(seqtab.no_chim_chloro_mito))), seq_table_no_chloro_mito_biom)
  write.table(cbind(sample=rownames(seqtab.with_chim_chloro_mito),seqtab.with_chim_chloro_mito), file = seq_table_with_chloro_mito_file, sep = "\t", quote = F, row.names = F)
  write.table(cbind(ASV_id=rownames(taxa_table_L7_no_chloro_mito),taxa_table_L7_no_chloro_mito), file = taxon_no_chloro_mito_tsv, sep = "\t", quote = F, row.names = F)
  write.table(cbind(ASV_id=rownames(taxa_table_L7_with_chloro_mito), taxa_table_L7_with_chloro_mito), file = taxon_with_chloro_mito_tsv, sep = "\t", quote = F, row.names = F)

  rowSumsResult <- rowSums(seqtab.no_chim_chloro_mito)
  print(">>>>>>rowSums seqtab.no_chim_chloro_mito:")
  print(rowSumsResult)

  input_reads_count = as.numeric(track[,"input"])



  new_colnames = c(colnames(track), "no_chim_chloro_mito", "no_chim_chloro_mito_p", "no_chim_chloro_mito_ASV")

  track <- cbind(track, rowSumsResult, rowSumsResult/input_reads_count*100, rowSums(seqtab.no_chim_chloro_mito > 0))

  colnames(track) = new_colnames

  print(track)

  write.table(track, file = assign_taxonomy_stats_tsv, sep = "\t", quote = F, row.names = F)

  # 下游分析

  ps <- phyloseq(otu_table(seqtab.no_chim_chloro_mito, taxa_are_rows=FALSE),
                 tax_table(taxa_table_L7_no_chloro_mito),
                 Biostrings::DNAStringSet(seq_no_chim_chloro_mito))


  print(ps)

  # 导出特征表
  save(ps, file = phyloseq_object_file)


}

do_dada2(
  snakemake@input[["seq_table"]],
  snakemake@input[["db_taxon"]],
  snakemake@input[["db_spec"]],
  snakemake@output[["rep_seqs_no_chloro_mito"]],
  snakemake@output[["rep_seqs_with_chloro_mito"]],
  snakemake@output[["seq_table_no_chloro_mito"]],
  snakemake@output[["seq_table_no_chloro_mito_biom"]],
  snakemake@output[["seq_table_with_chloro_mito"]],
  snakemake@output[["taxon_no_chloro_mito_tsv"]],
  snakemake@output[["taxon_with_chloro_mito_tsv"]],
  snakemake@output[["stats_tsv"]],
  snakemake@output[["phyloseq_object_file"]]

)




