## capture all the output to a file.
log <- file(snakemake@log[[1]], open="wt")
sink(log) #redirect stdout
sink(log, type = "message") #redirect stderr
library(dada2)
library(ShortRead) # 读写序列



do_dada2 = function (f_fq_file_path, r_fq_file_path, f_fq_filt_file_path, r_fq_filt_file_path, rep_seqs_nochim_file, tsv_path, sample_name, truncLen, minFoldParentOverAbundance = 1.5){

  fnFs <- c(f_fq_file_path)
  fnRs <- c(r_fq_file_path)

  # Extract sample names, assuming filenames have format: SAMPLENAME_XXX.fastq
  sample.names <- sapply(strsplit(basename(fnFs), "_\\d"), `[`, 1)



  # Place filtered files in filtered/ subdirectory
  filtFs <- c(f_fq_filt_file_path)
  filtRs <- c(r_fq_filt_file_path)
  names(filtFs) <- sample.names
  names(filtRs) <- sample.names


  out_2_2_220 <- filterAndTrim(fnFs, filtFs, fnRs, filtRs, truncLen=c(truncLen,truncLen),
                               maxN=0, maxEE=c(2,2), truncQ=2, rm.phix=TRUE,
                               compress=TRUE, multithread=TRUE, verbose=TRUE)

  print(out_2_2_220)

  errF <- learnErrors(filtFs, multithread=TRUE)
  errR <- learnErrors(filtRs, multithread=TRUE)


  dadaFs <- dada(filtFs, err=errF, multithread=TRUE)
  dadaRs <- dada(filtRs, err=errR, multithread=TRUE)

  mergers <- mergePairs(dadaFs, filtFs, dadaRs, filtRs, verbose=TRUE)

  print(mergers)

  seqtab <- makeSequenceTable(mergers)


  print(minFoldParentOverAbundance)

  seqtab.nochim <- removeBimeraDenovo(seqtab, method="consensus", multithread=TRUE, verbose=TRUE, minFoldParentOverAbundance=minFoldParentOverAbundance)


  df <- data.frame(Sample = sample_name,
                   input = out_2_2_220[1,1],
                   merged = sum(seqtab),
                   merged_P = sum(seqtab)/out_2_2_220[1,1]*100,
                   non_chimeric = sum(seqtab.nochim),
                   non_chimeric_P = sum(seqtab.nochim)/out_2_2_220[1,1]*100,
                   merged_ASV = dim(seqtab)[2],
                   chimeric_ASV = dim(seqtab)[2] - dim(seqtab.nochim)[2],
                   non_chimeric_ASV = dim(seqtab.nochim)[2]

  )

  print(df)
  write.table(df, file = tsv_path, sep = "\t", quote = F, row.names = FALSE)

  # 导出序列
  seq_nochim = getSequences(seqtab.nochim)
  names(seq_nochim) <- paste0(sample_name, "_ASV_", seq_along(seq_nochim))

  writeFasta(seq_nochim, rep_seqs_nochim_file)



}

do_dada2(snakemake@input[["r1"]], snakemake@input[["r2"]], snakemake@output[["r1"]], snakemake@output[["r2"]], snakemake@output[["rep_seqs"]], snakemake@output[["tsv"]], snakemake@params[["sample_name"]], snakemake@params[["truncLen"]], snakemake@params[["minFoldParentOverAbundance"]])



