## capture all the output to a file.
log <- file(snakemake@log[[1]], open="wt")
sink(log) #redirect stdout
sink(log, type = "message") #redirect stderr
library(dada2)
library(ShortRead) # 读写序列



do_dada2 = function (cr1_file_path, fq_file_path, rep_seqs_nochim_file, seq_table_file, tsv_path, minFoldParentOverAbundance = 1.5, nbases = 1e8){


  reads_count <- countFastq(as.character(cr1_file_path))$records


  fnFs <- as.character(fq_file_path)
  sample.names <- sapply(strsplit(basename(fnFs), "\\."), `[`, 1)
  print(sample.names)

  out_dir = dirname(rep_seqs_nochim_file)

  filtFs <- file.path(out_dir, "filtered_reads", paste0(sample.names, "_filt.fq.gz"))

  print(filtFs)

  out <- filterAndTrim(fnFs, filtFs, truncLen=0,
                       maxN=0, maxEE=2, truncQ=2, rm.phix=TRUE,
                       compress=TRUE, multithread=TRUE, verbose=TRUE)
  print(out)
  # nbases: The minimum number of total bases to use for error rate learning. Default 1e8.
  print(nbases)
  errF <- learnErrors(filtFs, nbases = nbases, multithread=TRUE)


  dadaFs <- dada(filtFs, err=errF, multithread=TRUE)



  seqtab <- makeSequenceTable(dadaFs)


  print(minFoldParentOverAbundance)


  seqtab.nochim <- removeBimeraDenovo(seqtab, method="consensus", multithread=TRUE, verbose=TRUE, minFoldParentOverAbundance=minFoldParentOverAbundance)
  rownames(seqtab.nochim) <- sample.names



  # 导出序列
  seq_nochim = getSequences(seqtab.nochim)
  names(seq_nochim) <- paste0("ASV_", seq_along(seq_nochim))

  writeFasta(seq_nochim, rep_seqs_nochim_file)

  getN <- function(x) sum(getUniques(x))

  rowSumsResult <- rowSums(seqtab.nochim)
  track <- cbind(sample.names, reads_count, out, sapply(dadaFs, getN), rowSumsResult, rowSumsResult/reads_count*100, rowSums(seqtab.nochim > 0))
  # If processing a single sample, remove the sapply calls: e.g. replace sapply(dadaFs, getN) with getN(dadaFs)
  colnames(track) <- c("sample", "input", "merged", "filtered", "denoised", "nonchim", "nonchim_p", "nonchim_ASV")
  rownames(track) <- sample.names

  print(track)

  write.table(track, file = tsv_path, sep = "\t", quote = F, row.names = F)

  # 导出特征表
  save(seqtab.nochim, track, file = seq_table_file)




}

do_dada2(snakemake@input[["cr1"]], snakemake@input[["merged_seq"]], snakemake@output[["rep_seqs"]], snakemake@output[["seq_table"]], snakemake@output[["tsv"]], snakemake@params[["minFoldParentOverAbundance"]], snakemake@params[["nbases"]])



