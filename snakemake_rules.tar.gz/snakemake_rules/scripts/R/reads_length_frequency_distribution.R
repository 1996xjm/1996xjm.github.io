## capture all the output to a file.
log <- file(snakemake@log[[1]], open="wt")
sink(log) #redirect stdout
sink(log, type = "message") #redirect stderr
library(ggplot2)
library(pheatmap)
library(ShortRead) # 读写序列



do_dada2 = function (f_fq_file_path, f_len_freq_file_path, f_len_freq_fig_path){

  file_df_list = list()

  sample.names <- sapply(strsplit(basename(f_fq_file_path), "\\."), `[`, 1)
  print(sample.names)
  for (i in seq_along(f_fq_file_path)) {
  # Read the FASTQ file and calculate the read lengths
  file = f_fq_file_path[i]
  name = sample.names[i]
  fastq <- readFastq(file)
  read_lengths <- width(fastq)


  # Create a data frame for the file's read lengths
  file_df <- data.frame(Sample = name, ReadLength = read_lengths)

  # print(table(file_df$ReadLength))

  kk = list(file_df)
  names(kk) = name
  file_df_list = append(file_df_list, kk)



}

  # Merge the results
merged_result <- table(file_df_list[[1]]$ReadLength)  # Initialize with the first result
for (i in 2:length(file_df_list)) {
  merged_result <- merge(merged_result, table(file_df_list[[i]]$ReadLength), by="Var1", all=TRUE)
}
  names(merged_result)[-1] = sample.names

  merged_result$Var1 = as.integer(levels(merged_result$Var1))

  sorted_df <- merged_result[order(merged_result$Var1), ]
  sorted_df[is.na(sorted_df)] <- 0
  transposed_df <- t(sorted_df)
  colnames(transposed_df) <- transposed_df[1, ]
  # In R, if you have a matrix with only one column and you use the code transposed_df <- transposed_df[-1, ], it will no longer be a matrix. The reason for this is that when you subset a single column from a matrix using the -1 index, R returns a vector instead of a matrix.
  transposed_df <- transposed_df[-1, ,drop=F]
  print(transposed_df)

  min_value = min(transposed_df)

if(min_value==max(transposed_df)){
  my_heatmap = pheatmap(transposed_df, cluster_rows = F, cluster_cols = F, breaks=c(min_value,min_value+4))
}else {
   my_heatmap = pheatmap(transposed_df, cluster_rows = F, cluster_cols = F)
}

  fig_width <- ncol(transposed_df) * 5
  fig_height <- nrow(transposed_df) * 5
  if(fig_width < 100){
    fig_width = 100
  }

  if(fig_height < 100){
    fig_height = 100
  }
  ggsave(f_len_freq_fig_path, plot = my_heatmap, width = fig_width, height = fig_height, units = "mm", dpi = 300, limitsize = FALSE)


  print(cbind(rownames(transposed_df),transposed_df))

  write.table(cbind(rownames(transposed_df),transposed_df), file = f_len_freq_file_path, sep = "\t", quote = F, row.names = F, col.names = T)





}

do_dada2(snakemake@input[["r1"]], snakemake@output[["r1"]], snakemake@output[["r1_fig"]])
do_dada2(snakemake@input[["r2"]], snakemake@output[["r2"]], snakemake@output[["r2_fig"]])



