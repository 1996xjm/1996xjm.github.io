library(ggplot2)
library(viridis) #配色
library(ggprism) # 坐标轴两端收边
do_plot = function (summary_table_path, out_path){

  df <- read.table(summary_table_path, fill = T, check.names = F, header=T, sep="\t")
  # y 值取 log2
  df$Value <- log2(df$Value)
   p <- ggplot(df, aes(x=Samples, y=Value)) +
      # geom_violin(aes(fill=Samples)) +
      geom_boxplot(width=0.4) +
      # scale_fill_manual(values = c("#8dd3c7","#ffffb3","#bebada","#fb8072","#80b1d3")) + # 自定义配色
      scale_fill_brewer(palette = "Dark2") +
      coord_flip() + # 水平
      # scale_y_reverse() + # 将y轴刻度反转
      scale_y_continuous(labels = function(x) format(x, scientific=FALSE), expand = c(0.01, 0), guide = "prism_offset" ) + #刻度不要科学计数, expand = c(0.01, 0) 扩展了1%，position = "right" 刻度移到上面
      scale_x_discrete(expand = c(0.05, 0), guide = "prism_offset") + #离散型变量 expand = c(0.05, 0) 扩展了5%, guide = "prism_offset" 坐标轴两端收边
      theme(
        plot.title = element_text(hjust = 0.5), #标题居中
        panel.background = element_blank(),  # 去除背景
        axis.line = element_line(color = "black", linewidth = 0.5), # 坐标轴样式
        axis.ticks = element_line(color = "black", linewidth = 0.5),
      panel.grid.major.y = element_blank(),
      panel.grid.major.x = element_blank(),
      text = element_text(size = 16, face = "bold"), #字体大小
        legend.position = "none", # 图例位置， bottom默认direction = "horizontal
        # legend.direction = "horizontal",
        plot.margin = unit(c(1,2,1,1),"cm") # margin 上右下左
      ) # 不要y轴网格
  p <- p + labs(x='Samples', y='log2(Read counts)', title = "Distribution of Counts")


  ggsave(out_path, p, width = 14, height = 8, dpi = 300, bg="white") # 白色背景
}

do_plot(snakemake@input[[1]], snakemake@output[[1]])



