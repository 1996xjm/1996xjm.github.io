
#-----------#
# LOAD DATA #
#-----------#
# 1. Load our text file with the lnL values
lnL_vals <- read.table( file = snakemake@input[[1]], sep= " ", stringsAsFactors = FALSE,
                        header = TRUE )

# 2. We can now compute the LRT statistic, but this can
# only be done between models that are nested:
#     M0 < M1a < M2a
#     M7 < M8

# First, we will compare M1a (alternative) to the M0 (null).
# If the null is rejected, then we can compare M1a (null) to
# M2a (alternative).
## M0 vs M1a ##
diff_M0vsM1a <- 2*( lnL_vals$Model_1a[1] - lnL_vals$Model_0[1] )
# diff = 559.2598
pchisq_M0vsM1a = pchisq( diff_M0vsM1a, df = 1, lower.tail=F )
# p-val = 1.217966e-123 < 0.05
Chisq.crit.M0vsM1a <- qchisq( p = 0.95, df = 1 )
# alpha critical value at 5% = 3.841459
Chisq.crit.M0vsM1a_2 <- qchisq( p = 0.99, df = 1 )
# alpha critical value at 1% = 6.634897

# As M1a is a better fit to the data than M0, we can compare M1a
# (Nearly Neutral) against M2a (Positive Selection).
## M1 vs M2a ##
diff_M1avsM2a <- 2*( lnL_vals$Model_2a[1] - lnL_vals$Model_1a[1] )
# diff = 0
pchisq_M1avsM2a = pchisq( diff_M1avsM2a, df = 2, lower.tail=F )
# p-val = 1 > 0
Chisq.crit.M1vsM2a <- qchisq( p = 0.95, df = 2 )
# alpha critical value at 5% level = 5.991465
Chisq.crit.M1vsM2a_2 <- qchisq( p = 0.99, df = 2 )
# alpha critical value at 1% level = 9.21034

# In addition, we can run an additional comparison between
# M7 (beta) and M8 (beta&omega).
## M7 vs M8 ##
diff_M7vsM8 <- 2*( lnL_vals$Model_8[1] - lnL_vals$Model_7[1] )
# 12.5435
pchisq_M7vsM8 = pchisq( diff_M7vsM8, df = 2, lower.tail=F )
# p-val = 0.001888922 < 0.05
Chisq.crit.M7vsM8 <- qchisq( p = 0.95, df = 2 )
# alpha critical value at 5% level = 5.991465
Chisq.crit.M7vsM8_2 <- qchisq( p = 0.99, df = 2 )
# alpha critical value at 1% level = 9.21034

LRT_df = data.frame(
  diff_lnL=c(diff_M0vsM1a,diff_M1avsM2a,diff_M7vsM8),
  pvalue=c(pchisq_M0vsM1a, pchisq_M1avsM2a, pchisq_M7vsM8),
  chisq_95=c(Chisq.crit.M0vsM1a, Chisq.crit.M1vsM2a, Chisq.crit.M7vsM8),
  chisq_99=c(Chisq.crit.M0vsM1a_2, Chisq.crit.M1vsM2a_2, Chisq.crit.M7vsM8_2)
)
rownames(LRT_df) <- c("M0vsM1a", "M1avsM2a", "M7vsM8")

write.table(cbind(model=rownames(LRT_df),LRT_df), file = snakemake@output[['LRT']], sep = "\t", quote = F, row.names = F)

# 3. Plot results
png(snakemake@output[['png']], width = 1200, height = 800, res = 150)
par( mfrow = c(1, 3) )



# M0 vs M1a
max_M0vsM1a = max(Chisq.crit.M0vsM1a, Chisq.crit.M0vsM1a_2, diff_M0vsM1a ) + 10
curve( dchisq( x, df = 1 ), from = 0, to =  max_M0vsM1a, xlab = paste0("pvalue = ", pchisq_M0vsM1a) )
abline( v = c( Chisq.crit.M0vsM1a, Chisq.crit.M0vsM1a_2, diff_M0vsM1a ), col = c( "darkgray", "brown", "red" ) )
coords_dev    <- c( max_M0vsM1a/2, Inf )
coords_pval   <- c( 410.4, 0.0075 )
coords_alphac <- c( 390, 0.0068 )
coords_alphac2 <- c( 390, 0.0064 )

title( "A) M0 vs M1a" )


#M1a vs M2a
curve( dchisq( x, df = 2 ), from = 0, to =  10, xlab = paste0("pvalue = ", pchisq_M1avsM2a) )
abline( v = c( Chisq.crit.M1vsM2a, Chisq.crit.M1vsM2a_2, diff_M1avsM2a ), col = c( "darkgray", "brown", "red" ) )
coords_dev     <- c( 7.85, 0.48 )
coords_pval    <- c( 7.8, 0.45 )
coords_alphac  <- c( 8, 0.41 )
coords_alphac2 <- c( 8, 0.38 )

title( "B) M1a vs M2a" )

# M7 vs M8
curve( dchisq( x, df = 2 ), from = 0, to =  15, xlab = paste0("pvalue = ", pchisq_M7vsM8) )
abline( v = c( Chisq.crit.M7vsM8, Chisq.crit.M7vsM8_2, diff_M7vsM8 ), col = c( "darkgray", "brown", "red" ) )
coords_dev     <- c( 3.5, 0.48 )
coords_pval    <- c( 3.8, 0.45 )
coords_alphac  <- c( 3.4, 0.41 )
coords_alphac2 <- c( 3.4, 0.38 )

title( "C) M7 vs M8" )
dev.off()