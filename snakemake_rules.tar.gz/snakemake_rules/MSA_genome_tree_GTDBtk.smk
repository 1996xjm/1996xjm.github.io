"""
name: download NCBI genome
date: 2023-01-05
description: Snakemake pipeline to download NCBI genome
author: Jianmin Xie
dependencies:
    - datasets = 14.6.4,
    - checkM
    - drep
rules:
    - download


"""
import os

import pandas as pd

# configfile: "configs/config.yaml"

genome_dir = config["genome"]
GTDBTK_env_name = config["GTDBTK_env_name"]
iqtree_env_name = config["iqtree_env_name"]
extension = config.get("extension","fasta")




identify_output = "identify_output"
align_output = "align_output"
iqtree_output = "iqtree_output"





shell.executable('/bin/zsh') # set a shell to run commands




rule all:
    input:
        iqtree_output + "/MSA_genome_tree.treefile",
    default_target: True




# 识别120marker基因
rule identify_marker_gene:
    input:
        genome_dir
    output:
        directory(identify_output)
    params:
        extension = extension,
    threads: workflow.cores
    conda:
        GTDBTK_env_name
    log:
        "logs/identify_marker_gene.log"
    shell:
        "gtdbtk identify --genome_dir {input} --out_dir {output} --extension {params.extension} --cpus {threads} &> {log}"


rule align_marker_gene:
    input:
        rules.identify_marker_gene.output
    output:
        align_output + "/align/gtdbtk.bac120.user_msa.fasta.gz"
    params:
        out_dir = align_output,
    threads: workflow.cores
    conda:
        GTDBTK_env_name
    log:
        "logs/align_marker_gene.log"
    shell:
        "gtdbtk align --identify_dir {input} --out_dir {params.out_dir} --cpus {threads} --skip_gtdb_refs &> {log}"

# 把上面加的 my_ 去掉
rule rename_MAS:
    input:
        rules.align_marker_gene.output
    output:
        align_output + "/align/renamed.bac120.user_msa.fasta"
    shell:
        "zcat {input}|sed 's/>my_/>/' > {output}"

rule iqtree:
    input:
        rules.rename_MAS.output
    output:
        iqtree_output + "/MSA_genome_tree.treefile"
    params:
        outgroup = config["outgroup"] if "outgroup" in config else "\"\"",
        output_prefix = iqtree_output + "/MSA_genome_tree"
    log:
        "logs/iqtree.log"
    benchmark:
        f"benchmarks/iqtree_benchmark.tsv"
    conda:
        iqtree_env_name
    threads: workflow.cores
    shell:
        """if [[ {params.outgroup} == "" ]] {{
    iqtree2 -s {input} -m MFP  -B 1000  -redo --prefix {params.output_prefix}  -nt {threads} &> {log}
}} else {{
    iqtree2 -s {input} -m MFP  -B 1000  -redo --prefix {params.output_prefix}  -nt {threads} -o {params.outgroup} &> {log}
}}"""