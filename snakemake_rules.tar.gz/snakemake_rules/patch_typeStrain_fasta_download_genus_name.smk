"""
name: patch type strain fasta download
date: 2024-10-15
description: download type strain fasta using genus name from LPSN
author: Jianmin Xie
dependencies:
    - parsnp = 1.7.4,
    - harvesttools = ?
rules:
    - parsnp


"""
from urllib  import request
from lxml import etree


shell.executable('/bin/zsh') # set a shell to run commands


genera_list_txt = "/Users/xjm/Documents/sampling/final_representative_strain/Phaeobacter gallaeciensis/TG_genome/type_strain_16S/close_genera.txt"
fasta_out_dir = "fasta_out"

with open(genera_list_txt,"r") as f:
    SAMPLE = [line.strip() for line in f]

rule all:
    input:
        expand(fasta_out_dir + "/{sample}.fasta", sample=SAMPLE)
rule download_fasta:
    output:
        ensure(fasta_out_dir + "/{sample}.fasta", non_empty=True)
    run:
        res = request.urlopen(f"https://lpsn.dsmz.de/genus/{wildcards.sample}")
        htmlStr = res.read().decode()
        html = etree.HTML(htmlStr)
        fastaUriList = html.xpath("//a[@class='black fasta-download']/@href")
        if len(fastaUriList) > 0:
            fasta_url = f"https://lpsn.dsmz.de{fastaUriList[0]}"
            shell(f"curl -o {output[0]} {fasta_url}")


