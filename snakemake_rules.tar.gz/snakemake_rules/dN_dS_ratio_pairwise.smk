"""
name: Use YN00 to estimate the synonymous and nonsynonymous rates (dS and dN) and to detect positive Darwinian selection
date: 2025-10-11
description: a standard approach is to calculate pairwise dN/dS values across all genomes for each gene (using codon-aligned sequences), then for each genome, take the average dN/dS of its sequence compared to the other 6 genomes
reference: https://doi.org/10.1093/molbev/msad041, https://github.com/abacus-gene/paml-tutorial/tree/main/positive-selection
author: Jianmin Xie
dependencies:
    - pal2nal.pl http://www.bork.embl.de/pal2nal/
    - mafft
    - yn00 in  = 4paml.10.7


rules:
    - copy_fna
    - mafft
    - pal2nal

"""

####### 这种两两比对取均值的算法 最终算出来的结果不准，没有采用，因为这种差异本身就得跟祖先比较而不是互相比较

import os
from builtins import input
from os import path

import pandas as pd


GENOMES = ["PT24_64", "PT34_48", "PT42_8", "PT41_83", "SY47_7", "SY12_1", "PT47_15"]
CDS_DIR = "/home/xjm/final_representative_strain/Pha/TG_genome/my_pangenome/pan_genome_output/seq/single_copy_fnas"
PROT_DIR = "/home/xjm/final_representative_strain/Pha/TG_genome/my_pangenome/pan_genome_output/seq/single_copy_aas"
RESULTS_DIR = "results"
mean_omega_output = "mean_omega_output"
parse_yn00_output = "parse_yn00_output"
env_name = "orthofinder"
# 获取所有基因ID
genes = sorted([f.replace(".fna", "") for f in os.listdir(CDS_DIR) if f.endswith(".fna")])
rule all:
    input:
        expand(f"{RESULTS_DIR}/{{gene}}/{{gene}}.codon_aln.phy", gene=genes),
        expand(f"{RESULTS_DIR}/{{gene}}/yn00_results.txt", gene=genes),
        expand(f"{parse_yn00_output}/{{gene}}_pairwise.tsv", gene=genes),
        expand(f"{mean_omega_output}/{{gene}}_mean_omega.tsv", gene=genes),
        f"dnds_matrix.tsv"

# 1️⃣ MAFFT 蛋白多序列比对
rule align_protein:
    input:
        faa = f"{PROT_DIR}/{{gene}}.faa"
    output:
        aln = f"{RESULTS_DIR}/{{gene}}/{{gene}}_prot_aln.faa"
    conda:
        env_name
    shell:
        """
        mafft --auto {input.faa} > {output.aln}
        """

# 2️⃣ PAL2NAL：用蛋白比对和对应的CDS生成 codon 对齐文件
rule pal2nal:
    input:
        aln = f"{RESULTS_DIR}/{{gene}}/{{gene}}_prot_aln.faa",
        fna = f"{CDS_DIR}/{{gene}}.fna"
    output:
        codon = f"{RESULTS_DIR}/{{gene}}/{{gene}}.codon_aln.phy"
    shell:
        """
        pal2nal.pl {input.aln} {input.fna} -output paml -codontable 11 -nogap > {output.codon}
        """

# 3️⃣ PAML YN00 计算 pairwise dN/dS
rule run_yn00:
    input:
        codon = f"{RESULTS_DIR}/{{gene}}/{{gene}}.codon_aln.phy"
    output:
        out = f"{RESULTS_DIR}/{{gene}}/yn00_results.txt"
    log:
        "logs/yn00/{gene}.log"
    shell:
        """
        (cd {RESULTS_DIR}/{wildcards.gene} && \
        echo "seqfile = {wildcards.gene}.codon_aln.phy\noutfile = yn00_results.txt\nverbose = 0" > yn00.ctl && \
        yn00 yn00.ctl) &> {log}
        """

# 4️⃣ 解析 yn00 输出 → 生成 3335×7 的矩阵
rule parse_yn00:
    input:
        rules.run_yn00.output
        # lambda x:[i for i in expand(f"{RESULTS_DIR}/{{gene}}/yn00_results.txt", gene=genes) if path.exists(i)]
    output:
        f"{parse_yn00_output}/{{gene}}_pairwise.tsv",
        f"{mean_omega_output}/{{gene}}_mean_omega.tsv",
    script:
        "scripts/python/paml/parse_yn00_output.py"



rule merge_omega_output:
    input:
        lambda x:[i for i in expand(f"{mean_omega_output}/{{gene}}_mean_omega.tsv", gene=genes) if path.exists(i)]
    output:
        f"dnds_matrix.tsv",
        f"dnds_matrix_without_PCA_nan.tsv",
        f"dnds_matrix_without_nan.tsv",
    run:
        df_list = []
        for file in input:
            GC_ID = path.basename(file).replace("_mean_omega.tsv","")
            omega_S = pd.read_table(file, index_col=0)["omega"]
            omega_S.name = GC_ID
            df_list.append(omega_S)
        pd.concat(df_list, axis=1).T.to_csv(output[0], sep="\t", index_label="GC_ID")
        pd.concat(df_list, axis=1).dropna(axis=1, how='all').to_csv(output[1], sep="\t", index_label="GC_ID")
        pd.concat(df_list, axis=1).dropna(axis=1, how='all').T.to_csv(output[2], sep="\t", index_label="GC_ID")




