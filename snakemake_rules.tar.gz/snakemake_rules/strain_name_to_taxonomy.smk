"""
name: get taxon from NCBI
date: 2023-11-18
description: Snakemake pipeline to get taxon using assembly accession number
author: Jianmin Xie
dependencies:
    - lxml = 4.9.3,
rules:
    - make_db
"""
import os
from os import path
import urllib
import pandas as pd


shell.executable('/bin/zsh') # set a shell to run commands

name_txt = "/Users/xjm/Desktop/程宇/20231204/bac_name.txt"
assembly_url = "https://www.ncbi.nlm.nih.gov/assembly"

taxon_text_dir = "taxon_text_output"


df = pd.read_table("/Users/xjm/Desktop/程宇/20231204/bac_name.txt", index_col=0)
SAMPLES = df.index.tolist()



rule all:
    input:
        "all_Taxonomy.tsv"


rule get_taxon_text:
    params:
        name = lambda wildcards: df.loc[wildcards.sample,'name']
    output:
        taxon_text_dir + "/{sample}.txt"
    # retries: 4
    conda:
        "coding_env"
    script:
        "scripts/python/get_taxon_text_by_strain_name.py"




rule cat:
    input:
        expand(taxon_text_dir + "/{sample}.txt",sample=SAMPLES)
    params:
        dir = taxon_text_dir
    output:
        "all_Taxonomy.tsv"
    run:
        max_length = 0
        line_list = []
        for line in shell("cat {params.dir}/*",iterable=True):
            line_strip = line.strip()
            level_length = len(line_strip.split("\t")) - 1
            if level_length > max_length:
                max_length = level_length
            line_list.append(line_strip)
        with open(output[0], "w") as f:
            header = "\t".join(["acc ID"]+[f"level_{i}" for i in range(max_length)])
            line_list = [header] + line_list
            f.write("\n".join(line_list))
