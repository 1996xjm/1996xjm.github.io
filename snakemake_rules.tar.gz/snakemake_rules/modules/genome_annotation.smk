"""
config key
    - genome_dir
    - env_name
    - samples
    - busco_database
    - checkM_output
    - busco_output
"""

# 默认值
genome_suffix = config.get("genome_suffix","fasta")

bakta_output = config["bakta_output"]
pgap_output = config["pgap_output"]

bakta_db = config["bakta_db"]
genome_dir = config["genome_dir"]
bakta_replicons_table_dir = config["bakta_replicons_table_dir"]
bakta_proteins_output = config["bakta_proteins_output"]
env_name = config["env_name"]
SAMPLES = config["samples"]



# 检查有没有配置pgap数据库路径的环境变量
envvars:
    "PGAP_INPUT_DIR"

rule bakta:
    input:
        genome=genome_dir + "/{sample}." + genome_suffix,
        bakta_replicons_table=bakta_replicons_table_dir + "/{sample}_replicons.tsv"
    output:
        bakta_output + "/{sample}/{sample}.tsv"
    params:
        out_dir=bakta_output + "/{sample}",
        db=bakta_db,
        genus=lambda wildcards: config["organism"][wildcards.sample].split(" ")[0],
        species=lambda wildcards: config["organism"][wildcards.sample].split(" ")[1],
    log:
        "logs/bakta/{sample}_bakta.log"
    threads: workflow.cores / 4
    conda:
        env_name
    shell:
        "bakta -f "
        "--db {params.db} "
        "--verbose "
        "--genus {params.genus} "
        "--species {params.species} "
        "--output {params.out_dir} "
        "--prefix {wildcards.sample} "
        "--locus-tag {wildcards.sample} "
        "--replicons {input.bakta_replicons_table} "
        "--threads {threads} {input.genome} "
        "&> {log}"










rule pgap_yaml:
    input:
        genome=genome_dir + "/{sample}." + genome_suffix,
    output:
        generic=pgap_output + "/{sample}/generic.yaml",
        metadata=pgap_output + "/{sample}/metadata.yaml",
        genome=temp(pgap_output + "/{sample}/{sample}.fasta"),
    params:
        genus_species=lambda wildcards: config["organism"][wildcards.sample],
    run:
        # docker容器里只支持相对路径，要把基因组复制过来
        shell(f"cp {input.genome} {output.genome}")
        generic_yaml = f"""fasta:
    class: File
    location: {wildcards.sample}.fasta
submol:
    class: File
    location: metadata.yaml"""

        metadata_yaml = f"""organism:
    genus_species: {params["genus_species"]}
    strain: {wildcards.sample}
locus_tag_prefix: {wildcards.sample}
authors:
    - author:
        first_name: 'Jianmin'
        last_name: 'Xie'
contact_info:
    first_name: 'Jianmin'
    last_name: 'Xie'
    email: '19jmxie@stu.edu.cn'
    organization: 'Shantou University'
    department: 'College of Science'
    street: '243 Daxue Road'
    city: 'Shantou'
    state: 'Guangdong'
    postal_code: '515063'
    country: 'China'"""
        with open(output["generic"],"w") as f:
            f.write(generic_yaml)
        with open(output["metadata"],"w") as f:
            f.write(metadata_yaml)





rule pgap:
    input:
        generic = rules.pgap_yaml.output.generic,
        genome = rules.pgap_yaml.output.genome,
    output:
        gff = pgap_output + "/{sample}/result/annot.gff",
        gbk = pgap_output + "/{sample}/result/annot.gbk",
        faa = pgap_output + "/{sample}/result/annot.faa", # 不用那个annot_translated_cds.faa 是因为bakta不支持还有内部终止子的序列，这些假基因基本都是移动原件蛋白，无所谓
        translated_faa = pgap_output + "/{sample}/result/annot_translated_cds.faa"
    params:
        threads=128,
        out_dir = pgap_output + "/{sample}/result"
    benchmark:
        "benchmarks/pgap/{sample}_benchmark.tsv"
    threads: workflow.cores / 4
    log:
        "logs/pgap/{sample}_pgap.log"
    shell:
        "rm -rf {params.out_dir};" # snakemake会自动创建这个文件夹，pgap又不允许存在这个文件夹
        "pgap.py --no-self-update --taxcheck --ignore-all-errors -c {params.threads} -n -o {params.out_dir} {input.generic} &> {log}"





rule bakta_proteins:
    input:
        rules.pgap.output.faa
    output:
        bakta_proteins_output + "/{sample}/{sample}.tsv"
    params:
        out_dir=bakta_proteins_output + "/{sample}",
        db=bakta_db,
    log:
        "logs/bakta_proteins/{sample}_bakta_proteins.log"
    threads: workflow.cores / 4
    conda:
        env_name
    shell:
        "bakta_proteins -f "
        "--db {params.db} "
        "--verbose "
        "--output {params.out_dir} "
        "--prefix {wildcards.sample} "
        "--threads {threads} {input} "
        "&> {log}"








