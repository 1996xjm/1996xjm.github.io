"""
name: Use MUMmer4 to perform whole-genome alignment and count the number of SNVs
date: 2025-09-26
description: Snakemake pipeline for the usage of MUMmer4 to perform whole-genome alignment and count the number of SNVs
reference: https://doi.org/10.1093/molbev/msad041, https://github.com/abacus-gene/paml-tutorial/tree/main/positive-selection
author: Jianmin Xie
dependencies:
    - nucmer = 4.0.1



"""

#######################################
# Snakefile: pairwise SNP comparison with merged summary
#######################################

import itertools
import pandas as pd
import math
import os

configfile: "configs/genome_sets.yaml"


# 读取 config.yaml 里面的基因组集合
GENOME_SETS = config["genome_sets"]
GENOME_DIR = config["genome_dir"]

# 生成所有 pairwise 组合
PAIRS = {}
for group, genomes in GENOME_SETS.items():
    PAIRS[group] = [(ref, qry) for ref, qry in itertools.combinations(genomes, 2)]

rule all:
    input:
        expand("pairwise_results/{group}/summary.tsv", group=GENOME_SETS.keys()),
        "pairwise_results/all_summary.tsv"

rule nucmer_dnadiff:
    input:
        ref=lambda w: f"{GENOME_DIR}/{w.ref}",
        qry=lambda w: f"{GENOME_DIR}/{w.qry}"
    output:
        delta="pairwise_results/{group}/{ref}__{qry}/out.delta",
        report="pairwise_results/{group}/{ref}__{qry}/out.report",
        snps="pairwise_results/{group}/{ref}__{qry}/out.snps"
    shell:
        r"""
        mkdir -p pairwise_results/{wildcards.group}/{wildcards.ref}__{wildcards.qry}
        nucmer --prefix=pairwise_results/{wildcards.group}/{wildcards.ref}__{wildcards.qry}/out {input.ref} {input.qry}
        dnadiff -p pairwise_results/{wildcards.group}/{wildcards.ref}__{wildcards.qry}/out -d pairwise_results/{wildcards.group}/{wildcards.ref}__{wildcards.qry}/out.delta
        """

rule summarize:
    input:
        reports=lambda w: [f"pairwise_results/{w.group}/{ref}__{qry}/out.report"
                           for ref, qry in PAIRS[w.group]],
        snps=lambda w: [f"pairwise_results/{w.group}/{ref}__{qry}/out.snps"
                        for ref, qry in PAIRS[w.group]]
    output:
        "pairwise_results/{group}/summary.tsv"
    run:
        records = []
        for ref, qry in PAIRS[wildcards.group]:
            report_file = f"pairwise_results/{wildcards.group}/{ref}__{qry}/out.report"
            snps_file = f"pairwise_results/{wildcards.group}/{ref}__{qry}/out.snps"

            with open(snps_file) as f:
                snp_count = sum(1 for _ in f)

            # 初始化变量
            ref_total = ref_aligned = ref_unaligned = None
            qry_total = qry_aligned = qry_unaligned = None
            ref_totalseqs = ref_alignedseqs = ref_unalignedseqs = None
            qry_totalseqs = qry_alignedseqs = qry_unalignedseqs = None

            with open(report_file) as f:
                for line in f:
                    s = line.strip()
                    if s.startswith("TotalSeqs"):
                        parts = s.split()
                        ref_totalseqs, qry_totalseqs = int(parts[1]), int(parts[2])
                    elif s.startswith("AlignedSeqs"):
                        parts = s.split()
                        ref_alignedseqs, qry_alignedseqs = parts[1], parts[2]
                    elif s.startswith("UnalignedSeqs"):
                        parts = s.split()
                        ref_unalignedseqs, qry_unalignedseqs = parts[1], parts[2]
                    elif s.startswith("TotalBases"):
                        parts = s.split()
                        ref_total, qry_total = int(parts[1]), int(parts[2])
                    elif s.startswith("AlignedBases"):
                        parts = s.split()
                        ref_aligned, qry_aligned = int(parts[1].split("(")[0]), int(parts[2].split("(")[0])
                    elif s.startswith("UnalignedBases"):
                        parts = s.split()
                        ref_unaligned, qry_unaligned = int(parts[1].split("(")[0]), int(parts[2].split("(")[0])

            snp_density_per_mb = snp_count / ref_total * 1e6 if ref_total > 0 else math.nan

            ref_aligned_pct = ref_aligned / ref_total * 100
            qry_aligned_pct = qry_aligned / qry_total * 100

            records.append([
                ref, qry, snp_count, snp_density_per_mb,
                ref_totalseqs, ref_alignedseqs, ref_unalignedseqs,
                qry_totalseqs, qry_alignedseqs, qry_unalignedseqs,
                ref_total, ref_aligned, ref_unaligned, ref_aligned_pct,
                qry_total, qry_aligned, qry_unaligned, qry_aligned_pct
            ])

        df = pd.DataFrame(records, columns=[
            "Ref", "Qry", "SNPs", "SNPs_per_Mb",
            "Ref_TotalSeqs", "Ref_AlignedSeqs", "Ref_UnalignedSeqs",
            "Qry_TotalSeqs", "Qry_AlignedSeqs", "Qry_UnalignedSeqs",
            "Ref_TotalBases", "Ref_AlignedBases", "Ref_UnalignedBases", "Ref_AlignedBasesPct",
            "Qry_TotalBases", "Qry_AlignedBases", "Qry_UnalignedBases", "Qry_AlignedBasesPct"
        ])
        df.to_csv(output[0], sep="\t", index=False)

rule merge_summaries:
    input:
        summaries=expand("pairwise_results/{group}/summary.tsv", group=GENOME_SETS.keys())
    output:
        "pairwise_results/all_summary.tsv"
    run:
        dfs = []
        for f in input.summaries:
            group = os.path.basename(os.path.dirname(f))
            df = pd.read_csv(f, sep="\t")
            df["Group"] = group
            dfs.append(df)
        merged = pd.concat(dfs, ignore_index=True)
        merged.to_csv(output[0], sep="\t", index=False)
