"""
name: run anvi pangenomics
date: 20234-03-22
description: Snakemake pipeline to run anvi pangenomics https://merenlab.org/2016/11/08/pangenomics-v2/
author: Jianmin Xie
dependencies:
    - anvio,
rules:
    -
"""
import os
from os import path
import pandas as pd
shell.executable('/bin/zsh') # set a shell to run commands

configfile: "configs/genome_abundance_config.yaml"

env_name = config["env_name"]
ref_genome = config["ref_genome"]

# tara_reads = "/userdata1/xjm/Tara_ocean/PRJEB1787/reads"
tara_reads = config["fastp_config"]["reads_dir"]
bowtie2_index = "bowtie2_index"
bowtie2_output = "bowtie2_output"
summary_output = "summary_output"

blast_db_output = "blast_db"


genome_name = ".".join(path.basename(ref_genome).split(".")[:-1])

# 先只考虑双端数据
SAMPLES =  [i for i in os.listdir(tara_reads) if len([j for j in os.listdir(path.join(tara_reads,i)) if j.endswith(".gz")]) > 1]

module fastp_module:
    # here, plain paths, URLs and the special markers for code hosting providers (see below) are possible.
    snakefile: "modules/fastp_module_temp.smk"
    config: config["fastp_config"]


use rule * from fastp_module as my_*

rule all:
    input:
        expand(bowtie2_output + "/{sample}/{sample}_{type}.tsv", sample=SAMPLES, type=["idxstats", "coverage"]),
        expand(bowtie2_output + "/{sample}/{sample}.mapped.sort.bam", sample=SAMPLES),
        summary_output + "/mapped_reads_count.tsv",
        bowtie2_index+ f"/{genome_name}.1.bt2"
    default_target: True


# 参考文档：https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml
rule build_bowtie2_index:
    input:
        ref_genome
    output:
        bowtie2_index + f"/{genome_name}.1.bt2"
    params:
        index_prifix=bowtie2_index + f"/{genome_name}"
    threads: 32
    log:
        "logs/build_bowtie2_index.log"
    conda:
        env_name
    shell:
        "bowtie2-build --threads {threads} {input} {params.index_prifix} &> {log}"

# 参考文档：https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml
rule bowtie2:
    input:
        r1=rules.my_fastp.output.r1,
        r2=rules.my_fastp.output.r2,
        bowtie2_index = rules.build_bowtie2_index.output
    output:
        temp(bowtie2_output + "/{sample}/{sample}.sam")
    params:
        index_prifix=bowtie2_index + f"/{genome_name}"
    log:
        "logs/bowtie2/{sample}_bowtie2.log"
    conda:
        env_name
    threads: 64
    shell:
        "bowtie2 -x {params.index_prifix} -1 {input.r1} -2 {input.r2} -S {output} -p {threads} &> {log}"





# 排序与压缩
rule samtools_sort:
    input:
        rules.bowtie2.output
    output:
        bam = temp(bowtie2_output + "/{sample}/{sample}.sort.bam"),
        bai = temp(bowtie2_output + "/{sample}/{sample}.sort.bam.bai"),

    threads: 24
    conda:
        env_name
    log:
        "logs/samtools_sort/{sample}_samtools.log"
    shell:
        "samtools sort -O BAM -o {output.bam} -@ {threads} {input} &> {log};"
        "samtools index -@ {threads} {output.bam};"



rule mapping_summary:
    input:
        bam = rules.samtools_sort.output.bam,
        bai = rules.samtools_sort.output.bai,
    output:
        idxstats = bowtie2_output + "/{sample}/{sample}_idxstats.tsv",
        flagstat = bowtie2_output + "/{sample}/{sample}_flagstat.txt",
        coverage = bowtie2_output + "/{sample}/{sample}_coverage.tsv",
        coverage_histogram = bowtie2_output + "/{sample}/{sample}_coverage_histogram.tsv",
        depth_histogram = bowtie2_output + "/{sample}/{sample}_depth_histogram.tsv",
    conda:
        env_name
    shell:
        "samtools idxstats {input.bam} > {output.idxstats};"
        "samtools flagstat {input.bam} > {output.flagstat};"
        "samtools coverage {input.bam} > {output.coverage};"
        "samtools coverage -A {input.bam} > {output.coverage_histogram};"
        "samtools coverage -A --plot-depth {input.bam} > {output.depth_histogram};"



# 过滤掉没有比对上的
rule samtools_filter:
    input:
        rules.samtools_sort.output.bam
    output:
        bowtie2_output + "/{sample}/{sample}.mapped.sort.bam"

    threads: 24
    conda:
        env_name
    log:
        "logs/samtools_filter/{sample}_samtools.log"
    shell:
        "samtools view -F 4 -@ {threads} -bS -o {output} {input} &> {log};" # -F 4 滤掉没有mapping上records
        "samtools index -@ {threads} {output};"



# rule summary:
#     input:
#         expand(bowtie2_output + "/{sample}/{sample}_flagstat.txt", sample=SAMPLES)
#     output:
#         summary_output + "/mapped_reads_count.tsv"
#     shell:
#         """echo "Sample\tTotal_reads\tMapped_reads\tCoverage\tMeandepth" > {output}
# for i ({input}) {{
# sample_name=$(echo $i | cut -d'/' -f2)
# aa=(${{(f)"$(cut -d " " -f1 $i)"}})
# coverage=$(awk 'NR==2 {{print $6}}' {bowtie2_output}/$sample_name/${{sample_name}}_coverage.tsv)
# meandepth=$(awk 'NR==2 {{print $7}}' {bowtie2_output}/$sample_name/${{sample_name}}_coverage.tsv)
# echo "$sample_name\t$aa[1]\t$aa[7]\t$coverage\t$meandepth" >> {output}
# }}
# """
#


rule summary:
    input:
        flagstat_list = expand(bowtie2_output + "/{sample}/{sample}_flagstat.txt", sample=SAMPLES),
        coverage_list = expand(bowtie2_output + "/{sample}/{sample}_coverage.tsv", sample=SAMPLES),

    output:
        summary_output + "/mapped_reads_count.tsv"
    conda:
        env_name
    script:
        "scripts/python/summary_bowtie2_output.py"