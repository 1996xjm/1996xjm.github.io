

env_name = "MobileElementFinder"
SAMPLES = os.listdir("bakta_output")

rule all:
    input: 
        expand("blastp_out/{sample}.tsv", sample=SAMPLES)


rule blastp:
    input:
        q="JukA.faa",
        r="bakta_output/{sample}/{sample}.faa"
    output:
        "blastp_out/{sample}.tsv"
    conda: env_name
    shell:
        "blastp -query {input.q} -subject {input.r} -outfmt '7 qseqid sseqid pident qcovs qlen slen length mismatch gapopen evalue bitscore' -evalue 1e-5 -out {output}"