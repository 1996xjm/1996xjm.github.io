"""
name: download NCBI genome
date: 2023-01-05
description: Snakemake pipeline to download NCBI genome
author: Jianmin Xie
dependencies:
    - datasets = 14.6.4,
    - checkM
    - drep
rules:
    - download


"""
import os

import pandas as pd

configfile: "configs/config.yaml"

accession_list_file = config["accession_list_file"]
ANI_algorithm = config["ANI_algorithm"] # {skani,fastANI,gANI,ANImf,goANI,ANIn}大批量的基因组去重推荐skani，速度比fastANI快20倍以上，而且结果的冗余度比fastaANI低
S_ANI = config["S_ANI"] # 第二次聚类的ANI阈值
my_genome_path = config["my_genome_path"]
checkM_env_name = config["checkM_env_name"]
dRep_env_name = config["dRep_env_name"]
GTDBTK_env_name = config["GTDBTK_env_name"]
iqtree_env_name = config["iqtree_env_name"]

DOWNLOAD_OUT_PATH = "download_result"
CHECKM_OUT_PATH = "checkM_output"
target_genome_dir = "target_genome"
filter_cc_output = "filter_cc_output"

dereplication_output = f"dereplication_output_{ANI_algorithm}"

rename_soft_link_output = "dereplicated_genomes"

identify_output = "identify_output"
align_output = "align_output"
iqtree_output = f"iqtree_output_{ANI_algorithm}"







with open(accession_list_file,"r") as f:
    kk = f.read()
    SAMPLE = kk.strip().split("\n")


shell.executable('/bin/zsh') # set a shell to run commands




rule all:
    input:
        # expand(DOWNLOAD_OUT_PATH + "/genomes/{sample}.fna", sample=SAMPLE),
        # CHECKM_OUT_PATH + "/checkm_result.tsv",
        # filter_cc_output + "/target_genome_file_list.txt"
        # dereplication_output,
        # rename_soft_link_output,
        # identify_output,
        iqtree_output + "/MSA_genome_tree.treefile",
    default_target: True

rule download:
    output:
        temp(ensure(DOWNLOAD_OUT_PATH + "/temp/{sample}.zip", non_empty=True))
    shell:
        "datasets download genome accession {wildcards.sample} --include genome --filename {output} &> /dev/null"

rule unzip:
    input:
        rules.download.output
    output:
        genome = ensure(DOWNLOAD_OUT_PATH + "/genomes/{sample}.fna", non_empty=True),
        unzip_dir = temp(directory(DOWNLOAD_OUT_PATH + "/temp/{sample}"))
    shell:
        "unzip -d {output.unzip_dir} {input} &> /dev/null;"
        "mv {output.unzip_dir}/ncbi_dataset/data/*/*.fna {output.genome}"


rule checkM:
    input:
        expand(DOWNLOAD_OUT_PATH + "/genomes/{sample}.fna", sample=SAMPLE)
    output:
        ensure(CHECKM_OUT_PATH + "/checkm_result.tsv", non_empty=True)
    params:
        dir = DOWNLOAD_OUT_PATH + "/genomes",
        tem =CHECKM_OUT_PATH + "/checkm_tem",
        suffix = "fna",
        tax_rank = "class",
        tax = "Verrucomicrobiae",
    threads: workflow.cores
    conda:
        checkM_env_name
    log:
        "logs/checkM.log"
    shell:
        "checkm taxonomy_wf -f {output} --tab_table -x {params.suffix} -t {threads} {params.tax_rank} {params.tax} {params.dir} {params.tem} &> {log}"





# 根据完整度和污染度过滤
rule filter_cc:
    input:
        rules.checkM.output
    output:
        genome_file_list = filter_cc_output + "/target_genome_file_list.txt",
        genome_info = filter_cc_output + "/target_genome_info.csv", # 给dRep用的
    run:
        df = pd.read_table(input[0])
        target_df = df[(df["Completeness"] - df["Contamination"] * 5) >= 50]
        target_sample = target_df["Bin Id"].tolist()
        genome_file_list = [ DOWNLOAD_OUT_PATH + f"/genomes/{sample}.fna" for sample in target_sample]
        with open(output["genome_file_list"], "w") as f:
            f.write("\n".join(genome_file_list))

        target_df["genome"] = df['Bin Id'].apply(lambda x: x + ".fna")
        genome_info_df = target_df[["genome", "Completeness", "Contamination"]]
        genome_info_df = genome_info_df.set_index("genome", drop=True)
        genome_info_df.columns = ["completeness", "contamination"]
        genome_info_df.to_csv(output["genome_info"])




# 基因组去重
rule dereplication:
    input:
        genome_file_list = rules.filter_cc.output.genome_file_list,
        genome_info = rules.filter_cc.output.genome_info,
    output:
        directory(dereplication_output)
    params:
        ANI_algorithm = ANI_algorithm, # {skani,fastANI,gANI,ANImf,goANI,ANIn}大批量的基因组去重推荐skani，速度比fastANI快20倍以上
        S_ANI = S_ANI,
        comp = 40 # 上面已经过滤过了，这里填一个能保留所有基因组的参数
    benchmark:
        f"benchmarks/dereplication_{ANI_algorithm}_benchmark.tsv"
    threads: workflow.cores
    conda:
        dRep_env_name
    log:
        "logs/dereplication.log"
    shell:
        "dRep dereplicate -g {input.genome_file_list} --genomeInfo {input.genome_info} -comp {params.comp} -p {threads} --S_algorithm {params.ANI_algorithm} -sa {params.S_ANI} {output} &> {log}"


# 创建重命名的软连接，因为GTDB-TK不允许有基因组的名称跟他的数据库的基因组一样，还可以统一命名成fasta后缀
rule rename_genome_to_soft_link:
    input:
        rules.dereplication.output
    output:
        directory("dereplicated_genomes")
    params:
        my_genome_path = my_genome_path
    shell:
        """rm -rf {output}
mkdir {output}
cd {output}
cp {params.my_genome_path} .
for i (../{input}/dereplicated_genomes/*.fna) {{
ln -f -s $i "my_"$i[-19,-4]"fasta"
}}"""


# 识别120marker基因
rule identify_marker_gene:
    input:
        rules.rename_genome_to_soft_link.output
    output:
        directory(identify_output)
    params:
        extension = "fasta",
    threads: workflow.cores
    conda:
        GTDBTK_env_name
    log:
        "logs/identify_marker_gene.log"
    shell:
        "gtdbtk identify --genome_dir {input} --out_dir {output} --extension {params.extension} --cpus {threads} &> {log}"


rule align_marker_gene:
    input:
        rules.identify_marker_gene.output
    output:
        align_output + "/align/gtdbtk.bac120.user_msa.fasta.gz"
    params:
        out_dir = align_output,
    threads: workflow.cores
    conda:
        GTDBTK_env_name
    log:
        "logs/align_marker_gene.log"
    shell:
        "gtdbtk align --identify_dir {input} --out_dir {params.out_dir} --cpus {threads} --skip_gtdb_refs &> {log}"

# 把上面加的 my_ 去掉
rule rename_MAS:
    input:
        rules.align_marker_gene.output
    output:
        align_output + "/align/renamed.bac120.user_msa.fasta"
    shell:
        "zcat {input}|sed 's/>my_/>/' > {output}"

rule iqtree:
    input:
        rules.rename_MAS.output
    output:
        iqtree_output + "/MSA_genome_tree.treefile"
    params:
        output_prefix = iqtree_output + "/MSA_genome_tree"

    log:
        "logs/iqtree.log"
    benchmark:
        f"benchmarks/iqtree_{ANI_algorithm}_benchmark.tsv"
    conda:
        iqtree_env_name
    threads: workflow.cores
    shell:
        "iqtree2 -s {input} -m MFP  -B 1000  -redo --prefix {params.output_prefix}  -nt {threads} &> {log}"