"""
name: call SNPs with reference genome
date: 2024-04-07
description: Snakemake pipeline to call SNPs by Taking all genomes in turn as reference genomes
author: Jianmin Xie
dependencies:
    - bowtie2
    - freebayes = 1.3.6 https://github.com/freebayes/freebayes  最新的1.3.7 有bug
    - snpEff
rules:
    -
"""
import os
import pandas as pd
# from numpy.f2py import rules
from snakemake.utils import read_job_properties

configfile: "config.yaml"

env_name = config["env_name"]
BIN = config.get("bin_size", 1000)
THREADS = config.get("threads", 4)
FREEBAYES_OPTS = config.get("freebayes_opts", "")
WRAP_CHROM = config.get("wrap_chromosome", True)
PLASMID_PATTERN = config.get("plasmid_pattern", "plasmid|plm|p")
OUTDIR = config.get("out_dir", "results")
SAMPLES_TSV = config.get("samples_tsv", "samples.tsv")

samples = pd.read_csv(SAMPLES_TSV, sep="\t", comment="#", dtype=str)
SAMPLES = samples['sample'].tolist()

# map sample -> group
sample_group = dict(zip(samples['sample'], samples['group']))
group_dict = samples.groupby(by=["group"])

# groups set
GROUPS = sorted(list(set(samples['group'].tolist())))

# references mapping
REFS = config['references']

# targets
ALL_BAMS = expand(os.path.join(OUTDIR, "bam/{group}/{sample}.sorted.bam"), zip, group=samples['group'].tolist(), sample=SAMPLES)
all_samtools_stats = expand(os.path.join(OUTDIR, "mapping_stats/{group}/{sample}.idxstats.txt"), zip, group=samples['group'].tolist(), sample=SAMPLES)
ALL_VCFS = expand(os.path.join(OUTDIR, "vcf/{group}/{sample}.vcf"), zip, group=samples['group'].tolist(), sample=SAMPLES)
all_sample_mutation_stats = expand(os.path.join(OUTDIR, "mutation_stats/{group}/{sample}.tsv"), zip, group=samples['group'].tolist(), sample=SAMPLES)
all_sample_contig_mutation_stats = expand(os.path.join(OUTDIR,"mutation_stats_contig/{group}/{sample}.tsv"), zip, group=samples['group'].tolist(), sample=SAMPLES)
ALL_BIN_COUNTS = expand(os.path.join(OUTDIR, "bin_counts/{sample}.bins.tsv"), sample=SAMPLES)
GROUP_STATS = expand(os.path.join(OUTDIR, "group_stats/{group}_bin_mean_sd.tsv"), group=GROUPS)
GROUP_PLOTS = expand(os.path.join(OUTDIR, "plots/{group}_snp_hist.svg"), group=GROUPS)

rule all:
    input:
        ALL_BAMS,
        all_samtools_stats,
        ALL_VCFS,
        all_sample_mutation_stats,
        all_sample_contig_mutation_stats,
        expand(os.path.join(OUTDIR,"mutation_stats_contig/{clade}/{clade}_merged.tsv"), clade=GROUPS),
        # ALL_BIN_COUNTS,
        # GROUP_STATS,
        # GROUP_PLOTS,
        # os.path.join(OUTDIR, "all_sample_stats.tsv")

rule make_index_dir:
    input:
        ref=lambda wildcards: REFS[wildcards.group]
    output:
        directory(os.path.join(OUTDIR,"index/{group}"))
    conda:
        env_name
    shell:
        """
        mkdir -p {output}
        bowtie2-build {input.ref} {output}/ref || true
        """

rule map_reads:
    input:
        idx=os.path.join(OUTDIR, "index/{group}"),
        r1=lambda wildcards: samples.loc[samples['sample']==wildcards.sample,'r1'].values[0],
        r2=lambda wildcards: samples.loc[samples['sample']==wildcards.sample,'r2'].values[0]
    output:
        bam=os.path.join(OUTDIR, "bam/{group}/{sample}.sorted.bam")
    threads: THREADS
    params:
        group=lambda w: sample_group[w.sample]
    conda:
        env_name
    shell:
        r"""
        bowtie2 -x {input.idx}/ref -1 {input.r1} -2 {input.r2} -p {threads} |
            samtools view -b -@ {threads} - |
            samtools sort -@ {threads} -o {output.bam}
        samtools index {output.bam}
        """



rule samtools_stats:
    input:
        bam=rules.map_reads.output
    output:
        idx=os.path.join(OUTDIR, "mapping_stats/{group}/{sample}.idxstats.txt"),
        flag=os.path.join(OUTDIR, "mapping_stats/{group}/{sample}.flagstat.txt"),
        cov=os.path.join(OUTDIR, "mapping_stats/{group}/{sample}.coverage.tsv"),
        cov_his=os.path.join(OUTDIR, "mapping_stats/{group}/{sample}.coverage_histogram.txt"),
        depth_his=os.path.join(OUTDIR, "mapping_stats/{group}/{sample}.depth_histogram.txt"),
    conda:
        env_name
    shell:
        r"""
        samtools idxstats {input.bam} > {output.idx}
        samtools flagstat {input.bam} > {output.flag}
        samtools coverage {input.bam} > {output.cov}
        samtools coverage -A {input.bam} > {output.cov_his}
        samtools coverage -A --plot-depth {input.bam} > {output.depth_his}
        """

rule call_freebayes:
    input:
        bam=rules.map_reads.output,
        ref=lambda wildcards: REFS[sample_group[wildcards.sample]]
    output:
        vcf=os.path.join(OUTDIR, "vcf/{group}/{sample}.vcf")
    threads: 4
    params:
        min_coverage=10,# mapping深度
        min_base_quality=20,# 碱基测序质量对于这个数字才会被考虑
        min_alternate_fraction=0.75,# 这一列突变碱基所占全部碱基的最小比例
        haplotype_length=-1  # 不要检测连续突变的单倍型
    conda:
        env_name
    shell:
        r"""
        freebayes -f {input.ref} --min-coverage {params.min_coverage} --min-base-quality {params.min_base_quality} --min-alternate-fraction {params.min_alternate_fraction} --haplotype-length {params.haplotype_length} --vcf {output}  {input.bam}
        """

rule sample_mutation_stats:
    input:
        vcf=rules.call_freebayes.output.vcf,
        ref=lambda wildcards: REFS[sample_group[wildcards.sample]]
    output:
        stats=os.path.join(OUTDIR, "mutation_stats/{group}/{sample}.tsv")

    run:
        import subprocess, os
        os.makedirs(os.path.dirname(output.stats), exist_ok=True)
        # ensure fasta index
        if not os.path.exists(input.ref + ".fai"):
            shell("conda run --no-capture-output -n {env_name} samtools faidx {input.ref}")
        # read first contig len (but we won't rely only on first for per-contig stats)

        cmd_len = "awk '{sum += $2} END {print sum}' " + input.ref + ".fai"
        ref_len = int(subprocess.check_output(cmd_len, shell=True).strip())

        # --no-capture-output 去掉末尾的空白行
        cmd = f"conda run --no-capture-output -n {env_name} bcftools view -H {input.vcf} | wc -l"
        snp_count = int(subprocess.check_output(cmd, shell=True).strip())
        snp_per_mb = snp_count / ref_len * 1e6 if ref_len>0 else 0
        with open(output.stats, 'w') as fo:
            fo.write("sample\tmutation_count\tmutations_per_Mb\tref_len\n")
            fo.write(f"{wildcards.sample}\t{snp_count}\t{snp_per_mb}\t{ref_len}\n")


rule count_mutations:
    input:
        vcf=rules.call_freebayes.output.vcf,
        cov=rules.samtools_stats.output.cov
    output:
        os.path.join(OUTDIR,"mutation_stats_contig/{group}/{sample}.tsv")
    conda:
        env_name
    script:
        "scripts/python/intra_calde_ref_genome_mapping_SNVs/count_mutations.py"



rule merge_clade:
    input:
        lambda wildcards: expand(os.path.join(OUTDIR,"mutation_stats_contig/{clade}/{sample}.tsv"),
                                 clade=wildcards.clade,
                                 sample=group_dict.get_group(wildcards.clade)['sample'].tolist())  # 每个 Clade 的样本列表
    output:
        os.path.join(OUTDIR,"mutation_stats_contig/{clade}/{clade}_merged.tsv")
    run:
        import pandas as pd
        import os

        dfs = []
        for f in input:
            df = pd.read_csv(f, sep="\t")
            sample = os.path.basename(f).split(".")[0]  # 去掉 .mut_stats.tsv
            df["Sample"] = sample
            dfs.append(df)
        out_df = pd.concat(dfs)
        out_df["Clade"] = wildcards.clade
        out_df.to_csv(output[0], sep="\t", index=False)
