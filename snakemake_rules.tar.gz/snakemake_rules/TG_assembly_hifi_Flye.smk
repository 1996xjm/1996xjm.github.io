"""
name: Third generation sequence assembly
date: 2023-04-24
description: Snakemake pipeline to do Third generation sequence assembly
author: Jianmin Xie
dependencies:
    - fastp = 0.23.2
    - flye = 2.9.2
    - minimap2 = 2.24
    - samtools = 1.17
    - pilon = 1.24
    - bakta = 1.9.2
    - prodigal
    - biopython
    - pandas

rules:
    - fastp
    - flye
    - minimap2
    - pilon


"""

import os
configfile: "configs/TG_assembly_config.yaml"

pilon_jar = config["pilon_jar"]
TG_reads_dir = config["TG_reads_dir"]
# polish_times = config["polish_times"] # polishing recurse time
env_name = config["env_name"]
bakta_db = config["bakta_db"]
SAMPLES = os.listdir(TG_reads_dir)

FASTP_OUT_PATH = "fastp_output"
flye_OUT_PATH = "flye_output"
minimap2_OUT_PATH = "minimap2_output"
pilon_OUT_PATH = "pilon_output"
final_genome_PATH = "TG_genome"
unfixed_genome_PATH = "TG_unfixed_genome"
prodigal_OUT_PATH = "prodigal_output"
bakta_replicons_table_dir = "bakta_replicons_table"
checkM_output = "checkM_output"
busco_output = "busco_output"
bakta_output = "bakta_output"
pgap_output = "pgap_output"
merge_annotation_output = "merge_annotation"

shell.executable('/bin/zsh') # set a shell to run commands


quality_assessment_config = {
    "genome_dir": final_genome_PATH,
    "env_name": config["quality_assessment_env_name"],
    "samples": SAMPLES,
    "busco_database": config["busco_database"],
    "checkM_output": checkM_output,
    "busco_output": busco_output
}

module quality_assessment_m:
    snakefile: "modules/quality_assessment_module.smk"
    config: quality_assessment_config


genome_annotation_config = {
        "bakta_db":bakta_db,
        "genome_dir":final_genome_PATH,
        "bakta_replicons_table_dir":bakta_replicons_table_dir,
        "organism":config["organism"],
        "env_name":env_name,
        "samples": SAMPLES,
        "bakta_output": bakta_output,
        "pgap_output": pgap_output,
        "merge_annotation_output": merge_annotation_output,
    }
module genome_annotation_m:
    snakefile: "modules/genome_annotation.smk"
    config: genome_annotation_config

use rule * from quality_assessment_m as qa_*
use rule * from genome_annotation_m as ga_*

rule all:
    input:
        busco_output + "/batch_summary.tsv",
        checkM_output + "/checkm_result.tsv",
        # expand(bakta_output + "/{sample}/{sample}.faa",sample=SAMPLES),
        # expand(pgap_output + "/{sample}/result",sample=SAMPLES),
        expand(merge_annotation_output + "/{sample}_annotation.tsv",sample=SAMPLES),

    default_target: True







# mapping
rule flye:
    input:
        TG_reads_dir + "/{sample}/{sample}.hifi.fastq.gz"
    output:
        ensure(flye_OUT_PATH + "/{sample}/assembly.fasta", non_empty=True)
    params:
        genomeSize = lambda wildcards: config["genome_size"][wildcards.sample], #不同样本可能具体匹配, flye可以不指定这个 对于Phaeobacter gallaeciensis 4.5m的组装效果比4.7m好
        outdir = flye_OUT_PATH + "/{sample}",
        asm_coverage = 300 #限制测序深度，测序深度过高会组装失败！试过填500也失败，Using longest 300x reads for contig assembly
    threads: workflow.cores * (0.3 if len(SAMPLES) > 1 else 1)
    log:
        "logs/flye/{sample}_flye.log"
    benchmark:
        "benchmarks/flye/{sample}_benchmark.tsv"
    conda:
        env_name
    shell:
        "flye --pacbio-hifi {input} -g {params.genomeSize} --asm-coverage {params.asm_coverage} --out-dir {params.outdir} --threads {threads} &> {log}"




# contig重命名
rule rename:
    input:
        rules.flye.output
    output:
        fasta = unfixed_genome_PATH + "/{sample}_unfixed.fasta",
        bakta_replicons_table=bakta_replicons_table_dir + "/{sample}_replicons.tsv"
    params:
        sample = "{sample}",
        assembly_info = flye_OUT_PATH + "/{sample}/assembly_info.txt",
        polish_times = 0
    log:
        "logs/rename/{sample}_rename.log"
    conda:
        env_name
    script:
        "scripts/python/rename_TG_genome.py"



# 修复成环contig两端可能存在的断裂基因
# Prodigal预测ORF，找到第一个没有ORF重叠的间隔区，把间隔区前面的序列挪到contig的尾部
rule prodigal:
    input:
        rules.rename.output.fasta
    output:
        prodigal_OUT_PATH + "/{sample}_unfixed.gff"
    conda:
        env_name
    log:
        "logs/prodigal/{sample}_prodigal.log"
    shell:
        "prodigal -i {input} -f gff -o {output} &> {log};"
        "sed -i '/^#/d' {output}" # 删除注释行 方便pandas读取



rule fix_genome:
    input:
        genome = rules.rename.output.fasta,
        gff = rules.prodigal.output
    output:
        final_genome_PATH + "/{sample}.fasta"
    log:
        "logs/fix_genome/{sample}_fix_genome.log"
    conda:
        env_name
    script:
        "scripts/python/fix_TG_genome.py"






