"""
name: get taxon from NCBI
date: 2023-11-18
description: Snakemake pipeline to get taxon using assembly accession number
author: Jianmin Xie
dependencies:
    - lxml = 4.9.3,
rules:
    - make_db
"""
import os
from os import path

shell.executable('/bin/zsh') # set a shell to run commands

id_txt = "/Users/xjm/Desktop/CYR/德国新菌/Verrucomicrobiae/skani/retained_genome_id.txt"

taxon_url_dir = "taxon_url_output"
taxon_text_dir = "taxon_text_output"



with open(id_txt, "r") as f:
    SAMPLES = f.read().split("\n")
    # SAMPLES = ["GCA_017570505.1"]




rule all:
    input:
        "all_Taxonomy.tsv"


rule get_taxon_id:
    params:
        accession = "{sample}"
    output:
        temp(taxon_url_dir + "/{sample}.txt")
    log:
        "logs/get_taxon_id/{sample}.log"
    retries: 4
    conda:
        "coding_env"
    script:
        "scripts/python/get_taxon_id_by_assembly_accession.py"

rule get_taxon_text:
    input:
        rules.get_taxon_id.output
    output:
        taxon_text_dir + "/{sample}.txt"
    log:
        "logs/get_taxon_text/{sample}.log"
    retries: 4
    conda:
        "coding_env"
    script:
        "scripts/python/get_taxon_text_by_taxon_id.py"

rule cat:
    input:
        expand(taxon_text_dir + "/{sample}.txt",sample=SAMPLES)
    params:
        dir = taxon_text_dir
    output:
        "all_Taxonomy.tsv"
    run:
        max_length = 0
        line_list = []
        for line in shell("cat {params.dir}/*",iterable=True):
            line_strip = line.strip()
            level_length = len(line_strip.split("\t")) - 1
            if level_length > max_length:
                max_length = level_length
            line_list.append(line_strip)
        with open(output[0], "w") as f:
            header = "\t".join(["acc ID", "tax ID"]+[f"level_{i}" for i in range(1,max_length)])
            line_list = [header] + line_list
            f.write("\n".join(line_list))
