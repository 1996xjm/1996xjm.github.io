"""
name: call SNPs with reference genome
date: 2024-04-07
description: Snakemake pipeline to call SNPs with single reference genome
author: Jianmin Xie
dependencies:
    - bowtie2
    - freebayes = 1.3.6 https://github.com/freebayes/freebayes  最新的1.3.7 有bug
    - snpEff
rules:
    -
"""
import os
from os import path
import pandas as pd
shell.executable('/bin/zsh') # set a shell to run commands

configfile: "configs/call_SNPs_config.yaml"

env_name = config["env_name"]
ref_genome = config["ref_genome"]
ref_gbk = config["ref_gbk"]
single_copy_gene_info = config["single_copy_gene_info"]
fastp_output = config["fastp_output"]
is_phred64 = config.get("is_phred64",False)

bowtie2_index = "bowtie2_index"
bowtie2_output = "bowtie2_output"
call_variants_output = "call_variants_output"
variants_annotation_output = "variants_annotation_output"
variants_annotation_summary_output = "variants_annotation_summary"

blast_db_output = "blast_db"


genome_name = ".".join(path.basename(ref_genome).split(".")[:-1])

SAMPLES =  [i for i in os.listdir(fastp_output) if i != genome_name]

single_copy_gene_list = pd.read_table(single_copy_gene_info,index_col=0).index.to_list()

rule all:
    input:
        expand(bowtie2_output + "/{sample}/{sample}_{type}.tsv", sample=SAMPLES, type=["idxstats", "coverage"]),
        variants_annotation_summary_output + "/SNV_count_info",
        variants_annotation_summary_output + "/base_changes_info",
        variants_annotation_summary_output + "/SNV_codon_position_info",
        variants_annotation_summary_output + "/AA_changes_info",
        bowtie2_index+ f"/{genome_name}.1.bt2",
        variants_annotation_output + f"/config/data/{genome_name}/snpEffectPredictor.bin"
    default_target: True


# 参考文档：https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml
rule build_bowtie2_index:
    input:
        ref_genome
    output:
        bowtie2_index + f"/{genome_name}.1.bt2"
    params:
        index_prifix=bowtie2_index + f"/{genome_name}"
    threads: 32
    log:
        "logs/build_bowtie2_index.log"
    conda:
        env_name
    shell:
        "bowtie2-build --threads {threads} {input} {params.index_prifix} &> {log}"

# 参考文档：https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml
rule bowtie2:
    input:
        r1=fastp_output + "/{sample}/{sample}_paired_1.fq.gz",
        r2=fastp_output + "/{sample}/{sample}_paired_2.fq.gz",
        bowtie2_index = rules.build_bowtie2_index.output
    output:
        temp(bowtie2_output + "/{sample}/{sample}.sam")
    params:
        index_prifix=bowtie2_index + f"/{genome_name}",
        is_phred64 = "--phred64" if is_phred64 else ""
    log:
        "logs/bowtie2/{sample}_bowtie2.log"
    conda:
        env_name
    threads: 64
    shell:
        "bowtie2 -x {params.index_prifix} -1 {input.r1} -2 {input.r2} -S {output} -p {threads} {params.is_phred64} &> {log}"


# 排序与压缩
rule samtools_sort:
    input:
        rules.bowtie2.output
    output:
        bam = temp(bowtie2_output + "/{sample}/{sample}.sort.bam"),
        bai = temp(bowtie2_output + "/{sample}/{sample}.sort.bam.bai"),

    threads: 24
    conda:
        env_name
    log:
        "logs/samtools_sort/{sample}_samtools.log"
    shell:
        "samtools sort -O BAM -o {output.bam} -@ {threads} {input} &> {log};"
        "samtools index -@ {threads} {output.bam};"



rule mapping_summary:
    input:
        bam = rules.samtools_sort.output.bam,
        bai = rules.samtools_sort.output.bai,
    output:
        idxstats = bowtie2_output + "/{sample}/{sample}_idxstats.tsv",
        flagstat = bowtie2_output + "/{sample}/{sample}_flagstat.txt",
        coverage = bowtie2_output + "/{sample}/{sample}_coverage.tsv",
        coverage_histogram = bowtie2_output + "/{sample}/{sample}_coverage_histogram.tsv",
        depth_histogram = bowtie2_output + "/{sample}/{sample}_depth_histogram.tsv",
    conda:
        env_name
    shell:
        "samtools idxstats {input.bam} > {output.idxstats};"
        "samtools flagstat {input.bam} > {output.flagstat};"
        "samtools coverage {input.bam} > {output.coverage};"
        "samtools coverage -A {input.bam} > {output.coverage_histogram};"
        "samtools coverage -A --plot-depth {input.bam} > {output.depth_histogram};"



# 过滤掉没有比对上的
rule samtools_filter:
    input:
        rules.samtools_sort.output.bam
    output:
        bowtie2_output + "/{sample}/{sample}.mapped.sort.bam"

    threads: 24
    conda:
        env_name
    log:
        "logs/samtools_filter/{sample}_samtools.log"
    shell:
        "samtools view -F 4 -@ {threads} -bS -o {output} {input} &> {log};" # -F 4 滤掉没有mapping上records
        "samtools index -@ {threads} {output};"


def get_gene_region(w):
    gene_df = pd.read_table(single_copy_gene_info,index_col=0)

    return f"{gene_df.loc[w.gene,'Seqname']}:{gene_df.loc[w.gene,'Start']}-{gene_df.loc[w.gene,'End']}"

# 按照基因区域来计算
# rule freebayes:
#     input:
#         bam = rules.samtools_filter.output,
#         ref_genome = ref_genome
#     output:
#         call_variants_output + "/{gene}/{sample}.vcf"
#     params:
#         gene_region = get_gene_region,
#         min_coverage = 10, # mapping深度
#         min_base_quality = 20, # 碱基测序质量对于这个数字才会被考虑
#         min_alternate_fraction = 0.75, # 这一列突变碱基所占全部碱基的最小比例
#         haplotype_length = -1 # 不要检测连续突变的单倍型
#     conda:
#         env_name
#     shell:
#         "freebayes -f {input.ref_genome} -r {params.gene_region} --min-coverage {params.min_coverage} --min-base-quality {params.min_base_quality} --min-alternate-fraction {params.min_alternate_fraction} --haplotype-length {params.haplotype_length}  {input.bam} > {output}"

# 全基因组计算
rule freebayes:
    input:
        bam = rules.samtools_filter.output,
        ref_genome = ref_genome
    output:
        call_variants_output + "/{sample}.vcf"
    params:
        min_coverage = 10, # mapping深度
        min_base_quality = 20, # 碱基测序质量对于这个数字才会被考虑
        min_alternate_fraction = 0.75, # 这一列突变碱基所占全部碱基的最小比例
        haplotype_length = -1 # 不要检测连续突变的单倍型
    conda:
        env_name
    shell:
        "freebayes -f {input.ref_genome} --min-coverage {params.min_coverage} --min-base-quality {params.min_base_quality} --min-alternate-fraction {params.min_alternate_fraction} --haplotype-length {params.haplotype_length} --vcf {output}  {input.bam}"



rule snpEff_config:
    input:
        ref_gbk = ref_gbk,
        ref_genome = ref_genome
    output:
        config_file = variants_annotation_output + "/config/snpEff.config",
        ref_gbk = variants_annotation_output + f"/config/data/{genome_name}/genes.gbk"
    run:
        shell("cp {input.ref_gbk} {output.ref_gbk}")
        base_str = f"""codon.Bacterial_and_Plant_Plastid : TTT/F , TTC/F , TTA/L , TTG/L+, TCT/S , TCC/S , TCA/S , TCG/S , TAT/Y , TAC/Y , TAA/* , TAG/* , TGT/C , TGC/C , TGA/* , TGG/W , CTT/L , CTC/L , CTA/L , CTG/L+, CCT/P , CCC/P , CCA/P , CCG/P , CAT/H , CAC/H , CAA/Q , CAG/Q , CGT/R , CGC/R , CGA/R , CGG/R , ATT/I+, ATC/I+, ATA/I+, ATG/M+, ACT/T , ACC/T , ACA/T , ACG/T , AAT/N , AAC/N , AAA/K , AAG/K , AGT/S , AGC/S , AGA/R , AGG/R , GTT/V , GTC/V , GTA/V , GTG/V+, GCT/A , GCC/A , GCA/A , GCG/A , GAT/D , GAC/D , GAA/E , GAG/E , GGT/G , GGC/G , GGA/G , GGG/G

{genome_name}.genome : {genome_name}
"""
        for line in shell("grep '>' {input.ref_genome}",iterable=True):
            base_str += f"{genome_name}.{line.strip().split(' ')[0][1:]}.codonTable : Bacterial_and_Plant_Plastid\n"
        with open(output.config_file, "w") as f:
            f.write(base_str)


rule build_snpEff_database:
    input:
        rules.snpEff_config.output.config_file
    output:
        variants_annotation_output + f"/config/data/{genome_name}/snpEffectPredictor.bin"
    conda:
        env_name
    log:
        "logs/build_snpEff_database.log"
    shell:
        "snpEff build -genbank -c {input} -v {genome_name} &> {log}"

rule run_snpEff:
    input:
        config_file = rules.snpEff_config.output.config_file,
        vcf_file = rules.freebayes.output
    output:
        ann_vcf = variants_annotation_output + "/result/{sample}/{sample}_ann.vcf",
        summary_html = variants_annotation_output + "/result/{sample}/{sample}_ann_summary.html"
    log:
        "logs/run_snpEff/{sample}_snpEff.log"
    conda:
        env_name
    shell:
        "(snpEff -no-downstream -no-upstream -no-utr -no-intergenic -c {input.config_file} -htmlStats {output.summary_html} -v {genome_name} {input.vcf_file} > {output.ann_vcf}) &> {log}"


rule summary_variants_annotation:
    input:
        ann_vcf_list = expand(variants_annotation_output + "/result/{sample}/{sample}_ann.vcf", sample=SAMPLES),
        single_copy_gene_info = single_copy_gene_info,
    output:
        SNV_info_dir = directory(variants_annotation_summary_output + "/SNV_count_info"),
        base_changes_info_dir = directory(variants_annotation_summary_output + "/base_changes_info"),
        SNV_codon_position_info_dir = directory(variants_annotation_summary_output + "/SNV_codon_position_info"),
        SNV_variant_type_info_dir = directory(variants_annotation_summary_output + "/SNV_variant_type_info"),
        AA_changes_info_dir = directory(variants_annotation_summary_output + "/AA_changes_info"),
    conda:
        env_name
    log:
        "logs/summary_variants_annotation.log"
    script:
        "scripts/python/summary_variants_annotation.py"
