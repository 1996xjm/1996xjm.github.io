"""
name: 16S rRNA amplicon
date: 2023-12-10
description: Snakemake pipeline to do 16S rRNA amplicon analysis
author: Jianmin Xie
dependencies:
    - bioconductor-shortread = 1.60.0 # r-base is in this package
    - bioconductor-dada2 = 1.30.0
    - bioconductor-phyloseq = 1.46.0
    - r-pheatmap = 1.0.12
    - r-ggplot2 = 3.4.4
    - r-dplyr = 1.1.4 # 数据框分组聚合
    - r-phangorn # 进化树
    - cutadapt = 4.5
    - mafft # 多序列比对
    - fasttree # 进化树
    - biopython
    - pandas

rules:
    - fastp
    - flye
    - minimap2
    - pilon



references:
    dada2: https://bioconductor.org/packages/3.18/bioc/vignettes/dada2/inst/doc/dada2-intro.html

"""

import os
from os import path
configfile: "configs/16S_rRNA_amplicon_config.yaml"

samples_dir = config["samples_dir"]
env_name = config["env_name"]
SAMPLES = os.listdir(samples_dir)


f_suffix = config["f_suffix"]
r_suffix = config["r_suffix"]


f_primer = config["f_primer"]
r_primer = config["r_primer"]
phred_offset = config["phred_offset"]

minFoldParentOverAbundance = config["minFoldParentOverAbundance"]


max_error_num = config["max_error_num"]
is_raw_data = config["is_raw_data"]
db_taxon_file = config["db_taxon_file"]
db_spec_file = config["db_spec_file"]
error_rate_learning_nbases = config["error_rate_learning_nbases"]


custom_pipeline_output = f"custom_pipeline_output_mfp{minFoldParentOverAbundance}"
renamed_reads = "renamed_reads"


logs_dir = f"logs"
benchmarks = "benchmarks"



flash_output = "flash_output"
cutadapt_output = "cutadapt_output"
mafft_output = "mafft_output"
fasttree_output = "fasttree_output"



dada2_single_end_output = "dada2_single_end_output"
summary_output = "summary_output"
figure_output = "figure_output"
ez_output = "ez_output"
taxonomy_databases_output = "taxonomy_databases"

shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand(dada2_single_end_output + "/seqs/ASV_seqs_{type}_chloro_mito.fasta", type=["no","with"]),
        expand(dada2_single_end_output + "/tables/{file}_{type}_chloro_mito.tsv", file=["ASV_taxon","seq_table"], type=["no","with"]),
        expand(dada2_single_end_output + "/tables/{name}.tsv", name=["seq_table_prop_no_chloro_mito", "ASV_prevalence_totalAbundance"]),
        expand(summary_output + "/cutadapter/{type}_length_frequency_distribution_{order}_cutting.tsv", type=["R1", "R2"], order=["before", "after"]),
        expand(figure_output + "/cutadapter/{type}_length_frequency_distribution_{order}_cutting.png", type=["R1", "R2"], order=["before", "after"]),
        expand(summary_output + "/dada2/{type}.tsv", type=["denoising_stats","assign_taxonomy_stats"]),
        summary_output + "/alpha_diversity/alpha_diversity.tsv"

    default_target: True

# read id 不一致会导致cutadapt报错，去掉注释部分, 有些fastq文件有，大部分没有这个注释, 有需要再开启这个步骤
# @FCH7VFCBCX3:2:1101:13304:2183#TCA_CTACGACC_AGGCTTGT/1
# @FCH7VFCBCX3:2:1101:13304:2183#TTCCA_CTACGACC_AGGCTTGT/2
# rule rename_reads_id:
#     input:
#         r1 = samples_dir + "/{sample}/{sample}_1.fq.gz",
#         r2 = samples_dir + "/{sample}/{sample}_2.fq.gz"
#     output:
#         r1=temp(renamed_reads + "/{sample}/{sample}_1.fq"),
#         r2=temp(renamed_reads + "/{sample}/{sample}_2.fq")
#     shell:
#         "zcat {input.r1}|sed 's/#.*\/1$/\/1/g' > {output.r1};"
#         "zcat {input.r2}|sed 's/#.*\/2$/\/2/g' > {output.r2}"
#


rule cutadapt:
    input:
        r1 = samples_dir + "/{sample}/{sample}" + f_suffix,
        r2 = samples_dir + "/{sample}/{sample}" + r_suffix
    output:
        r1 = cutadapt_output + "/{sample}/{sample}_1.fq.gz",
        r2 = cutadapt_output + "/{sample}/{sample}_2.fq.gz"
    log:
        logs_dir + "/cutadapt/{sample}_cutadapt.log"
    threads: 16
    params:
        f_adapter = f_primer,
        r_adapter = r_primer,
        max_error_num = max_error_num,
        phred_offset= phred_offset, # 只有很早期是数据是64，现在都是33
        is_raw_data = is_raw_data
    conda:
        env_name
    shell:
        # 不是rawdata的数据要指定为anchor的primer，因为前面没有primer，他会往序列的中间找，导致误裁剪
        # -q 裁剪3'端低质量碱基，裁不裁剪结果对XJM的样品几乎无差别，就是最终保留的序列有+-10条的区别，相比于没有裁剪的组，有裁剪的最终保留序列增加的样品会比序列变少的样品多一些
        # 对曲立平的数据显著影响了拼接率，没有裁剪会导致拼接率降低，可能曲立平的数据质量太低，overlap区域的错配率高于设定的阈值0.1，所以还是裁剪比较好
        """if [[ {params.is_raw_data} == "True" ]] {{
    cutadapt --discard-untrimmed -q 20 --quality-base {params.phred_offset}  -g F_primer={params.f_adapter} -G R_primer={params.r_adapter} -e {params.max_error_num} -o {output.r1} -p {output.r2} {input.r1} {input.r2} &> {log}
}} else {{
    cutadapt -q 20 --quality-base {params.phred_offset}  -g F_primer=^{params.f_adapter} -G R_primer=^{params.r_adapter} -e {params.max_error_num} -o {output.r1} -p {output.r2} {input.r1} {input.r2} &> {log}
}}"""


rule reads_length_frequency_distribution_before_cutting:
    input:
        r1 = expand(samples_dir + "/{sample}/{sample}" + f_suffix, sample=SAMPLES),
        r2 = expand(samples_dir + "/{sample}/{sample}" + r_suffix, sample=SAMPLES)
    output:
        r1 = summary_output + "/cutadapter/R1_length_frequency_distribution_before_cutting.tsv",
        r2 = summary_output + "/cutadapter/R2_length_frequency_distribution_before_cutting.tsv",
        r1_fig = figure_output + "/cutadapter/R1_length_frequency_distribution_before_cutting.png",
        r2_fig = figure_output + "/cutadapter/R2_length_frequency_distribution_before_cutting.png",

    log:
        logs_dir + "/reads_len_freq_dist_before_cutting.log"
    conda:
        env_name
    script:
        "scripts/R/reads_length_frequency_distribution.R"


rule reads_length_frequency_distribution_after_cutting:
    input:
        r1 = expand(cutadapt_output + "/{sample}/{sample}_1.fq.gz", sample=SAMPLES),
        r2 = expand(cutadapt_output + "/{sample}/{sample}_2.fq.gz", sample=SAMPLES)
    output:
        r1 = summary_output + "/cutadapter/R1_length_frequency_distribution_after_cutting.tsv",
        r2 = summary_output + "/cutadapter/R2_length_frequency_distribution_after_cutting.tsv",
        r1_fig= figure_output + "/cutadapter/R1_length_frequency_distribution_after_cutting.png",
        r2_fig=figure_output + "/cutadapter/R2_length_frequency_distribution_after_cutting.png",
    log:
        logs_dir + "/reads_len_freq_dist_after_cutting.log"
    conda:
        env_name
    script:
        "scripts/R/reads_length_frequency_distribution.R"

rule flash:
    input:
        r1 = rules.cutadapt.output.r1,
        r2 = rules.cutadapt.output.r2,
    output:
        flash_output + "/{sample}/{sample}.extendedFrags.fastq"
    log:
        logs_dir + "/flash/{sample}_flash.log" # 注意看这个日志里面有没有提示Max overlap过低的waring，如果有要提高这个数值
    threads: 16
    params:
        prefix = "{sample}",
        out_dir = flash_output + "/{sample}",
        phred_offset = phred_offset,
        max_overlap = 250 # 最大重叠长度，如果重叠区大于这个长度也会正常拼接，但是下面的错配比率的分母还是按照这个值去算而不是整个重叠区长度，会导致拼接失败的比例升高 [default: 65]
    conda:
        env_name
    shell:
        "flash -m 15 -M {params.max_overlap} -x 0.1 -o {params.prefix} -d {params.out_dir} -p {params.phred_offset} -t {threads} {input.r1} {input.r2} &> {log}"






rule dada2_single_end_reads:
    input:
        cr1 = expand(cutadapt_output + "/{sample}/{sample}_1.fq.gz", sample=SAMPLES),
        merged_seq = expand(flash_output + "/{sample}/{sample}.extendedFrags.fastq", sample=SAMPLES)
    output:
        rep_seqs = dada2_single_end_output + "/seqs/ASV_seqs_nochim.fasta",
        seq_table = dada2_single_end_output + "/RData/seq_table_nochim.RData",
        tsv= summary_output + "/dada2/denoising_stats.tsv",
    params:
        minFoldParentOverAbundance = minFoldParentOverAbundance,
        nbases = error_rate_learning_nbases # 错误率学习的采样数量，会影响降噪的准确度，1e8 大概能采样70000readsX4样品
    benchmark:
        benchmarks + "/dada2_single_end_reads_benchmark.tsv"
    log:
        logs_dir + "/dada2_single_filter_reads.log"
    conda:
        env_name
    script:
        "scripts/R/dada2/dada2_single_reads_multi_samples.R"



rule assign_taxonomy:
    input:
        seq_table = rules.dada2_single_end_reads.output.seq_table,
        db_taxon = db_taxon_file,
        db_spec = db_spec_file
    output:
        taxon_no_chloro_mito_tsv = dada2_single_end_output + "/tables/ASV_taxon_no_chloro_mito.tsv",
        taxon_with_chloro_mito_tsv = dada2_single_end_output + "/tables/ASV_taxon_with_chloro_mito.tsv",
        seq_table_no_chloro_mito = dada2_single_end_output + "/tables/seq_table_no_chloro_mito.tsv",
        seq_table_no_chloro_mito_biom = dada2_single_end_output + "/tables/seq_table_no_chloro_mito.biom",
        seq_table_with_chloro_mito = dada2_single_end_output + "/tables/seq_table_with_chloro_mito.tsv",
        rep_seqs_no_chloro_mito = dada2_single_end_output + "/seqs/ASV_seqs_no_chloro_mito.fasta",
        rep_seqs_with_chloro_mito = dada2_single_end_output + "/seqs/ASV_seqs_with_chloro_mito.fasta",
        stats_tsv= summary_output + "/dada2/assign_taxonomy_stats.tsv",
        phyloseq_object_file = dada2_single_end_output + "/RData/phyloseq_object.RData"
    conda:
        env_name
    log:
        logs_dir + "/assign_taxonomy.log"
    script:
        "scripts/R/dada2/assign_taxonomy.R"


rule mafft:
    input:
        rules.assign_taxonomy.output.rep_seqs_no_chloro_mito
    output:
        mafft_output + "/ASV_seqs_no_chloro_mito_align.fasta"
    conda:
        env_name
    log:
        logs_dir + "/mafft.log"
    shell:
        "(mafft --auto {input} > {output}) &> {log}"


rule fasttree:
    input:
        rules.mafft.output
    output:
        fasttree_output + "/ASV_seqs_no_chloro_mito_tree.nwk"
    conda:
        env_name
    log:
        logs_dir + "/fasttree.log"
    shell:
        "(FastTree -gtr -nt {input} > {output}) &> {log}"


rule downstream_analysis:
    input:
        phyloseq_object_file = rules.assign_taxonomy.output.phyloseq_object_file,
        tree_file = rules.fasttree.output
    output:
        seq_table_prop_no_chloro_mito = dada2_single_end_output + "/tables/seq_table_prop_no_chloro_mito.tsv",
        prevalence_totalAbundance_table = dada2_single_end_output + "/tables/ASV_prevalence_totalAbundance.tsv",
        alpha_diversity_tsv= summary_output + "/alpha_diversity/alpha_diversity.tsv",
    params:
        alpha_diversity_fig_dir=figure_output + "/alpha_diversity",
        beta_diversity_table_dir=summary_output + "/beta_diversity",
        prevalence_fig_dir=figure_output + "/prevalence",
        stacked_bar_plot_table_dir=summary_output + "/stacked_bar_plot",
    conda:
        env_name
    log:
        logs_dir + "/downstream_analysis.log"
    script:
        "scripts/R/dada2/downstream_analysis.R"


