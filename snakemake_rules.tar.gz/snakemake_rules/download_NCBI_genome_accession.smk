"""
name: download NCBI genome
date: 2023-01-05
description: Snakemake pipeline to download NCBI genome
author: Jianmin Xie
dependencies:
    - datasets = 14.6.4,
rules:
    - download


"""


DOWNLOAD_OUT_PATH = "download_result"
accession_list_file = config["accession"]
CHECKM_OUT_PATH = "checkM_output"


with open(accession_list_file,"r") as f:
    kk = f.read()
    SAMPLE = kk.strip().split("\n")


shell.executable('/bin/zsh') # set a shell to run commands



rule all:
    input:
        expand(DOWNLOAD_OUT_PATH + "/genomes/{sample}.fna", sample=SAMPLE),
        CHECKM_OUT_PATH + "/checkm_result.tsv",
    default_target: True

rule download:
    output:
        temp(ensure(DOWNLOAD_OUT_PATH + "/temp/{sample}.zip", non_empty=True))
    shell:
        "datasets download genome accession {wildcards.sample} --include genome --filename {output} &> /dev/null"

rule unzip:
    input:
        rules.download.output
    output:
        genome = ensure(DOWNLOAD_OUT_PATH + "/genomes/{sample}.fna", non_empty=True),
        unzip_dir = temp(directory(DOWNLOAD_OUT_PATH + "/temp/{sample}"))
    shell:
        "unzip -d {output.unzip_dir} {input} &> /dev/null;"
        "mv {output.unzip_dir}/ncbi_dataset/data/*/*.fna {output.genome}"


rule checkM:
    input:
        expand(DOWNLOAD_OUT_PATH + "/genomes/{sample}.fna", sample=SAMPLE)
    output:
        ensure(CHECKM_OUT_PATH + "/checkm_result.tsv", non_empty=True)
    params:
        dir = DOWNLOAD_OUT_PATH + "/genomes",
        tem =CHECKM_OUT_PATH + "/checkm_tem",
        suffix = "fna",
        tax_rank = "class",
        tax = "Verrucomicrobiae",
    threads: workflow.cores
    conda:
        "quality_assessment"
    log:
        "logs/checkM/checkM.log"
    shell:
        "checkm taxonomy_wf -f {output} --tab_table -x {params.suffix} -t {threads} {params.tax_rank} {params.tax} {params.dir} {params.tem} &> {log}"


