"""
name: TG genome loop polishing
date: 2024-01-09
description: Snakemake pipeline to do TG genome loop polishing
author: Jianmin Xie
dependencies:
    - minimap2 = 2.24
    - samtools = 1.17
    - pilon = 1.24


rules:
    - fastp
    - flye
    - minimap2
    - pilon


"""

from os import path

loop_times = config["loop"]
genome = config["genome"]
pilon_jar = config["jar"]
r1 = config["r1"]
r2 = config["r2"]

env_name = config["env"]
SAMPLES = [".".join(path.basename(genome).split(".")[:-1])]


minimap2_OUT_PATH = "minimap2_output"
pilon_OUT_PATH = "pilon_output"
final_genome_PATH = "TG_genome"


rule all:
    input:
        expand(pilon_OUT_PATH + f"_{loop_times}" + "/{sample}/{sample}" + f"_pilon_{loop_times}.fasta",sample=SAMPLES),
    default_target: True


def recurse_genome(wcs):
    n = int(wcs.n)
    if n == 1:
        return genome
    elif n > 1:
        return pilon_OUT_PATH + f"_{n-1}/{wcs.sample}/{wcs.sample}_pilon_{n-1}.fasta"
    else:
        raise ValueError(f"loop numbers must be 1 or greater: received {wcs.n}")




rule minimap2:
    input:
        genome = recurse_genome,
        r1 = r1,
        r2 = r2,
    output:
        minimap2_OUT_PATH + "_{n}/{sample}/{sample}_aln.bam"
    threads: 10
    log:
        "logs/minimap2_{n}/{sample}_minimap2.log"
    conda:
        env_name
    shell:
        "(minimap2 -ax sr {input.genome} {input.r1} {input.r2} | samtools sort -@ {threads} -O bam -o {output}) &> {log};"
        "samtools index -@ {threads} {output};"

rule pilon:
    input:
        genome = recurse_genome,
        bam = rules.minimap2.output
    output:
        pilon_OUT_PATH + "_{n}/{sample}/{sample}_pilon_{n}.fasta"
    params:
        prefix = "{sample}_pilon_{n}",
        outdir= pilon_OUT_PATH + "_{n}/{sample}",
        pilonJar = pilon_jar
    log:
        "logs/pilon_{n}/{sample}_pilon.log"
    shell:
        "java -Xmx16G -jar {params.pilonJar} --genome {input.genome} --frags {input.bam} --output {params.prefix} --fix all --mindepth 10 --outdir {params.outdir} --changes --verbose &> {log}"

