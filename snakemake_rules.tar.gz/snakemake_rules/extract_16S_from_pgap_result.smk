"""
name: extract 16S
date: 2023-11-17
description: Snakemake pipeline to extract 16S from genome
author: Jianmin Xie
dependencies:
    - barrnap = 0.9,
    - biopython = 1.81
rules:
    - barrnap
"""
import os
from os import path
import pandas as pd

shell.executable('/bin/zsh') # set a shell to run commands

# base_dir = "/home/xjm/cyr/Germany_novel_strain/Verrucomicrobiota_genome_all"
pgap_out_dir = config["pgap"]
genome_dir = "/home/xjm/final_representative_strain/Pha/TG_genome/genome/complete"
output_16S_gff = "16S_gff"
output_16S_fasta = "16S_fasta"
blast_db_output = "blast_db"
env_name = "barrnap"



SAMPLES = os.listdir(pgap_out_dir)
# print(len(SAMPLES))

rule all:
    input:
        "16S_identity_matrix.tsv"
        # expand(output_16S_fasta + "/{sample}.fasta", sample=SAMPLES),
        # "extract_16S.fasta"



rule grep_gff:
    input:
        pgap_out_dir + "/{sample}/result/annot.gff"
    output:
        output_16S_gff + "/{sample}.gff"
    conda:
        env_name
    shell:
        "grep '16S ribosomal RNA' {input} | grep 'rRNA\t' > {output}"

rule extract:
    input:
        gff=rules.grep_gff.output,
        genome=genome_dir+"/{sample}.fasta"
    output:
        output_16S_fasta + "/{sample}.fasta"
    conda:
        env_name

    script:
        "scripts/python/extract_16S_rRNA_gene_from_pgap_gff.py"
rule merge:
    input:
        expand(output_16S_fasta + "/{sample}.fasta", sample=SAMPLES)
    output:
        "extract_16S.fasta"
    shell:
        "cat {input} > {output}"

rule make_blast_db:
    input:
        rules.merge.output
    output:
        directory(blast_db_output)
    log:
        "log/make_blast_db.log"
    conda:
        env_name
    shell:
        "mkdir {output};"
        "makeblastdb -in {input}  -dbtype nucl -out {output}/16S &> {log}"

rule blast:
    input:
        db=rules.make_blast_db.output,
        query=rules.merge.output
    output:
        "blast_out.tsv"
    params:
        max_target_count = len(SAMPLES)
    conda:
        env_name
    shell:
        "blastn -db {input.db}/16S -query {input.query} "
        "-outfmt '6 qacc sacc pident qcovhsp qlen slen length mismatch gapopen evalue bitscore' "
        "-out {output} -evalue 1e-5 -max_target_seqs {params.max_target_count}"

rule table_to_matrix:
    input:
        rules.blast.output
    output:
        "16S_identity_matrix.tsv"
    run:
        df = pd.read_table(input[0], header=None)
        df.columns = ["qacc", "sacc", "pident", "qcovhsp", "qlen", "slen", "length", "mismatch", "gapopen", "evalue", "bitscore"]
        df_matrix = df.pivot(index='qacc',columns='sacc',values='pident')
        df_matrix.to_csv(output[0], sep="\t")


