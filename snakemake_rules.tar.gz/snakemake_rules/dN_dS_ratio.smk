"""
name: Third generation sequence assembly
date: 2023-08-16
description: Snakemake pipeline to calculate the number of synonymous substitutions per synonymous site (dS) and the number of nonsynonymous substitutions per nonsynonymous site (dN) and their ratio (dN/dS).
reference: https://web.archive.org/web/20200303040750id_/https://www.protocols.io/view/introduction-to-calculating-dn-ds-ratios-with-code-qhvdt66.pdf
author: Jianmin Xie
dependencies:
    - pal2nal.pl http://www.bork.embl.de/pal2nal/
    - clustalo or mafft
    - FastTree = 2.1 https://microbesonline.org/fasttree
    - codeml in paml = 4.10.7


rules:
    - copy_fna
    - mafft
    - pal2nal

"""

import os
from os import path
import pandas as pd
from Bio import SeqIO
import re



shell.executable('/bin/zsh') # set a shell to run commands

base_dir = "/home/xjm/final_representative_strain/Pha/population_structure/dNdS_ratio"
orthofinder_Single_Copy_Orthologue_Sequences_dir = "/home/xjm/final_representative_strain/Pha/population_structure/orthofinder_rast_prodigal/orthofinder_outgroup/Results_defaut/Single_Copy_Orthologue_Sequences"
rast_dir = "/home/xjm/final_representative_strain/Pha/genome/rast_prodigal_output"
SAMPLE = [i.replace(".fa","") for i in os.listdir(orthofinder_Single_Copy_Orthologue_Sequences_dir)]

model = 0
codeml_subfix = f"model_{model}.NSsites_0_1"


fna_OUT_PATH = path.join(base_dir, "fna")
mafft_OUT_PATH = path.join(base_dir, "mafft_output")
FastTree_OUT_PATH = path.join(base_dir, "FastTree_output")
pal2nal_OUT_PATH = path.join(base_dir, "pal2nal_output")
codeml_OUT_PATH = path.join(base_dir, "codeml_output")
statistics_OUT_PATH = path.join(base_dir, "statistics_output")

def parse_output():
    df = pd.read_table(path.join(statistics_OUT_PATH, "dNdS_result.tsv"), index_col=0)
    count_list = []
    # 可能是精度问题 0.0001或者0都是该突变类型的个数为0
    count_list.append(df[df["tree_length_dS"] <= 0.0001]["omega"].count())
    count_list.append(df[(df["tree_length_dS"] > 0.0001) & (df["tree_length_dN"] <= 0.0001)]["omega"].count())

    omega_positive = df[(df["tree_length_dS"] > 0.0001) & (df["tree_length_dN"] > 0.0001) & (df["omega"] > 1)]
    count_list.append(omega_positive["omega"].count())

    count_list.append(df[(df["tree_length_dS"] > 0.0001) & (df["tree_length_dN"] > 0.0001) & (df["omega"] == 1)]["omega"].count())

    omega_purified = df[(df["tree_length_dS"] > 0.0001) & (df["tree_length_dN"] > 0.0001) & (df["omega"] < 1)]
    omega_purified = omega_purified.sort_values(by="omega", ascending=False)
    count_list.append(omega_purified["omega"].count())

    data = {'type': ['dS=0', 'dS>0&dN=0', 'ω>1', 'ω=1', 'ω<1'],
     'count': count_list,
     }
    frame = pd.DataFrame(data)
    frame.to_csv(path.join(statistics_OUT_PATH, "proportion.tsv"), index=None, sep="\t")
    gff_df_dict = {}
    function_list = []
    for OG in omega_purified.index.tolist():
        for line in shell(f"grep '>' {path.join(fna_OUT_PATH, OG+'.fna')}", iterable=True):
            gene_id = line[1:]
            sample_name = gene_id.split(".")[0]
            if sample_name not in gff_df_dict:
                dff_df = pd.read_table(path.join(rast_dir,sample_name,f"{sample_name}.gff"),skiprows=1,header=None)

                dff_df = dff_df[8].str.replace("ID=","").str.split(";Name=",expand=True)
                dff_df = dff_df.set_index(0, drop=True)
                gff_df_dict[sample_name] = dff_df[1]
            function_list.append(gff_df_dict[sample_name][gene_id])
            break

    omega_purified["function"] = function_list
    omega_purified.to_csv(path.join(statistics_OUT_PATH, "purified_omega_function.tsv"), sep="\t")



onsuccess:
    shell(f"mkdir -p {statistics_OUT_PATH}")
    shell(f"grep -H 'tree length for dS:' codeml_output/*/*.codeml.{codeml_subfix}.txt|cut -d '/' -f2 > {path.join(statistics_OUT_PATH, 'OG.txt')}")
    shell(f"grep 'tree length for dS:' codeml_output/*/*.codeml.{codeml_subfix}.txt|rev|cut -d ' ' -f1 | rev > {path.join(statistics_OUT_PATH, 'dS.txt')}")
    shell(f"grep 'tree length for dN:' codeml_output/*/*.codeml.{codeml_subfix}.txt|rev|cut -d ' ' -f1 | rev > {path.join(statistics_OUT_PATH, 'dN.txt')}")
    shell(f"grep 'omega (dN/dS)' codeml_output/*/*.codeml.{codeml_subfix}.txt|rev|cut -d ' ' -f1 | rev > {path.join(statistics_OUT_PATH, 'omega.txt')}")
    shell(f"cd {statistics_OUT_PATH};paste OG.txt dS.txt dN.txt omega.txt > dNdS_result.tsv;sed -i '1i\OG_id\ttree_length_dS\ttree_length_dN\tomega' dNdS_result.tsv")
    parse_output()



rule all:
    input:
        expand(fna_OUT_PATH + "/{sample}.fna", sample=SAMPLE),
        expand(mafft_OUT_PATH + "/{sample}.aln.faa", sample=SAMPLE),
        expand(pal2nal_OUT_PATH + "/{sample}.pal2nal", sample=SAMPLE),
        expand(FastTree_OUT_PATH + "/{sample}.nwk", sample=SAMPLE),
        expand(codeml_OUT_PATH + "/{sample}/{sample}." + codeml_subfix + ".ctl", sample=SAMPLE),
        expand(codeml_OUT_PATH + "/{sample}/{sample}.codeml." + codeml_subfix + ".txt", sample=SAMPLE),






rule copy_fna:
    input:
        orthofinder_Single_Copy_Orthologue_Sequences_dir + "/{sample}.fa"
    output:
        fna_OUT_PATH + "/{sample}.fna"
    run:
        records = SeqIO.parse(input[0],"fasta")
        fna_records_list = []
        for rec in records:
            rec_id = rec.id
            sample_name = rec_id.split(".")[0]
            fna_path = path.join(rast_dir, sample_name, f"{sample_name}.fna")
            fna_rec = SeqIO.index(fna_path,"fasta").get(rec_id)
            fna_rec.seq = fna_rec.seq.upper()
            fna_records_list.append(fna_rec)
        with open(output[0],"w") as f:
            SeqIO.write(fna_records_list,f,"fasta")

rule mafft:
    input:
        orthofinder_Single_Copy_Orthologue_Sequences_dir + "/{sample}.fa"
    output:
        mafft_OUT_PATH + "/{sample}.aln.faa"
    shell:
        "mafft --quiet --auto {input} > {output}"



rule pal2nal:
    input:
        fna = rules.copy_fna.output,
        aln_faa = rules.mafft.output
    output:
        pal2nal_OUT_PATH + "/{sample}.pal2nal"
    shell:
        "pal2nal.pl {input.aln_faa} {input.fna} -output paml -codontable 11 -nogap > {output}"

"""
Below is an example of the PHYLIP format (Felsenstein 2005). The first line contains the number
of species and the sequence length (possibly followed by option characters).

#####
   7    519
PT24_64.peg.4182
ATGCGGATCCCTTTCGGCATGATTGTTCTGGTAGGCGCGGTGGCCGTCGCGGGCTGCTCG
CAAAAAGGTCTGCGTGATATTC
####
"""


rule FastTree:
    input:
        rules.mafft.output
    output:
        FastTree_OUT_PATH + "/{sample}.nwk"
    shell:
        """
        FastTree {input} > {output}
        speciesNum=`grep '>' {input}|wc -l`
        sed -i "1i\   $speciesNum  1" {output}
        """

"""
The first line contains the number of species and the number of trees in the file

####
   7  1
((PT47_15.peg.4052:0.00393,(PT34_48.peg.1319:0.00982,SY12_1.peg.1887:0.00194)0.894:0.00392)0.758:0.00196,(PT24_64.peg.1237:0.00196,PT42_8.peg.983:0.00787)0.878:0.00393,(PT41_83.peg.2013:0.00787,SY47_7.peg.2589:0.01386)0.777:0.00196);
####
"""



rule make_ctl_file:
    input:
        rules.pal2nal.output,
        rules.FastTree.output
    output:
        codeml_OUT_PATH + "/{sample}/{sample}." + codeml_subfix + ".ctl"
    params:
        codeml_OUT_PATH + "/{sample}/{sample}.codeml." + codeml_subfix + ".txt"
    run:
        ctl_str = f"""seqfile = {input[0]} * sequence data filename
outfile = {params[0]} * main result file name
treefile = {input[1]}
noisy = 9 * 0,1,2,3,9: how much rubbish on the screen
verbose = 1 * 1:detailed output
runmode = 0 * 0: user tree; -2: pairwise
seqtype = 1 *  1:codons; 2:AAs; 3:codons-->AAs
CodonFreq = 2 * 0:equal, 1:F1X4, 2:F3X4, 3:F61
model = {model} * 0:one, 1:b, 2:2 or more dN/dS ratios for branches
NSsites = 0 1 *
icode = 0 * 0:universal code
fix_kappa = 0 * 1:kappa fixed, 0:kappa to be estimated
kappa = 1 * initial or fixed kappa
fix_omega = 0 * 1:omega fixed, 0:omega to be estimated
omega = 0.4 * initial omega value
ndata = 1
getSE = 0 * 0: don't want them, 1: want S.E.s of estimates
RateAncestor = 0 * (0,1,2): rates (alpha>0) or ancestral states (1 or 2)
Small_Diff = .45e-6
cleandata = 0 * remove sites with ambiguity data (1:yes, 0:no)"""
        with open(output[0], "w") as f:
            f.write(ctl_str)

rule codeml:
    input:
        rules.make_ctl_file.output
    output:
        codeml_OUT_PATH + "/{sample}/{sample}.codeml." + codeml_subfix + ".txt"
    log:
        codeml_OUT_PATH + "/{sample}/{sample}.codeml." + codeml_subfix + ".log"
    params:
        pwd = codeml_OUT_PATH + "/{sample}"
    shell:
        "cd {params.pwd};codeml {input} &> {log}"

"""
Error: too many daughter nodes, raise MAXNSONS

####
Ziheng
未读，
2013年3月6日 14:57:22
收件人 pamlso...@googlegroups.com

that error is generated when you have a multifurcating tree.
you open the source file and find a line that looks like the following

#define MAXNSONS 5
and increase the number.  this sets the maximum number of daughter nodes for each node on the tree.
however some programs such as mcmctree requires a fully resolved tree, and won't take a multifurcating tree at all, in which case making that change won't cure the problem.  it sounds like yours is not such a case.
ziheng
####

就是提供的树文件里面某个枝的子节点超出数量了
去src文件夹修改源码后运行下面编译命令
cc -fast -o codeml codeml.c tools.c -lm
"""

"""
疑问
- 参考的那篇文章是用氨基酸去做树，同义突变的差异就会被掩盖，得不出核酸水平的进化关系，个人认为还是要用核酸树
"""

