"""
name: run anvi pangenomics
date: 20234-03-22
description: Snakemake pipeline to run anvi pangenomics https://merenlab.org/2016/11/08/pangenomics-v2/
author: Jianmin Xie
dependencies:
    - anvio,
rules:
    -
"""
import os
from os import path
import pandas as pd
shell.executable('/bin/zsh') # set a shell to run commands

configfile: "configs/genome_abundance_config.yaml"

env_name = config["env_name"]

genome_dir = config["genome_dir"]

is_subsample = config.get("is_subsample",False)

# tara_reads = "/userdata1/xjm/Tara_ocean/PRJEB1787/reads"
tara_reads = config["fastp_config"]["reads_dir"]
bowtie2_index = "bowtie2_index"
subsample_reads_output = "subsample_reads_output"
bowtie2_output = "bowtie2_output"
summary_output = "summary_output"

blast_db_output = "blast_db"


genome_name = ""

# 先只考虑双端数据
SAMPLES =  [i for i in os.listdir(tara_reads) if len([j for j in os.listdir(path.join(tara_reads,i)) if j.endswith(".gz")]) > 1]
genomes = [".".join(i.split(".")[:-1]) for i in os.listdir(genome_dir) if not i.startswith(".")]
module fastp_module:
    # here, plain paths, URLs and the special markers for code hosting providers (see below) are possible.
    snakefile: "modules/fastp_module_temp.smk"
    config: config["fastp_config"]


use rule * from fastp_module as my_*

rule all:
    input:
        expand(bowtie2_output + "/{genome}/{sample}/{sample}.mapped.sort.bam", genome=genomes, sample=SAMPLES),
        expand(summary_output + "/{genome}_mapped_reads_count.tsv",genome=genomes),
        expand(bowtie2_index + "/{genome}/{genome}.1.bt2", genome=genomes),
        expand(bowtie2_output + "/{genome}/{sample}/{sample}_{type}.tsv", genome=genomes, sample=SAMPLES, type=["idxstats", "coverage"])
    default_target: True





# 参考文档：https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml
rule build_bowtie2_index:
    input:
        genome_dir + "/{genome}.fasta"
    output:
        bowtie2_index + "/{genome}/{genome}.1.bt2"
    params:
        index_prifix=bowtie2_index + "/{genome}/{genome}"
    threads: 32
    log:
        "logs/build_bowtie2_index/{genome}.log"
    conda:
        env_name
    shell:
        "bowtie2-build --threads {threads} {input} {params.index_prifix} &> {log}"

rule subsample_reads:
    input:
        r1 = rules.my_fastp.output.r1,
        r2 = rules.my_fastp.output.r2,
    output:
        r1 = subsample_reads_output + "/{sample}_subsample_1.fq.gz",
        r2 = subsample_reads_output + "/{sample}_subsample_2.fq.gz"
    params:
        subsample_count = 40000000
    conda:
        env_name
    shell:
        "seqtk sample -s100 {input.r1} {params.subsample_count} | gzip > {output.r1};" # Note: Ensure both calls use the same seed for sampling (-s option) to maintain pair consistency.
        "seqtk sample -s100 {input.r2} {params.subsample_count} | gzip > {output.r2}" # Note: Ensure both calls use the same seed for sampling (-s option) to maintain pair consistency.

# 参考文档：https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml
rule bowtie2:
    input:
        r1=lambda w: rules.subsample_reads.output.r1 if is_subsample else rules.my_fastp.output.r1,
        r2=lambda w: rules.subsample_reads.output.r2 if is_subsample else rules.my_fastp.output.r2,
        bowtie2_index = rules.build_bowtie2_index.output
    output:
        temp(bowtie2_output + "/{genome}/{sample}/{sample}.sam")
    params:
        index_prifix=bowtie2_index + "/{genome}/{genome}"
    log:
        "logs/bowtie2/{genome}/{sample}_bowtie2.log"
    conda:
        env_name
    threads: 64
    shell:
        "bowtie2 -x {params.index_prifix} -1 {input.r1} -2 {input.r2} -S {output} -p {threads} &> {log}"





# 排序与压缩
rule samtools_sort:
    input:
        rules.bowtie2.output
    output:
        bam = temp(bowtie2_output + "/{genome}/{sample}/{sample}.sort.bam"),
        bai = temp(bowtie2_output + "/{genome}/{sample}/{sample}.sort.bam.bai"),

    threads: 24
    conda:
        env_name
    log:
        "logs/samtools_sort/{genome}/{sample}_samtools.log"
    shell:
        "samtools sort -O BAM -o {output.bam} -@ {threads} {input} &> {log};"
        "samtools index -@ {threads} {output.bam};"



rule mapping_summary:
    input:
        bam = rules.samtools_sort.output.bam,
        bai = rules.samtools_sort.output.bai,
    output:
        idxstats = bowtie2_output + "/{genome}/{sample}/{sample}_idxstats.tsv",
        flagstat = bowtie2_output + "/{genome}/{sample}/{sample}_flagstat.txt",
        coverage = bowtie2_output + "/{genome}/{sample}/{sample}_coverage.tsv",
        coverage_histogram = bowtie2_output + "/{genome}/{sample}/{sample}_coverage_histogram.tsv",
        depth_histogram = bowtie2_output + "/{genome}/{sample}/{sample}_depth_histogram.tsv",
    conda:
        env_name
    shell:
        "samtools idxstats {input.bam} > {output.idxstats};"
        "samtools flagstat {input.bam} > {output.flagstat};"
        "samtools coverage {input.bam} > {output.coverage};"
        "samtools coverage -A {input.bam} > {output.coverage_histogram};"
        "samtools coverage -A --plot-depth {input.bam} > {output.depth_histogram};"



# 过滤掉没有比对上的
rule samtools_filter:
    input:
        rules.samtools_sort.output.bam
    output:
        bowtie2_output + "/{genome}/{sample}/{sample}.mapped.sort.bam"

    threads: 24
    conda:
        env_name
    log:
        "logs/samtools_filter/{genome}/{sample}_samtools.log"
    shell:
        "samtools view -F 4 -@ {threads} -bS -o {output} {input} &> {log};" # -F 4 滤掉没有mapping上records
        "samtools index -@ {threads} {output};"



# rule summary:
#     input:
#         lambda w:expand(bowtie2_output + f"/{w.genome}/{{sample}}/{{sample}}_flagstat.txt", sample=SAMPLES)
#
#     output:
#         summary_output + "/{genome}_mapped_reads_count.tsv"
#     shell:
#         """echo "Sample\tTotal_reads\tMapped_reads\tCoverage\tMeandepth" > {output}
# for i ({input}) {{
# sample_name=$(echo $i | cut -d'/' -f3)
# genome_name=$(echo $i | cut -d'/' -f2)
# aa=(${{(f)"$(cut -d " " -f1 $i)"}})
# coverage=$(awk 'NR==2 {{print $6}}' {bowtie2_output}/$genome_name/$sample_name/${{sample_name}}_coverage.tsv)
# meandepth=$(awk 'NR==2 {{print $7}}' {bowtie2_output}/$genome_name/$sample_name/${{sample_name}}_coverage.tsv)
# echo "$sample_name\t$aa[1]\t$aa[7]\t$coverage\t$meandepth" >> {output}
# }}
# """
#


rule summary:
    input:
        flagstat_list = lambda w:expand(bowtie2_output + f"/{w.genome}/{{sample}}/{{sample}}_flagstat.txt", sample=SAMPLES),
        coverage_list = lambda w:expand(bowtie2_output + f"/{w.genome}/{{sample}}/{{sample}}_coverage.tsv", sample=SAMPLES),

    output:
        summary_output + "/{genome}_mapped_reads_count.tsv"
    conda:
        env_name
    script:
        "scripts/python/summary_bowtie2_output.py"



