"""
name: run pgap
date: 2025-04-08
description: Snakemake pipeline to run pgap
author: Jianmin Xie
dependencies:
    - pgap = ,
rules:
    - make_db
"""
import os
from Bio import SeqIO
from os import path
import pandas as pd


configfile: "pgap_cconfigs.yaml"

shell.executable('/bin/zsh') # set a shell to run commands


genome_dir = config["genome_dir"]
genome_suffix = config.get("suffix","fasta")
pgap_output = "pgap_output"
SAMPLES = [".".join(i.split(".")[:-1]) for i in os.listdir(genome_dir) if not i.startswith(".")]
# 检查有没有配置pgap数据库路径的环境变量
envvars:
    "PGAP_INPUT_DIR"



rule all:
    input:
        expand(pgap_output + "/{sample}/result/annot.faa", sample=SAMPLES)



rule pgap_yaml:
    input:
        genome=genome_dir + "/{sample}." + genome_suffix,
    output:
        generic=pgap_output + "/{sample}/generic.yaml",
        metadata=pgap_output + "/{sample}/metadata.yaml",
        genome=temp(pgap_output + "/{sample}/{sample}.fasta"),
    params:
        # 物种名是必须的 而且如果不正确会报错：在他的这个input_asn_type.txt 里面找不到
        genus_species=lambda wildcards: config["organism"][wildcards.sample],
    run:
        # docker容器里只支持相对路径，要把基因组的contig id 修改加上pgap所需信息[topology=linear] [location=chromosome] 并复制到目标目录
        records = SeqIO.parse(open(input.genome,"r"),"fasta")
        records_list = []
        for record in records:
            record.description = "[topology=linear] [location=chromosome]"
            records_list.append(record)
        with open(output.genome, "w") as out:
            SeqIO.write(records_list, out, "fasta")
        # shell(f"cp {input.genome} {output.genome}")
        generic_yaml = f"""fasta:
    class: File
    location: {wildcards.sample}.fasta
submol:
    class: File
    location: metadata.yaml"""

        metadata_yaml = f"""organism:
    genus_species: {params["genus_species"]}
    strain: {wildcards.sample}
locus_tag_prefix: {wildcards.sample}
authors:
    - author:
        first_name: 'Jianmin'
        last_name: 'Xie'
contact_info:
    first_name: 'Jianmin'
    last_name: 'Xie'
    email: '19jmxie@stu.edu.cn'
    organization: 'Shantou University'
    department: 'College of Science'
    street: '243 Daxue Road'
    city: 'Shantou'
    state: 'Guangdong'
    postal_code: '515063'
    country: 'China'"""
        with open(output["generic"],"w") as f:
            f.write(generic_yaml)
        with open(output["metadata"],"w") as f:
            f.write(metadata_yaml)





rule pgap:
    input:
        generic = rules.pgap_yaml.output.generic,
        genome = rules.pgap_yaml.output.genome,
    output:
        gff = pgap_output + "/{sample}/result/annot.gff",
        gbk = pgap_output + "/{sample}/result/annot.gbk",
        faa = pgap_output + "/{sample}/result/annot.faa", # 不用那个annot_translated_cds.faa 是因为bakta不支持还有内部终止子的序列，这些假基因基本都是移动原件蛋白，无所谓
        translated_faa = pgap_output + "/{sample}/result/annot_translated_cds.faa"
    params:
        threads=128,
        out_dir = pgap_output + "/{sample}/result"
    benchmark:
        "benchmarks/pgap/{sample}_benchmark.tsv"
    threads: workflow.cores / 4
    log:
        "logs/pgap/{sample}_pgap.log"
    shell:
        "rm -rf {params.out_dir};" # snakemake会自动创建这个文件夹，pgap又不允许存在这个文件夹
        "pgap.py --no-internet --ignore-all-errors -c {params.threads} -n -o {params.out_dir} {input.generic} &> {log}"



