"""
name: The pipeline to build MSA genome tree
date: 2023-04-24
description: Snakemake pipeline to do Third generation sequence assembly
author: Jianmin Xie
dependencies:
    - prodigal = 2.6.3
    - biopython = 1.81
    - orthofinder = 2.5.5
    - mafft = 7.520
    - seqtk = 1.4
    - iqtree = 2.2.3

rules:
    - prodigal



"""

import os
# configfile: "configs/MSA_genome_tree_from_single_copy_aas_config.yaml"

aas_dir = config["aas_dir"]
env_name = config["env_name"]
SAMPLES = [".".join(i.split(".")[:-1]) for i in os.listdir(aas_dir)]



scos_dir = "unique_single_copy_aas"
mafft_dir = "mafft_output"
iqtree_dir = "iqtree_output"

shell.executable('/bin/zsh') # set a shell to run commands

def get_GC_names(wildcards):
    # note 1: ck_output is the same as OUTDIR, but this requires
    # the checkpoint to complete before we can figure out what it is!

    # note 2: checkpoints will have attributes for each of the checkpoint
    # rules, accessible by name. Here we use make_some_files
    filter_output = checkpoints.filterSingleCopyGene.get(**wildcards).output[0]
    GCs, = glob_wildcards(os.path.join(filter_output, "{GC}.faa"))
    return expand(os.path.join(mafft_dir, "{GC}.faa"), GC=GCs)


rule all:
    input:
        scos_dir,
        iqtree_dir + "/MSA_genome_tree.treefile"
    default_target: True



# 去重
checkpoint filterSingleCopyGene:
    output:
        directory(scos_dir)
    params:
        single_copy_gene_dir = aas_dir
    log:
        "logs/filterSingleCopyGene.log"
    conda:
        env_name
    script:
        "scripts/python/filterSingleCopyGene.py"




rule mafft:
    input:
        scos_dir + "/{GC}.faa"
    output:
        mafft_dir + "/{GC}.faa"
    log:
        "logs/mafft/{GC}.log"
    conda:
        env_name
    shell:
        "(mafft --auto {input} > {output}) &> {log}"





rule concatenate_seq:
    input:
        get_GC_names
    output:
        iqtree_dir + "/concatenated_seq.fasta"
    conda:
        env_name
    script:
        "scripts/python/concatenate_seq.py"




rule iqtree:
    input:
        rules.concatenate_seq.output
    output:
        iqtree_dir + "/MSA_genome_tree.treefile"
    params:
        outgroup = config["outgroup"] if "outgroup" in config else "\"\"",
        output_prefix = iqtree_dir + "/MSA_genome_tree"
    log:
        "logs/iqtree.log"
    conda:
        env_name
    threads: workflow.cores
    shell:
        """if [[ {params.outgroup} == "" ]] {{
    iqtree2 -s {input} -m MFP  -B 1000  -redo --prefix {params.output_prefix}  -nt {threads} &> {log}
}} else {{
    iqtree2 -s {input} -m MFP  -B 1000  -redo --prefix {params.output_prefix}  -nt {threads} -o {params.outgroup} &> {log}
}}"""













