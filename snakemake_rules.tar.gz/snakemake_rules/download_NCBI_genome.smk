"""
name: download NCBI genome
date: 2023-01-05
description: Snakemake pipeline to download NCBI genome
author: Jianmin Xie
dependencies:
    - datasets = 14.6.4,
rules:
    - download


"""

SAMPLE = ["Phaeobacter", "Neptuniibacter", "Shimia"]
DOWNLOAD_OUT_PATH = "/home/cyr/Documents/xjm/finall_strain/recombination_fragment_source_db"

shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand(DOWNLOAD_OUT_PATH + "/{sample}_NCBI.zip", sample=SAMPLE),
        expand(DOWNLOAD_OUT_PATH + "/{sample}_NCBI", sample=SAMPLE),

rule download:
    params:
        taxon="{sample}"
    output:
        DOWNLOAD_OUT_PATH + "/{sample}_NCBI.zip"
    shell:
        "datasets download genome taxon {params.taxon} --assembly-source GenBank --filename {output}"

rule unzip:
    input:
        rules.download.output
    output:
        directory(DOWNLOAD_OUT_PATH + "/{sample}_NCBI")
    shell:
        "unzip -d {output} {input};"
        "mkdir {output}/genome;"
        "mv {output}/ncbi_dataset/data/*/*.fna {output}/genome;"
        "rm {input}"
