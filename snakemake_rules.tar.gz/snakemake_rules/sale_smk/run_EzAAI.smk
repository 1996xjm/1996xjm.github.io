"""
name: run EzAAI
date: 2023-02-27
description: Snakemake pipeline to run EzAAI
author: Jianmin Xie
dependencies:
    - ezaai = 1.2.2,
rules:
    - make_db
"""
import os
import pandas as pd

seq_dir = config["seq"]
output_DB_dir = "DBs"
output_file = "AAI.tsv"
output_matrix_file = "AAI_matrix.tsv"


SAMPLE = os.listdir(seq_dir)

onsuccess:
    df = pd.read_table(output_file)
    matrix = df["AAI"].groupby(by=[df["Label 1"], df["Label 2"]]).sum().unstack()
    matrix.to_csv(output_matrix_file,sep="\t")
rule all:
    input:
        output_file


rule make_db:
    params:
        label="{sample}",
        seq_type=config["type"]
    input:
        seq_dir + "/{sample}"
    output:
        output_DB_dir + "/{sample}.msd"
    log:
        "logs/make_db/{sample}.log"
    shell:
        """if [ {params.seq_type} == "faa" ]; then
    EzAAI convert -i {input} -s prot -o {output} -l {params.label} &> {log}
else
    EzAAI extract -i {input} -o {output} -l {params.label} &> {log}
fi"""


rule EzAAI:
    input:
        expand(output_DB_dir + "/{sample}.msd",sample=SAMPLE)
    output:
        output_file
    params:
        db_dir = output_DB_dir
    log:
        "logs/EzAAI.log"
    threads: workflow.cores # 使用全部线程
    shell:
        "EzAAI calculate -i {params.db_dir} -j {params.db_dir} -o {output} -t {threads} &> {log}"