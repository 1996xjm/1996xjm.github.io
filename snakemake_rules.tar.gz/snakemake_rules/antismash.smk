from os import listdir
fasta_path = config["genome"]
suffix = config.get("suffix","fasta")
antismash_output_path = "antismash_output"
statistics_output_path = "statistics_output"

SAMPLES = [".".join(i.split(".")[:-1]) for i in listdir(fasta_path)]



rule all:
    input:
        # expand(antismash_output_path + "/{sample}/regions.js", sample=SAMPLES),
        expand(statistics_output_path + "/{type}.tsv", type=["orfs_count", "products_count"]),
        expand(f"{statistics_output_path}/index_page_table/{{sample}}", sample=SAMPLES)


rule antismash:
    input:
        fasta_path + "/{sample}." + suffix
        # "/home/xjm/final_representative_strain/Pha/ONT_sequencing/pgap_output/{sample}/result/annot.gbk"
    output:
        regions_js = ensure(antismash_output_path + "/{sample}/regions.js", non_empty=True),
        index_html = ensure(antismash_output_path + "/{sample}/index.html", non_empty=True),
    benchmark:
        "benchmarks/antismash/{sample}_benchmark.txt"
    threads: 8
    log:
        "logs/antismash/{sample}.log"
    params:
        output_dir = antismash_output_path + "/{sample}",
        basename = "{sample}",
        genefinding_tool = "--genefinding-tool prodigal " if suffix != "gbk" else ""
    conda:
        "antismash-7.0.1"
    shell:
        "antismash -v -c 32 --clusterhmmer --cb-knownclusters --cb-subclusters --asf --pfam2go --rre --tfbs {params.genefinding_tool}"
        "--output-dir {params.output_dir} --output-basename {params.basename} {input} &> {log}"

rule product_gene_count:
    input:
        expand(antismash_output_path + "/{sample}/regions.js",sample=SAMPLES)
    output:
        orfs_count = statistics_output_path + "/orfs_count.tsv",
        products_count = statistics_output_path + "/products_count.tsv"
    log:
        "logs/product_gene_count/product_gene_count.log"
    conda:
        "antismash-7.0.1"
    script:
        "scripts/python/antismash_gene_count.py"



rule index_page_table:
    input:
        rules.antismash.output.index_html
    output:
        directory(f"{statistics_output_path}/index_page_table/{{sample}}")
    log:
        "logs/index_page_table/{sample}.log"
    conda:
        "antismash-7.0.1"
    script:
        "scripts/python/antismash_index_page_table.py"
