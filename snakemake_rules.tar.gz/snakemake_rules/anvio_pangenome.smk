"""
name: run anvi pangenomics
date: 20234-03-22
description: Snakemake pipeline to run anvi pangenomics https://merenlab.org/2016/11/08/pangenomics-v2/
author: Jianmin Xie
dependencies:
    - anvio,
rules:
    -
"""
import os
from os import path
import pandas as pd
shell.executable('/bin/zsh') # set a shell to run commands

configfile: "configs/anvio_pangenome_config.yaml"

genomes_dir = config["genomes_dir"]
env_name = config["env_name"]
pgap_output = config["pgap_output"]

rename_genomes_output = "renamed_genomes"
external_gene_calls_output = "external_gene_calls"
contigs_db_output = "contigs_db"
pan_genome_output = "pan_genome_output"



SAMPLES =  [".".join(i.split(".")[:-1]) for i in os.listdir(genomes_dir)]


rule all:
    input:
        pan_genome_output


# anvi'o的要求的序列id不能带后面的描述
rule rename_genomes:
    input:
        genomes_dir + "/{sample}.fasta"
    output:
        rename_genomes_output + "/{sample}.fasta"
    shell:
        "sed 's/ .*//g' {input} > {output}"


rule pgapRes_to_external_gene_calls:
    input:
        gff = pgap_output + "/{sample}/result/annot.gff",
        faa = pgap_output + "/{sample}/result/annot_translated_cds.faa",
        genome = rename_genomes_output + "/{sample}.fasta",

    output:
        external_gene_calls_output + "/{sample}_external_gene_calls.tsv"
    conda:
        env_name
    script:
        "scripts/python/pgapRes_to_anvio_external_gene_calls.py"

# 查看db信息 anvi-db-info contigs_db/PT24_64.db
rule make_contigs_db:
    input:
        genome = rules.rename_genomes.output,
        external_gene_calls = rules.pgapRes_to_external_gene_calls.output,

    output:
        contigs_db_output + "/{sample}.db"
    log:
        "logs/make_contigs_db/{sample}_contigs_db.log"
    params:
        project_name = "Pha"
    threads: 12
    conda:
        env_name
    shell:
        "anvi-gen-contigs-database -f {input.genome} --external-gene-calls {input.external_gene_calls} --ignore-internal-stop-codons --skip-predict-frame --project-name {params.project_name} -T {threads} -o {output} &> {log}"

rule generate_metadata:
    input:
        expand(contigs_db_output + "/{sample}.db",sample=SAMPLES)
    output:
        "external-genomes.tsv"
    run:
        with open(output[0], "w") as f:
            print("name\tcontigs_db_path", file=f)
            for db in input:
                sample = ".".join(path.basename(db).split(".")[:-1])
                print(f"{sample}\t{db}", file=f)


rule genomes_storage:
    input:
        rules.generate_metadata.output
    output:
        "Pha-GENOMES.db" # The genomes storage file must end with '-GENOMES.db'.
    conda:
        env_name
    log:
        "logs/genomes_storage.log"
    shell:
        "anvi-gen-genomes-storage -e {input} -o {output} --gene-caller pgap &> {log}"



rule pan_genome:
    input:
        rules.genomes_storage.output
    output:
        directory(pan_genome_output)
    conda:
        env_name
    params:
        project_name="Pha_Pan"
    log:
        "logs/pan_genome.log"
    threads: 32
    shell:
        "anvi-pan-genome -g {input} "
        "--project-name {params.project_name} "
        "--output-dir {output} "
        "--num-threads {threads} "
        "--minbit 0.5 " # 跟微生物共现网络类似，用邻接矩阵去创建一个graph，过滤掉网络里面不合格（两条序列相似度没有达到这个阈值）的边
        "--mcl-inflation 10 " # MCL - a cluster algorithm for graphs， 膨胀系数 非常相近的基因组建议用10
        "--use-ncbi-blast &> {log}"

"""
Use the MCL algorithm (van Dongen and Abreu-Goodger, 2012) to identify clusters in amino acid sequence 
similarity search results. We use 2 as the MCL inflation parameter by default. This parameter defines 
the sensitivity of the algorithm during the identification of the gene clusters. More sensitivity means 
more clusters, but of course more clusters does not mean better inference of evolutionary relationships. 
More information on this parameter and it’s effect on cluster granularity is here http://micans.org/mcl/man/mclfaq.html#faq7.2, 
but clearly, we, the metagenomics people will need to talk much more about this. 
So far in the Meren Lab we have been using 2 if we are comparing many distantly related genomes (i.e., genomes classify into different families or farther), 
and 10 if we are comparing very closely related genomes (i.e., ‘strains’ of the same ‘species’ (based whatever definition of these terms you fancy)). 
You can change it using the parameter --mcl-inflation. Please experiment yourself, and consider reporting!
"""


