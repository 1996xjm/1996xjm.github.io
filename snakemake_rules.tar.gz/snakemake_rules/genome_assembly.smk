"""
name: quality control
date: 2022-11-27
description: Snakemake pipeline to do quality control, assembly, summary assembly quality
author: Jianmin Xie
dependencies:
    - fastp = 0.23.2
    - spades = 3.15.3
    - quast = 5.2.0
    - checkm = 1.2.0
rules:
    - fastp
    - spades
    - filterLengthAndCoverage
    - quast

"""

import os
from os import path
reads_dir = "/home/cyr/Documents/xjm/finall_strain/recombination_fragment_source_metagenome/reads"
SAMPLE = os.listdir(reads_dir)
# SAMPLE = ["PT30_61",  "PT63_30"]
FASTP_OUT_PATH = "fastp_output3"
SPADES_OUT_PATH = "spades_output3"
QUAST_OUT_PATH = "quast_output3"
CHECKM_OUT_PATH = "checkM_output3"
FILTERED_GENOME_OUT_PATH = "genome_upper_L1000C5"

shell.executable('/bin/zsh') # set a shell to run commands




onsuccess:
    #  merge fastp results of all samples
    shell(f"python  ~/Documents/BioInformatic/genome_assembly/mergeFastpSummary.py -f {FASTP_OUT_PATH} -o ./summary_table")
    #  merge quast results of all samples
    shell(f"python  ~/Documents/BioInformatic/genome_assembly/mergeQuastSummary.py -f {QUAST_OUT_PATH} -o ./summary_table")
    shell(f"mkdir -p {CHECKM_OUT_PATH};checkm lineage_wf -f {path.join(CHECKM_OUT_PATH,'checkm_result.tsv')} --tab_table -x fasta -t 32 --pplacer_threads 32 {FILTERED_GENOME_OUT_PATH} {path.join(CHECKM_OUT_PATH,'checkm_tem')}")

rule all:
    input:
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_paired_1.fq.gz", sample=SAMPLE),
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_paired_2.fq.gz", sample=SAMPLE),
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.json", sample=SAMPLE),
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.html", sample=SAMPLE),
        # expand(SPADES_OUT_PATH + "/{sample}", sample=SAMPLE),
        # expand(genome_dir + "/{sample}.fasta", sample=SAMPLE),
        # expand(QUAST_OUT_PATH + "/{sample}", sample=SAMPLE),

rule fastp:
    input:
        r1 = reads_dir + "/{sample}/{sample}_1.fq.gz",
        r2 = reads_dir + "/{sample}/{sample}_2.fq.gz",
    output:
        r1 = FASTP_OUT_PATH + "/{sample}/{sample}_paired_1.fq.gz",
        r2 = FASTP_OUT_PATH + "/{sample}/{sample}_paired_2.fq.gz",
        json = ensure(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.json", non_empty=True), # If the command somecommand happens to generate an empty output, the job will fail with an error listing the unexpected empty file.
        html = ensure(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.html", non_empty=True), # Often, it is a good idea to combine ensure annotations with retry definitions, e.g. for retrying upon invalid checksums or empty files.
    log:
        FASTP_OUT_PATH + "/{sample}/{sample}_fastp.log"
    threads: 8
    shell:
        "fastp -i {input.r1} -I {input.r2} -o {output.r1} -O {output.r2} "
        "-j {output.json} -h {output.html} -w {threads} "
        "-q 20 " # the quality value that a base is qualified
        "-u 10 " # how many percents of bases are allowed to be unqualified (0~100).
        "-n 3 " # number of N allowed
        "-l 50 " # reads shorter than length_required will be discarded, particularly those with adapter.
        "-5 " # enable trimming in 5' ends.
        "-3 " # enable trimming in 3' ends.
        "&> {log}"

rule spades:
    input:
        r1 = rules.fastp.output.r1,
        r2 = rules.fastp.output.r2,
    output:
        directory(SPADES_OUT_PATH + "/{sample}")
    threads: 16
    shell:
        "spades.py --isolate -1 {input.r1} -2 {input.r2} -t {threads} -m 48 -o {output} &> /dev/null"

rule filterLengthAndCoverage:
    input:
        SPADES_OUT_PATH + "/{sample}/contigs.fasta"
    output:
        FILTERED_GENOME_OUT_PATH + "/{sample}.fasta"
    shell:
        "python /home/cyr/Documents/BioInformatic/genome_assembly/filterLengthAndCoverage.py -f {input} -o {output}"

rule quast:
    input:
        rules.filterLengthAndCoverage.output
    output:
        directory(QUAST_OUT_PATH + "/{sample}")
    shell:
        "quast.py {input} -o {output} &> /dev/null"







