"""
name: Third generation sequence assembly
date: 2023-04-24
description: Snakemake pipeline to do Third generation sequence assembly
author: Jianmin Xie
dependencies:
    - fastp = 0.23.2
    - flye = 2.9.2
    - minimap2 = 2.24
    - samtools = 1.17
    - pilon = 1.24
    - seqtk # convert phred64 to 33
    - pyyaml
    - pgap
    - prodigal
    - biopython
    - pandas

rules:
    - fastp
    - flye
    - minimap2
    - pilon


"""

import os
from os import path
configfile: "configs/TG_assembly_config.yaml"

pilon_jar = config["pilon_jar"]
SG_reads_dir = config["SG_reads_dir"]
TG_reads_dir = config["TG_reads_dir"]
polish_times = config["polish_times"] # polishing recurse time
env_name = config["env_name"]
bakta_db = config["bakta_db"]
SAMPLES = os.listdir(TG_reads_dir)

FASTP_OUT_PATH = "fastp_output"
flye_OUT_PATH = "flye_output"
minimap2_OUT_PATH = "minimap2_output"
pilon_OUT_PATH = "pilon_output"
final_genome_PATH = "TG_genome"
final_plasmid_PATH = "plasmid"
final_chromosome_PATH = "chromosome"
final_plasmid_faa_PATH = "plasmid_faa"
unfixed_genome_PATH = "TG_unfixed_genome"
prodigal_OUT_PATH = "prodigal_output"
bakta_replicons_table_dir = "bakta_replicons_table"
checkM_output = "checkM_output"
busco_output = "busco_output"
bakta_output = "bakta_output"
pgap_output = "pgap_output"
bakta_proteins_output = "bakta_proteins_output"


shell.executable('/bin/zsh') # set a shell to run commands

module fastp_module:
    # here, plain paths, URLs and the special markers for code hosting providers (see below) are possible.
    snakefile: "modules/fastp_module.smk"
    config: config["fastp_config"]

quality_assessment_config = {
    "genome_dir": final_genome_PATH,
    "env_name": config["quality_assessment_env_name"],
    "samples": SAMPLES,
    "busco_database": config["busco_database"],
    "checkM_output": checkM_output,
    "busco_output": busco_output,

}

module quality_assessment_m:
    snakefile: "modules/quality_assessment_module.smk"
    config: quality_assessment_config

genome_annotation_config = {
        "bakta_db":bakta_db,
        "genome_dir":final_genome_PATH,
        "bakta_replicons_table_dir":bakta_replicons_table_dir,
        "organism":config["organism"],
        "env_name":env_name,
        "samples": SAMPLES,
        "bakta_output": bakta_output,
        "pgap_output": pgap_output,
        "bakta_proteins_output": bakta_proteins_output,
    }
module genome_annotation_m:
    snakefile: "modules/genome_annotation.smk"
    config: genome_annotation_config

# 使用fastp模块
use rule * from fastp_module as my_*
use rule * from quality_assessment_m as qa_*
use rule * from genome_annotation_m as ga_*

rule all:
    input:
        busco_output + "/batch_summary.tsv",
        checkM_output + "/checkm_result.tsv",
        # expand(bakta_output + "/{sample}/{sample}.tsv",sample=SAMPLES),
        # expand(pgap_output + "/{sample}/result/annot.tsv",sample=SAMPLES),
        # expand(final_genome_PATH + "/{sample}.fasta",sample=SAMPLES),
        expand(bakta_proteins_output + "/{sample}/{sample}.tsv",sample=SAMPLES),
        expand(pgap_output + "/{sample}/result/annot.gff",sample=SAMPLES),
        final_plasmid_PATH,
        final_plasmid_faa_PATH,
        final_chromosome_PATH
    default_target: True








# mapping
rule flye:
    input:
        TG_reads_dir + "/{sample}/{sample}.pass.fastq.gz"
    output:
        ensure(flye_OUT_PATH + "/{sample}/assembly.fasta", non_empty=True)
    params:
        genomeSize = lambda wildcards: config["genome_size"][wildcards.sample], #不同样本可能具体匹配, flye可以不指定这个 对于Phaeobacter gallaeciensis 4.5m的组装效果比4.7m好
        outdir = flye_OUT_PATH + "/{sample}",
        asm_coverage = 300 #限制测序深度，测序深度过高会组装失败！Using longest 300x reads for contig assembly
    threads: workflow.cores * (0.3 if len(SAMPLES) > 1 else 1)
    log:
        "logs/flye/{sample}_flye.log"
    benchmark:
        "benchmarks/flye/{sample}_benchmark.tsv"
    conda:
        env_name
    shell:
        "flye --nano-raw {input} -g {params.genomeSize} --asm-coverage {params.asm_coverage} --out-dir {params.outdir} --threads {threads} &> {log}"



# 基于三代数据的自我校正 racon，大部分文章没有做这一步

# Correct the assembly


def recurse_genome(wcs):
    n = int(wcs.n)
    if n == 1:
        return flye_OUT_PATH + f"/{wcs.sample}/assembly.fasta"
    elif n > 1:
        return pilon_OUT_PATH + f"/time_{n-1}/{wcs.sample}/{wcs.sample}_pilon_{n-1}.fasta"
    else:
        raise ValueError(f"loop numbers must be 1 or greater: received {wcs.n}")



# polishing 递归
rule minimap2:
    input:
        genome = recurse_genome,
        r1 = rules.my_fastp.output.r1,
        r2 = rules.my_fastp.output.r2,
    output:
        minimap2_OUT_PATH + "/time_{n}/{sample}/{sample}_aln.bam"
    threads: 10
    log:
        "logs/minimap2/time_{n}/{sample}_minimap2.log"
    conda:
        env_name
    shell:
        "(minimap2 -ax sr {input.genome} {input.r1} {input.r2} | samtools sort -@ {threads} -O bam -o {output}) &> {log};"
        "samtools index -@ {threads} {output};"

rule mapping_summary:
    input:
        rules.minimap2.output
    output:
        idxstats = minimap2_OUT_PATH + "/time_{n}/{sample}/{sample}_idxstats.tsv",
        flagstat = minimap2_OUT_PATH + "/time_{n}/{sample}/{sample}_flagstat.txt",
        coverage = minimap2_OUT_PATH + "/time_{n}/{sample}/{sample}_coverage.tsv",
        coverage_histogram = minimap2_OUT_PATH + "/time_{n}/{sample}/{sample}_coverage_histogram.txt",
        depth_histogram = minimap2_OUT_PATH + "/time_{n}/{sample}/{sample}_depth_histogram.txt",
    conda:
        env_name
    shell:
        "samtools idxstats {input} > {output.idxstats};"
        "samtools flagstat {input} > {output.flagstat};"
        "samtools coverage {input} > {output.coverage};"
        "samtools coverage -A {input} > {output.coverage_histogram};"
        "samtools coverage -A --plot-depth {input} > {output.depth_histogram};"

rule pilon:
    input:
        genome = recurse_genome,
        bam = rules.minimap2.output,
        summary = rules.mapping_summary.output,
    output:
        pilon_OUT_PATH + "/time_{n}/{sample}/{sample}_pilon_{n}.fasta"
    params:
        prefix = "{sample}_pilon_{n}",
        outdir= pilon_OUT_PATH + "/time_{n}/{sample}",
        pilonJar = pilon_jar
    log:
        "logs/pilon/time_{n}/{sample}_pilon.log"
    shell:
        "java -Xmx16G -jar {params.pilonJar} --genome {input.genome} --frags {input.bam} --output {params.prefix} --fix all --mindepth 10 --minqual 20 --outdir {params.outdir} --changes --verbose &> {log}"



"""
# 只有大于这个测序深度才会被校正，可以指定具体深度，也可以指定一个比例小数，下面的解释
--mindepth depth
          Variants (snps and indels) will only be called if there is coverage of good pairs
          at this depth or more; if this value is >= 1, it is an absolute depth, if it is a
          fraction < 1, then minimum depth is computed by multiplying this value by the mean
          coverage for the region, with a minumum value of 5 (default 0.1: min depth to call
          is 10% of mean coverage or 5, whichever is greater).
# 测序质量
--minqual
              Minimum base quality to consider for pileups (default 0)
"""







# contig重命名
rule rename:
    input:
        pilon_OUT_PATH + f"/time_{polish_times}/{{sample}}/{{sample}}_pilon_{polish_times}.fasta"
    output:
        fasta=unfixed_genome_PATH + "/{sample}_unfixed.fasta",
        bakta_replicons_table=bakta_replicons_table_dir + "/{sample}_replicons.tsv"
    params:
        sample = "{sample}",
        assembly_info = flye_OUT_PATH + "/{sample}/assembly_info.txt",
        polish_times = polish_times
    log:
        "logs/rename/{sample}_rename.log"
    conda:
        env_name
    script:
        "scripts/python/rename_TG_genome.py"



# 修复成环contig两端可能存在的断裂基因
# Prodigal预测ORF，找到第一个没有ORF重叠的间隔区，把间隔区前面的序列挪到contig的尾部
rule prodigal:
    input:
        rules.rename.output.fasta
    output:
        prodigal_OUT_PATH + "/{sample}_unfixed.gff"
    conda:
        env_name
    log:
        "logs/prodigal/{sample}_prodigal.log"
    shell:
        "prodigal -i {input} -f gff -o {output} &> {log};"
        "sed -i '/^#/d' {output}" # 删除注释行 方便pandas读取



rule fix_genome:
    input:
        genome = rules.rename.output.fasta,
        gff = rules.prodigal.output
    output:
        final_genome_PATH + "/{sample}.fasta"
    log:
        "logs/fix_genome/{sample}_fix_genome.log"
    conda:
        env_name
    script:
        "scripts/python/fix_TG_genome.py"


rule extract_plasmid_chromosome:
    input:
        expand(final_genome_PATH + "/{sample}.fasta", sample=SAMPLES)
    output:
        plasmid_dir = directory(final_plasmid_PATH),
        chromosome_dir = directory(final_chromosome_PATH),
    conda:
        env_name

    script:
        "scripts/python/extract_plasmid_chromosome.py"


rule extract_plasmid_faa:
    input:
        expand(pgap_output + "/{sample}/result/annot_translated_cds.faa",sample=SAMPLES)
    output:
        directory(final_plasmid_faa_PATH)
    conda:
        env_name

    script:
        "scripts/python/extract_plasmid_faa.py"






