"""
name: Third generation sequence assembly
date: 2023-04-24
description: Snakemake pipeline to do Third generation sequence assembly
author: Jianmin Xie
dependencies:
    - fastp = 0.23.2
    - hisat2 = 2.2.1
    - htseq = 2.0.2 速度慢 不支持多线程
    - featureCounts = 2.0.3 速度快 支持多线程

rules:
    - fastp
    - hisat2
    - htseq
    - featureCounts


"""

import os
from os import path
import pandas as pd

base_dir = "/home/xjm/lly/KSY-42-1_nanopore"
pilon_jar = "/home/xjm/software/pilon-1.24.jar"
SG_reads_dir = path.join(base_dir, "SG_reads")
TG_reads_dir = path.join(base_dir, "TG_reads")
SAMPLE = os.listdir(SG_reads_dir)

FASTP_OUT_PATH = "fastp_output"
canu_OUT_PATH = "canu_output"
minimap2_OUT_PATH = "minimap2_output"
pilon_OUT_PATH = "pilon_output"

shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_paired_1.fq.gz", sample=SAMPLE),
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_paired_2.fq.gz", sample=SAMPLE),
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.json", sample=SAMPLE),
        expand(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.html", sample=SAMPLE),
        expand(canu_OUT_PATH + "/{sample}/{sample}.contigs.fasta", sample=SAMPLE),
        expand(minimap2_OUT_PATH + "/{sample}/{sample}_aln.bam", sample=SAMPLE),
        expand(pilon_OUT_PATH + "/{sample}/{sample}_pilon.fasta", sample=SAMPLE),
        expand(minimap2_OUT_PATH + "/{sample}/{sample}_aln_2.bam", sample=SAMPLE),
        expand(pilon_OUT_PATH + "/{sample}/{sample}_pilon_2.fasta",sample=SAMPLE),





rule fastp:
    input:
        r1 = SG_reads_dir + "/{sample}/{sample}_1.fq.gz",
        r2 = SG_reads_dir + "/{sample}/{sample}_2.fq.gz",
    output:
        r1 = FASTP_OUT_PATH + "/{sample}/{sample}_paired_1.fq.gz",
        r2 = FASTP_OUT_PATH + "/{sample}/{sample}_paired_2.fq.gz",
        json = ensure(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.json", non_empty=True), # If the command somecommand happens to generate an empty output, the job will fail with an error listing the unexpected empty file.
        html = ensure(FASTP_OUT_PATH + "/{sample}/{sample}_fastp.html", non_empty=True), # Often, it is a good idea to combine ensure annotations with retry definitions, e.g. for retrying upon invalid checksums or empty files.
    log:
        FASTP_OUT_PATH + "/{sample}/{sample}_fastp.log"
    threads: 10
    shell:
        "fastp -i {input.r1} -I {input.r2} -o {output.r1} -O {output.r2} "
        "-j {output.json} -h {output.html} -w {threads} "
        "-q 20 " # the quality value that a base is qualified
        "-u 10 " # how many percents of bases are allowed to be unqualified (0~100) Default 40 means 40%.
        "-n 3 " # number of N allowed
        "-l 40 " # reads shorter than length_required will be discarded, particularly those with adapter.
        "-5 " # enable trimming in 5' ends.
        "-3 " # enable trimming in 3' ends.
        "&> {log}"


# mapping
rule canu:
    params:
        prefix = "{sample}",
        genomeSize = "3.4m", #不同样本可能具体匹配
        outdir = canu_OUT_PATH + "/{sample}"
    input:
        TG_reads_dir + "/{sample}/{sample}.pass.fastq.gz"
    output:
        canu_OUT_PATH + "/{sample}/{sample}.contigs.fasta",
    threads: 96
    shell:
        "canu -p {params.prefix} -d {params.outdir} genomeSize={params.genomeSize} corThreads={threads} -nanopore-raw {input}"


# 这里可能还要一部去除成环的两端接头冗余

# 基于三代数据的自我校正 racon，大部分文章没有做这一步

# Correct the assembly
# Canu 校正前和校正后 checkM完整度差异非常大
# 校正次数 | Completeness
# 没有校正 | 89.36
# 校正1次 | 99.17
# 校正2次 | 99.17
rule minimap2:
    input:
        genome=rules.canu.output,
        r1 = rules.fastp.output.r1,
        r2 = rules.fastp.output.r2,
    output:
        minimap2_OUT_PATH + "/{sample}/{sample}_aln.bam"
    threads: 10
    shell:
        "minimap2 -ax sr {input.genome} {input.r1} {input.r2} | samtools sort -@ {threads} -O bam -o {output};"
        "samtools index -@ {threads} {output};"

rule pilon:
    input:
        genome = rules.canu.output,
        bam = rules.minimap2.output
    output:
        pilon_OUT_PATH + "/{sample}/{sample}_pilon.fasta"
    params:
        prefix = "{sample}_pilon",
        outdir= pilon_OUT_PATH + "/{sample}",
        pilonJar= pilon_jar
    shell:
        "java -Xmx16G -jar {params.pilonJar} --genome {input.genome} --frags {input.bam} --output {params.prefix} --fix all --mindepth 10 --outdir {params.outdir} --changes --verbose"

# 第二轮校正，这轮基本就剩校正为数不多的snp, 一次跑的例子是11个
rule minimap2_2:
    input:
        genome=rules.pilon.output,
        r1 = rules.fastp.output.r1,
        r2 = rules.fastp.output.r2,
    output:
        minimap2_OUT_PATH + "/{sample}/{sample}_aln_2.bam"
    threads: 10
    shell:
        "minimap2 -ax sr {input.genome} {input.r1} {input.r2} | samtools sort -@ {threads} -O bam -o {output};"
        "samtools index -@ {threads} {output};"

rule pilon_2:
    input:
        genome = rules.pilon.output,
        bam = rules.minimap2_2.output
    output:
        pilon_OUT_PATH + "/{sample}/{sample}_pilon_2.fasta"
    params:
        prefix = "{sample}_pilon_2",
        outdir= pilon_OUT_PATH + "/{sample}",
        pilonJar= pilon_jar
    shell:
        "java -Xmx16G -jar {params.pilonJar} --genome {input.genome} --frags {input.bam} --output {params.prefix} --fix all --mindepth 10 --outdir {params.outdir} --changes --verbose"



# 只有大于这个测序深度才会被校正，可以指定具体深度，也可以指定一个比例小数，下面的解释
# --mindepth depth
#           Variants (snps and indels) will only be called if there is coverage of good pairs
#           at this depth or more; if this value is >= 1, it is an absolute depth, if it is a
#           fraction < 1, then minimum depth is computed by multiplying this value by the mean
#           coverage for the region, with a minumum value of 5 (default 0.1: min depth to call
#           is 10% of mean coverage or 5, whichever is greater).

