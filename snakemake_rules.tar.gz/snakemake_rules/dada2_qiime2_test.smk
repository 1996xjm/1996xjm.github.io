"""
name: dada2 qiime2 test
date: 2023-12-27
description: Snakemake pipeline to test params of dada2 and qiime2
author: Jianmin Xie
dependencies:
    - bioconductor-shortread = 1.60.0 # r-base is in this package
    - cutadapt = 4.6
    - flash = 1.2.11
    - qiime2 = 2023.9.0
    - biopython
    - pandas

rules:
    - fastp
    - flye
    - minimap2
    - pilon


"""

import os
from os import path
configfile: "configs/dada2_qiime2_test_config.yaml"

samples_dir = config["samples_dir"]
env_name = config["env_name"]
SAMPLES = os.listdir(samples_dir)

f_primer = config["f_primer"]
r_primer = config["r_primer"]

custom_pipeline_output = "custom_pipeline_output"
qiime2_output = "qiime2_output"
renamed_reads = "renamed_reads"
cutadapt_output = "cutadapt_output"

flash_output = path.join(custom_pipeline_output, "flash_output")

dada2_paired_truncLen220_output = path.join(custom_pipeline_output, "dada2_paired_truncLen220_output")
dada2_paired_truncLen230_output = path.join(custom_pipeline_output, "dada2_paired_truncLen230_output")
dada2_paired_truncLen240_output = path.join(custom_pipeline_output, "dada2_paired_truncLen240_output")
dada2_paired_truncLen250_output = path.join(custom_pipeline_output, "dada2_paired_truncLen250_output")
dada2_paired_truncLen260_output = path.join(custom_pipeline_output, "dada2_paired_truncLen260_output")
dada2_paired_truncLen270_output = path.join(custom_pipeline_output, "dada2_paired_truncLen270_output")


dada2_single_output = path.join(custom_pipeline_output, "dada2_single_output")
dada2_single_filter_output = path.join(custom_pipeline_output, "dada2_single_filter_output")
summary_output = path.join(custom_pipeline_output, "summary_output")


shell.executable('/bin/zsh') # set a shell to run commands


rule all:
    input:
        expand(custom_pipeline_output + "/dada2_paired_truncLen{len}_output/{sample}/{sample}_rep_seqs_nochim.fasta", len=[220,230,240,250,260,270], sample=SAMPLES),
        expand(dada2_single_output + "/{sample}/{sample}_rep_seqs_nochim.fasta", sample=SAMPLES),
        expand(dada2_single_filter_output + "/{sample}/{sample}_rep_seqs_nochim.fasta", sample=SAMPLES),
        expand(summary_output + "/{type}_length_frequency_distribution.tsv", type=["R1", "R2"]),
        expand(summary_output + "/{type}.tsv", type=["single_reads", "single_filter_reads"]),
        expand(summary_output + "/paired_reads_truncLen{len}.tsv", len=[220,230,240,250,260,270]),
    default_target: True

# cutadapt read id 不一致会报错，去掉注释部分
rule rename_reads_id:
    input:
        r1 = samples_dir + "/{sample}/{sample}_1.fq.gz",
        r2 = samples_dir + "/{sample}/{sample}_2.fq.gz"
    output:
        r1=temp(renamed_reads + "/{sample}/{sample}_1.fq"),
        r2=temp(renamed_reads + "/{sample}/{sample}_2.fq")
    shell:
        "zcat {input.r1}|sed 's/#.*\/1$/\/1/g' > {output.r1};"
        "zcat {input.r2}|sed 's/#.*\/2$/\/2/g' > {output.r2}"

rule cutadapt:
    input:
        r1 = rules.rename_reads_id.output.r1,
        r2 = rules.rename_reads_id.output.r2
    output:
        r1 = cutadapt_output + "/{sample}/{sample}_1.fq.gz",
        r2 = cutadapt_output + "/{sample}/{sample}_2.fq.gz"
    log:
        "logs/cutadapt/{sample}_cutadapt.log"
    threads: 16
    params:
        f_adapter = f_primer,
        r_adapter = r_primer,
        max_error_num= 4
    conda:
        env_name
    shell:
        "cutadapt -g {params.f_adapter} -G {params.r_adapter} -e {params.max_error_num} -o {output.r1} -p {output.r2} {input.r1} {input.r2} &> {log}"


rule reads_length_frequency_distribution:
    input:
        r1 = expand(cutadapt_output + "/{sample}/{sample}_1.fq.gz", sample=SAMPLES),
        r2 = expand(cutadapt_output + "/{sample}/{sample}_2.fq.gz", sample=SAMPLES)
    output:
        r1 = summary_output + "/R1_length_frequency_distribution.tsv",
        r2 = summary_output + "/R2_length_frequency_distribution.tsv",
    log:
        "logs/reads_len_freq_dist.log"
    conda:
        env_name
    script:
        "scripts/R/reads_length_frequency_distribution.R"

rule flash:
    input:
        r1 = rules.cutadapt.output.r1,
        r2 = rules.cutadapt.output.r2,
    output:
        flash_output + "/{sample}/{sample}.extendedFrags.fastq"
    log:
        "logs/flash/{sample}_flash.log"
    threads: 16
    params:
        prefix = "{sample}",
        out_dir = flash_output + "/{sample}",
        phred_offset = 33,
        max_overlap= 250  # 最大重叠长度，如果重叠区大于这个长度也会正常拼接，但是下面的错配比率的分母还是按照这个值去算而不是整个重叠区长度，会导致拼接失败的比例升高 [default: 65]
    conda:
        env_name
    shell:
        "flash -m 15 -M {params.max_overlap} -x 0.1 -o {params.prefix} -d {params.out_dir} -p {params.phred_offset} -t {threads} {input.r1} {input.r2} &> {log}"


# rule dada2:
#     input:
#         rules.flash.output
#     output:
#         dada2_output + "/{sample}/{sample}_tag_nochim.fasta"
#     params:
#         sample_name = "{sample}",
#         minFoldParentOverAbundance = 1.5
#     log:
#         "logs/dada2/{sample}_dada2.log"
#     conda:
#         env_name
#     script:
#         "scripts/R/dada2_from_prejoined_seq.R"


rule dada2_paired_reads_truncLen220:
    input:
        r1 = rules.cutadapt.output.r1,
        r2 = rules.cutadapt.output.r2,
    output:
        r1 = dada2_paired_truncLen220_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2 = dada2_paired_truncLen220_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs = dada2_paired_truncLen220_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv = dada2_paired_truncLen220_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name = "{sample}",
        minFoldParentOverAbundance = 1.5,
        truncLen = 220
    log:
        "logs/dada2_paired_reads_truncLen220/{sample}_dada2_paired_reads.log"
    conda:
        env_name
    script:
        "scripts/R/dada2_from_paired_reads.R"


use rule dada2_paired_reads_truncLen220 as dada2_paired_reads_truncLen230 with:
    output:
        r1=dada2_paired_truncLen230_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2=dada2_paired_truncLen230_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs=dada2_paired_truncLen230_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv=dada2_paired_truncLen230_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name= "{sample}",
        minFoldParentOverAbundance= 1.5,
        truncLen= 230

    log:
        "logs/dada2_paired_reads_truncLen230/{sample}_dada2_paired_reads.log"



use rule dada2_paired_reads_truncLen220 as dada2_paired_reads_truncLen240 with:
    output:
        r1=dada2_paired_truncLen240_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2=dada2_paired_truncLen240_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs=dada2_paired_truncLen240_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv=dada2_paired_truncLen240_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name= "{sample}",
        minFoldParentOverAbundance= 1.5,
        truncLen= 240

    log:
        "logs/dada2_paired_reads_truncLen240/{sample}_dada2_paired_reads.log"


use rule dada2_paired_reads_truncLen220 as dada2_paired_reads_truncLen250 with:
    output:
        r1=dada2_paired_truncLen250_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2=dada2_paired_truncLen250_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs=dada2_paired_truncLen250_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv=dada2_paired_truncLen250_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name= "{sample}",
        minFoldParentOverAbundance= 1.5,
        truncLen= 250

    log:
        "logs/dada2_paired_reads_truncLen250/{sample}_dada2_paired_reads.log"



use rule dada2_paired_reads_truncLen220 as dada2_paired_reads_truncLen260 with:
    output:
        r1=dada2_paired_truncLen260_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2=dada2_paired_truncLen260_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs=dada2_paired_truncLen260_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv=dada2_paired_truncLen260_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name= "{sample}",
        minFoldParentOverAbundance= 1.5,
        truncLen= 260

    log:
        "logs/dada2_paired_reads_truncLen260/{sample}_dada2_paired_reads.log"


use rule dada2_paired_reads_truncLen220 as dada2_paired_reads_truncLen270 with:
    output:
        r1=dada2_paired_truncLen270_output + "/{sample}/{sample}_1_filt.fq.gz",
        r2=dada2_paired_truncLen270_output + "/{sample}/{sample}_2_filt.fq.gz",
        rep_seqs=dada2_paired_truncLen270_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv=dada2_paired_truncLen270_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name= "{sample}",
        minFoldParentOverAbundance= 1.5,
        truncLen= 270

    log:
        "logs/dada2_paired_reads_truncLen270/{sample}_dada2_paired_reads.log"






rule dada2_single_reads:
    input:
        cr1 = rules.cutadapt.output.r1,
        merged_seq = rules.flash.output
    output:
        rep_seqs = dada2_single_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv= dada2_single_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name = "{sample}",
        minFoldParentOverAbundance = 1.5,
        is_filter = 0
    log:
        "logs/dada2_single_reads/{sample}_dada2_single_reads.log"
    conda:
        env_name
    script:
        "scripts/R/dada2_from_single_reads.R"



use rule dada2_single_reads as dada2_single_filter_reads with:
    output:
        rep_seqs=dada2_single_filter_output + "/{sample}/{sample}_rep_seqs_nochim.fasta",
        tsv=dada2_single_filter_output + "/{sample}/{sample}_summary.tsv",
    params:
        sample_name= "{sample}",
        minFoldParentOverAbundance= 1.5,
        is_filter= 1
    log:
        "logs/dada2_single_filter_reads/{sample}_dada2_single_filter_reads.log"

rule summary:
    input:
        paired_reads_truncLen220_tsv = expand(dada2_paired_truncLen220_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        paired_reads_truncLen230_tsv = expand(dada2_paired_truncLen230_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        paired_reads_truncLen240_tsv = expand(dada2_paired_truncLen240_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        paired_reads_truncLen250_tsv = expand(dada2_paired_truncLen250_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        paired_reads_truncLen260_tsv = expand(dada2_paired_truncLen260_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        paired_reads_truncLen270_tsv = expand(dada2_paired_truncLen270_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        single_reads_tsv = expand(dada2_single_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),
        single_filter_reads_tsv = expand(dada2_single_filter_output + "/{sample}/{sample}_summary.tsv", sample=SAMPLES),

    output:
        paired_reads_truncLen220_tsv = summary_output + "/paired_reads_truncLen220.tsv",
        paired_reads_truncLen230_tsv = summary_output + "/paired_reads_truncLen230.tsv",
        paired_reads_truncLen240_tsv = summary_output + "/paired_reads_truncLen240.tsv",
        paired_reads_truncLen250_tsv = summary_output + "/paired_reads_truncLen250.tsv",
        paired_reads_truncLen260_tsv = summary_output + "/paired_reads_truncLen260.tsv",
        paired_reads_truncLen270_tsv = summary_output + "/paired_reads_truncLen270.tsv",
        single_reads_tsv = summary_output + "/single_reads.tsv",
        single_filter_reads_tsv = summary_output + "/single_filter_reads.tsv",
    script:
        "scripts/python/dada2_summary.py"





